package meteordevelopment.meteorclient.events.packets;

import meteordevelopment.meteorclient.events.Cancellable;
import net.minecraft.class_2596;

public class PacketEvent extends Cancellable {
   public class_2596<?> packet;

   public static class Sent extends PacketEvent {
      private static final PacketEvent.Sent INSTANCE = new PacketEvent.Sent();

      public static PacketEvent.Sent get(class_2596<?> packet) {
         INSTANCE.packet = packet;
         return INSTANCE;
      }
   }

   public static class Send extends PacketEvent {
      private static final PacketEvent.Send INSTANCE = new PacketEvent.Send();

      public static PacketEvent.Send get(class_2596<?> packet) {
         INSTANCE.setCancelled(false);
         INSTANCE.packet = packet;
         return INSTANCE;
      }
   }

   public static class Receive extends PacketEvent {
      private static final PacketEvent.Receive INSTANCE = new PacketEvent.Receive();

      public static PacketEvent.Receive get(class_2596<?> packet) {
         INSTANCE.setCancelled(false);
         INSTANCE.packet = packet;
         return INSTANCE;
      }
   }
}
