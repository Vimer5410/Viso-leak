package meteordevelopment.meteorclient.events.entity.player;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class BreakBlockEvent {
   private static final BreakBlockEvent INSTANCE = new BreakBlockEvent();
   public class_2338 blockPos;

   public class_2680 getBlockState(class_1937 world) {
      return world.method_8320(this.blockPos);
   }

   public static BreakBlockEvent get(class_2338 blockPos) {
      INSTANCE.blockPos = blockPos;
      return INSTANCE;
   }
}
