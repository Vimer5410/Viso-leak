package meteordevelopment.meteorclient.events.entity.player;

import meteordevelopment.meteorclient.events.Cancellable;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class CobwebEntityCollisionEvent extends Cancellable {
   private static final CobwebEntityCollisionEvent INSTANCE = new CobwebEntityCollisionEvent();
   public class_2680 state;
   public class_2338 blockPos;

   public static CobwebEntityCollisionEvent get(class_2680 state, class_2338 blockPos) {
      INSTANCE.setCancelled(false);
      INSTANCE.state = state;
      INSTANCE.blockPos = blockPos;
      return INSTANCE;
   }
}
