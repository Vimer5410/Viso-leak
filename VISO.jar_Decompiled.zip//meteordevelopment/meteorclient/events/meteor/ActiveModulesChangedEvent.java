package meteordevelopment.meteorclient.events.meteor;

public class ActiveModulesChangedEvent {
   private static final ActiveModulesChangedEvent INSTANCE = new ActiveModulesChangedEvent();

   public static ActiveModulesChangedEvent get() {
      return INSTANCE;
   }
}
