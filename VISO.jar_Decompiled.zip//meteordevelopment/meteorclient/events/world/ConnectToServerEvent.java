package meteordevelopment.meteorclient.events.world;

public class ConnectToServerEvent {
   private static final ConnectToServerEvent INSTANCE = new ConnectToServerEvent();

   public static ConnectToServerEvent get() {
      return INSTANCE;
   }
}
