package meteordevelopment.meteorclient.events.world;

import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;

public class CollisionShapeEvent {
   private static final CollisionShapeEvent INSTANCE = new CollisionShapeEvent();
   public class_2680 state;
   public class_2338 pos;
   public class_265 shape;
   public CollisionShapeEvent.CollisionType type;

   public static CollisionShapeEvent get(class_2680 state, class_2338 pos, CollisionShapeEvent.CollisionType type) {
      INSTANCE.state = state;
      INSTANCE.pos = pos;
      INSTANCE.shape = null;
      INSTANCE.type = type;
      return INSTANCE;
   }

   public static enum CollisionType {
      BLOCK,
      FLUID;

      // $FF: synthetic method
      private static CollisionShapeEvent.CollisionType[] $values() {
         return new CollisionShapeEvent.CollisionType[]{BLOCK, FLUID};
      }
   }
}
