package meteordevelopment.meteorclient.events.world;

import meteordevelopment.meteorclient.utils.misc.Pool;
import net.minecraft.class_2818;

public class ChunkDataEvent {
   private static final Pool<ChunkDataEvent> INSTANCE = new Pool(ChunkDataEvent::new);
   public class_2818 chunk;

   public static ChunkDataEvent get(class_2818 chunk) {
      ChunkDataEvent event = (ChunkDataEvent)INSTANCE.get();
      event.chunk = chunk;
      return event;
   }

   public static void returnChunkDataEvent(ChunkDataEvent event) {
      INSTANCE.free(event);
   }
}
