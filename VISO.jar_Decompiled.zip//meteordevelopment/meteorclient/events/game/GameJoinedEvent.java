package meteordevelopment.meteorclient.events.game;

public class GameJoinedEvent {
   private static final GameJoinedEvent INSTANCE = new GameJoinedEvent();

   public static GameJoinedEvent get() {
      return INSTANCE;
   }
}
