package meteordevelopment.meteorclient.events.game;

import meteordevelopment.meteorclient.events.Cancellable;
import net.minecraft.class_2561;

public class ReceiveMessageEvent extends Cancellable {
   private static final ReceiveMessageEvent INSTANCE = new ReceiveMessageEvent();
   private class_2561 message;
   private boolean modified;
   public int id;

   public static ReceiveMessageEvent get(class_2561 message, int id) {
      INSTANCE.setCancelled(false);
      INSTANCE.message = message;
      INSTANCE.modified = false;
      INSTANCE.id = id;
      return INSTANCE;
   }

   public class_2561 getMessage() {
      return this.message;
   }

   public void setMessage(class_2561 message) {
      this.message = message;
      this.modified = true;
   }

   public boolean isModified() {
      return this.modified;
   }
}
