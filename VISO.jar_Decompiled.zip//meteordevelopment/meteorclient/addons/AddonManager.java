package meteordevelopment.meteorclient.addons;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.utils.Init;
import meteordevelopment.meteorclient.utils.InitStage;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.entrypoint.EntrypointContainer;
import net.fabricmc.loader.api.metadata.ModMetadata;
import net.fabricmc.loader.api.metadata.Person;

public class AddonManager {
   public static MeteorAddon METEOR;
   public static final List<MeteorAddon> ADDONS = new ArrayList();

   @Init(
      stage = InitStage.Pre
   )
   public static void init() {
      METEOR = new MeteorAddon() {
         public void onInitialize() {
         }
      };
      ModMetadata metadata = ((ModContainer)FabricLoader.getInstance().getModContainer("meteor-client").get()).getMetadata();
      METEOR.name = metadata.getName();
      METEOR.authors = new String[metadata.getAuthors().size()];
      if (metadata.containsCustomValue("meteor-client:color")) {
         METEOR.color.parse(metadata.getCustomValue("meteor-client:color").getAsString());
      }

      int i = 0;

      Person author;
      for(Iterator var2 = metadata.getAuthors().iterator(); var2.hasNext(); METEOR.authors[i++] = author.getName()) {
         author = (Person)var2.next();
      }

      Iterator var7 = FabricLoader.getInstance().getEntrypointContainers("meteor", MeteorAddon.class).iterator();

      while(var7.hasNext()) {
         EntrypointContainer<MeteorAddon> entrypoint = (EntrypointContainer)var7.next();
         ModMetadata metadata = entrypoint.getProvider().getMetadata();
         MeteorAddon addon = (MeteorAddon)entrypoint.getEntrypoint();
         addon.name = metadata.getName();
         addon.authors = new String[metadata.getAuthors().size()];
         if (metadata.containsCustomValue("meteor-client:color")) {
            addon.color.parse(metadata.getCustomValue("meteor-client:color").getAsString());
         }

         int i = 0;

         Person author;
         for(Iterator var5 = metadata.getAuthors().iterator(); var5.hasNext(); addon.authors[i++] = author.getName()) {
            author = (Person)var5.next();
         }

         ADDONS.add(addon);
      }

   }
}
