package meteordevelopment.meteorclient;

import java.awt.Component;
import java.io.File;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import net.minecraft.class_156;

public class Main {
   public static void main(String[] args) throws UnsupportedLookAndFeelException, ClassNotFoundException, InstantiationException, IllegalAccessException {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      int option = JOptionPane.showOptionDialog((Component)null, "To install Meteor Client you need to put it in your mods folder and run Fabric for latest Minecraft version.", "Meteor Client", 0, 0, (Icon)null, new String[]{"Open Wiki", "Open Mods Folder"}, (Object)null);
      switch(option) {
      case 0:
         class_156.method_668().method_670("https://github.com/MeteorDevelopment/meteor-client/wiki/Installation");
         break;
      case 1:
         String var10000;
         switch(class_156.method_668()) {
         case field_1133:
            var10000 = System.getenv("AppData") + "/.minecraft/mods";
            break;
         case field_1137:
            var10000 = System.getProperty("user.home") + "/Library/Application Support/minecraft/mods";
            break;
         default:
            var10000 = System.getProperty("user.home") + "/.minecraft";
         }

         String path = var10000;
         File mods = new File(path);
         if (!mods.exists()) {
            mods.mkdirs();
         }

         class_156.method_668().method_672(mods);
      }

   }
}
