package meteordevelopment.meteorclient.systems.accounts;

public class TexturesJson {
   public TexturesJson.Textures textures;

   public static class Texture {
      public String url;
   }

   public static class Textures {
      public TexturesJson.Texture SKIN;
   }
}
