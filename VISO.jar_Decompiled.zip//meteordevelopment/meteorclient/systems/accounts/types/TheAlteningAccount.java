package meteordevelopment.meteorclient.systems.accounts.types;

import com.mojang.authlib.Agent;
import com.mojang.authlib.Environment;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilMinecraftSessionService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import java.util.Optional;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.mixin.MinecraftClientAccessor;
import meteordevelopment.meteorclient.systems.accounts.Account;
import meteordevelopment.meteorclient.systems.accounts.AccountType;
import meteordevelopment.meteorclient.systems.accounts.AccountUtils;
import net.minecraft.class_320;
import net.minecraft.class_320.class_321;

public class TheAlteningAccount extends Account<TheAlteningAccount> {
   private static final String AUTH = "http://authserver.thealtening.com";
   private static final String ACCOUNT = "https://api.mojang.com";
   private static final String SESSION = "http://sessionserver.thealtening.com";
   private static final String SERVICES = "https://api.minecraftservices.com";

   public TheAlteningAccount(String token) {
      super(AccountType.TheAltening, token);
   }

   public boolean fetchInfo() {
      YggdrasilUserAuthentication auth = this.getAuth();

      try {
         auth.logIn();
         this.cache.username = auth.getSelectedProfile().getName();
         this.cache.uuid = auth.getSelectedProfile().getId().toString();
         return true;
      } catch (AuthenticationException var3) {
         return false;
      }
   }

   public boolean login() {
      YggdrasilMinecraftSessionService service = (YggdrasilMinecraftSessionService)MeteorClient.mc.method_1495();
      AccountUtils.setBaseUrl(service, "http://sessionserver.thealtening.com/session/minecraft/");
      AccountUtils.setJoinUrl(service, "http://sessionserver.thealtening.com/session/minecraft/join");
      AccountUtils.setCheckUrl(service, "http://sessionserver.thealtening.com/session/minecraft/hasJoined");
      YggdrasilUserAuthentication auth = this.getAuth();

      try {
         auth.logIn();
         this.setSession(new class_320(auth.getSelectedProfile().getName(), auth.getSelectedProfile().getId().toString(), auth.getAuthenticatedToken(), Optional.empty(), Optional.empty(), class_321.field_1988));
         this.cache.username = auth.getSelectedProfile().getName();
         return true;
      } catch (AuthenticationException var4) {
         MeteorClient.LOG.error("Failed to login with TheAltening.");
         return false;
      }
   }

   private YggdrasilUserAuthentication getAuth() {
      YggdrasilUserAuthentication auth = (YggdrasilUserAuthentication)(new YggdrasilAuthenticationService(((MinecraftClientAccessor)MeteorClient.mc).getProxy(), "", Environment.create("http://authserver.thealtening.com", "https://api.mojang.com", "http://sessionserver.thealtening.com", "https://api.minecraftservices.com", "The Altening"))).createUserAuthentication(Agent.MINECRAFT);
      auth.setUsername(this.name);
      auth.setPassword("Meteor on Crack!");
      return auth;
   }
}
