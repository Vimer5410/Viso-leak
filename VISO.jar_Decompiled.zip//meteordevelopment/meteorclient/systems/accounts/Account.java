package meteordevelopment.meteorclient.systems.accounts;

import com.mojang.authlib.yggdrasil.YggdrasilEnvironment;
import com.mojang.authlib.yggdrasil.YggdrasilMinecraftSessionService;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.mixin.MinecraftClientAccessor;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import meteordevelopment.meteorclient.utils.misc.NbtException;
import net.minecraft.class_2487;
import net.minecraft.class_320;

public abstract class Account<T extends Account<?>> implements ISerializable<T> {
   protected AccountType type;
   protected String name;
   protected final AccountCache cache;

   public Account(AccountType type, String name) {
      this.type = type;
      this.name = name;
      this.cache = new AccountCache();
   }

   public abstract boolean fetchInfo();

   public boolean fetchHead() {
      String url = AccountUtils.getSkinUrl(this.cache.username);
      return url == null ? true : this.cache.loadHead(url);
   }

   public boolean login() {
      YggdrasilMinecraftSessionService service = (YggdrasilMinecraftSessionService)MeteorClient.mc.method_1495();
      AccountUtils.setBaseUrl(service, YggdrasilEnvironment.PROD.getEnvironment().getSessionHost() + "/session/minecraft/");
      AccountUtils.setJoinUrl(service, YggdrasilEnvironment.PROD.getEnvironment().getSessionHost() + "/session/minecraft/join");
      AccountUtils.setCheckUrl(service, YggdrasilEnvironment.PROD.getEnvironment().getSessionHost() + "/session/minecraft/hasJoined");
      return true;
   }

   public String getUsername() {
      return this.cache.username.isEmpty() ? this.name : this.cache.username;
   }

   public AccountType getType() {
      return this.type;
   }

   public AccountCache getCache() {
      return this.cache;
   }

   protected void setSession(class_320 session) {
      ((MinecraftClientAccessor)MeteorClient.mc).setSession(session);
      MeteorClient.mc.method_1539().clear();
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10582("type", this.type.name());
      tag.method_10582("name", this.name);
      tag.method_10566("cache", this.cache.toTag());
      return tag;
   }

   public T fromTag(class_2487 tag) {
      if (tag.method_10545("name") && tag.method_10545("cache")) {
         this.name = tag.method_10558("name");
         this.cache.fromTag(tag.method_10562("cache"));
         return this;
      } else {
         throw new NbtException();
      }
   }
}
