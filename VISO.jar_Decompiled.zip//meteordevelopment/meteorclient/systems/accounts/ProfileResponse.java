package meteordevelopment.meteorclient.systems.accounts;

public class ProfileResponse {
   public String id;
}
