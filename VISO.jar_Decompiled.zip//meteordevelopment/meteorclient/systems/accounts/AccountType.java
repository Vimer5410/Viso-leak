package meteordevelopment.meteorclient.systems.accounts;

public enum AccountType {
   Cracked,
   Premium,
   Microsoft,
   TheAltening;

   // $FF: synthetic method
   private static AccountType[] $values() {
      return new AccountType[]{Cracked, Premium, Microsoft, TheAltening};
   }
}
