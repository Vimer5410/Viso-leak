package meteordevelopment.meteorclient.systems.waypoints;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.WaypointsModule;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.files.StreamUtils;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.world.Dimension;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_2487;

public class Waypoints extends System<Waypoints> implements Iterable<Waypoint> {
   private static final String[] BUILTIN_ICONS = new String[]{"square", "circle", "triangle", "star", "diamond", "skull"};
   private static final Color TEXT = new Color(255, 255, 255);
   public final Map<String, class_1044> icons = new HashMap();
   public List<Waypoint> waypoints = new ArrayList();

   public Waypoints() {
      super((String)null);
   }

   public static Waypoints get() {
      return (Waypoints)Systems.get(Waypoints.class);
   }

   public void init() {
      File iconsFolder = new File(new File(MeteorClient.FOLDER, "waypoints"), "icons");
      iconsFolder.mkdirs();
      String[] var2 = BUILTIN_ICONS;
      int var3 = var2.length;

      int var4;
      File file;
      for(var4 = 0; var4 < var3; ++var4) {
         String builtinIcon = var2[var4];
         file = new File(iconsFolder, builtinIcon + ".png");
         if (!file.exists()) {
            this.copyIcon(file);
         }
      }

      File[] files = iconsFolder.listFiles();
      File[] var11 = files;
      var4 = files.length;

      for(int var12 = 0; var12 < var4; ++var12) {
         file = var11[var12];
         if (file.getName().endsWith(".png")) {
            try {
               String name = file.getName().replace(".png", "");
               class_1044 texture = new class_1043(class_1011.method_4309(new FileInputStream(file)));
               this.icons.put(name, texture);
            } catch (IOException var9) {
               var9.printStackTrace();
            }
         }
      }

   }

   public void add(Waypoint waypoint) {
      this.waypoints.add(waypoint);
      this.save();
   }

   public void remove(Waypoint waypoint) {
      if (this.waypoints.remove(waypoint)) {
         this.save();
      }

   }

   public Waypoint get(String name) {
      Iterator var2 = this.iterator();

      Waypoint waypoint;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         waypoint = (Waypoint)var2.next();
      } while(!waypoint.name.equalsIgnoreCase(name));

      return waypoint;
   }

   @EventHandler
   private void onGameJoined(GameJoinedEvent event) {
      this.load();
   }

   @EventHandler(
      priority = -200
   )
   private void onGameDisconnected(GameLeftEvent event) {
      this.waypoints.clear();
   }

   private boolean checkDimension(Waypoint waypoint) {
      Dimension dimension = PlayerUtils.getDimension();
      if (waypoint.overworld && dimension == Dimension.Overworld) {
         return true;
      } else if (waypoint.nether && dimension == Dimension.Nether) {
         return true;
      } else {
         return waypoint.end && dimension == Dimension.End;
      }
   }

   @EventHandler
   private void onRender2D(Render2DEvent event) {
      WaypointsModule module = (WaypointsModule)Modules.get().get(WaypointsModule.class);
      if (module.isActive()) {
         TextRenderer text = TextRenderer.get();
         Vec3 center = new Vec3((double)MeteorClient.mc.method_22683().method_4489() / 2.0D, (double)MeteorClient.mc.method_22683().method_4506() / 2.0D, 0.0D);
         int textRenderDist = (Integer)module.textRenderDistance.get();
         Iterator var6 = this.iterator();

         while(true) {
            Waypoint waypoint;
            Vec3 pos;
            double dist;
            double distToCenter;
            double a;
            do {
               do {
                  do {
                     do {
                        do {
                           if (!var6.hasNext()) {
                              return;
                           }

                           waypoint = (Waypoint)var6.next();
                        } while(!waypoint.visible);
                     } while(!this.checkDimension(waypoint));

                     pos = waypoint.getCoords().add(0.5D, 0.0D, 0.5D);
                     dist = PlayerUtils.distanceToCamera(pos.x, pos.y, pos.z);
                  } while(dist > (double)waypoint.maxVisibleDistance);
               } while(!NametagUtils.to2D(pos, 1.0D));

               distToCenter = pos.distanceTo(center);
               a = 1.0D;
               if (!(dist < 20.0D)) {
                  break;
               }

               a = (dist - 10.0D) / 10.0D;
            } while(a < 0.01D);

            NametagUtils.scale = waypoint.scale - 0.2D;
            NametagUtils.begin(pos);
            waypoint.renderIcon(-16.0D, -16.0D, a, 32.0D);
            if (distToCenter <= (double)textRenderDist) {
               int preTextA = TEXT.a;
               Color var10000 = TEXT;
               var10000.a = (int)((double)var10000.a * a);
               text.begin();
               text.render(waypoint.name, -text.getWidth(waypoint.name) / 2.0D, -16.0D - text.getHeight(), TEXT, true);
               String distText = String.format("%d blocks", (int)Math.round(dist));
               text.render(distText, -text.getWidth(distText) / 2.0D, 16.0D, TEXT, true);
               text.end();
               TEXT.a = preTextA;
            }

            NametagUtils.end();
         }
      }
   }

   public File getFile() {
      return !Utils.canUpdate() ? null : new File(new File(MeteorClient.FOLDER, "waypoints"), Utils.getWorldName() + ".nbt");
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10566("waypoints", NbtUtils.listToTag(this.waypoints));
      return tag;
   }

   public Waypoints fromTag(class_2487 tag) {
      this.waypoints = NbtUtils.listFromTag(tag.method_10554("waypoints", 10), (tag1) -> {
         return (new Waypoint()).fromTag((class_2487)tag1);
      });
      return this;
   }

   public Iterator<Waypoint> iterator() {
      return this.waypoints.iterator();
   }

   public ListIterator<Waypoint> iteratorReverse() {
      return this.waypoints.listIterator(this.waypoints.size());
   }

   private void copyIcon(File file) {
      StreamUtils.copy(Waypoints.class.getResourceAsStream("/assets/meteor-client/textures/icons/waypoints/" + file.getName()), file);
   }
}
