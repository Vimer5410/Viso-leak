package meteordevelopment.meteorclient.systems.waypoints;

import java.util.Iterator;
import java.util.Map;
import meteordevelopment.meteorclient.renderer.GL;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.Dimension;
import net.minecraft.class_1044;
import net.minecraft.class_2487;
import net.minecraft.class_4587;

public class Waypoint implements ISerializable<Waypoint> {
   public String name = "Meteor on Crack!";
   public String icon = "Square";
   public SettingColor color = new SettingColor(225, 25, 25);
   public int x;
   public int y;
   public int z;
   public boolean visible = true;
   public int maxVisibleDistance = 1000;
   public double scale = 1.0D;
   public boolean overworld;
   public boolean nether;
   public boolean end;
   public Dimension actualDimension;

   public void validateIcon() {
      Map<String, class_1044> icons = Waypoints.get().icons;
      class_1044 texture = (class_1044)icons.get(this.icon);
      if (texture == null && !icons.isEmpty()) {
         this.icon = (String)icons.keySet().iterator().next();
      }

   }

   public void renderIcon(double x, double y, double a, double size) {
      this.validateIcon();
      class_1044 texture = (class_1044)Waypoints.get().icons.get(this.icon);
      if (texture != null) {
         int preA = this.color.a;
         SettingColor var10000 = this.color;
         var10000.a = (int)((double)var10000.a * a);
         GL.bindTexture(texture.method_4624());
         Renderer2D.TEXTURE.begin();
         Renderer2D.TEXTURE.texQuad(x, y, size, size, this.color);
         Renderer2D.TEXTURE.render((class_4587)null);
         this.color.a = preA;
      }
   }

   private int findIconIndex() {
      int i = 0;

      for(Iterator var2 = Waypoints.get().icons.keySet().iterator(); var2.hasNext(); ++i) {
         String icon = (String)var2.next();
         if (this.icon.equals(icon)) {
            return i;
         }
      }

      return -1;
   }

   private int correctIconIndex(int i) {
      if (i < 0) {
         return Waypoints.get().icons.size() + i;
      } else {
         return i >= Waypoints.get().icons.size() ? i - Waypoints.get().icons.size() : i;
      }
   }

   private String getIcon(int i) {
      i = this.correctIconIndex(i);
      int _i = 0;

      for(Iterator var3 = Waypoints.get().icons.keySet().iterator(); var3.hasNext(); ++_i) {
         String icon = (String)var3.next();
         if (_i == i) {
            return icon;
         }
      }

      return "Square";
   }

   public void prevIcon() {
      this.icon = this.getIcon(this.findIconIndex() - 1);
   }

   public void nextIcon() {
      this.icon = this.getIcon(this.findIconIndex() + 1);
   }

   public Vec3 getCoords() {
      double x = (double)this.x;
      double y = (double)this.y;
      double z = (double)this.z;
      if (this.actualDimension == Dimension.Overworld && PlayerUtils.getDimension() == Dimension.Nether) {
         x /= 8.0D;
         z /= 8.0D;
      } else if (this.actualDimension == Dimension.Nether && PlayerUtils.getDimension() == Dimension.Overworld) {
         x *= 8.0D;
         z *= 8.0D;
      }

      return new Vec3(x, y, z);
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10582("name", this.name);
      tag.method_10582("icon", this.icon);
      tag.method_10566("color", this.color.toTag());
      tag.method_10569("x", this.x);
      tag.method_10569("y", this.y);
      tag.method_10569("z", this.z);
      tag.method_10556("visible", this.visible);
      tag.method_10569("maxVisibleDistance", this.maxVisibleDistance);
      tag.method_10549("scale", this.scale);
      tag.method_10582("dimension", this.actualDimension.name());
      tag.method_10556("overworld", this.overworld);
      tag.method_10556("nether", this.nether);
      tag.method_10556("end", this.end);
      return tag;
   }

   public Waypoint fromTag(class_2487 tag) {
      this.name = tag.method_10558("name");
      this.icon = tag.method_10558("icon");
      this.color.fromTag(tag.method_10562("color"));
      this.x = tag.method_10550("x");
      this.y = tag.method_10550("y");
      this.z = tag.method_10550("z");
      this.visible = tag.method_10577("visible");
      this.maxVisibleDistance = tag.method_10550("maxVisibleDistance");
      this.scale = tag.method_10574("scale");
      this.actualDimension = Dimension.valueOf(tag.method_10558("dimension"));
      this.overworld = tag.method_10577("overworld");
      this.nether = tag.method_10577("nether");
      this.end = tag.method_10577("end");
      if (!Waypoints.get().icons.containsKey(this.icon)) {
         this.icon = "Square";
      }

      return this;
   }
}
