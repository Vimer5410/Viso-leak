package meteordevelopment.meteorclient.systems.profiles;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.accounts.Accounts;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.macros.Macros;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.waypoints.Waypoints;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import org.apache.commons.io.FileUtils;

public class Profile implements ISerializable<Profile> {
   public String name = "";
   public boolean onLaunch = false;
   public List<String> loadOnJoinIps = new ArrayList();
   public boolean accounts = false;
   public boolean config = true;
   public boolean friends = false;
   public boolean macros = true;
   public boolean modules = true;
   public boolean waypoints = false;
   public boolean hud = false;

   public void load(System<?> system) {
      File folder = new File(Profiles.FOLDER, this.name);
      system.load(folder);
   }

   public void load() {
      File folder = new File(Profiles.FOLDER, this.name);
      if (this.accounts) {
         Accounts.get().load(folder);
      }

      if (this.config) {
         Config.get().load(folder);
      }

      if (this.friends) {
         Friends.get().load(folder);
      }

      if (this.macros) {
         Macros.get().load(folder);
      }

      if (this.modules) {
         Modules.get().load(folder);
      }

      if (this.waypoints) {
         Waypoints.get().load(folder);
      }

      if (this.hud) {
         HUD.get().load(folder);
      }

   }

   public void save(System<?> system) {
      File folder = new File(Profiles.FOLDER, this.name);
      system.save(folder);
   }

   public void save() {
      File folder = new File(Profiles.FOLDER, this.name);
      if (this.accounts) {
         Accounts.get().save(folder);
      }

      if (this.config) {
         Config.get().save(folder);
      }

      if (this.friends) {
         Friends.get().save(folder);
      }

      if (this.macros) {
         Macros.get().save(folder);
      }

      if (this.modules) {
         Modules.get().save(folder);
      }

      if (this.waypoints) {
         Waypoints.get().save(folder);
      }

      if (this.hud) {
         HUD.get().save(folder);
      }

   }

   public void delete(System<?> system) {
      File file = new File(new File(Profiles.FOLDER, this.name), system.getFile().getName());
      file.delete();
   }

   public void delete() {
      try {
         FileUtils.deleteDirectory(new File(Profiles.FOLDER, this.name));
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10582("name", this.name);
      tag.method_10556("onLaunch", this.onLaunch);
      tag.method_10556("accounts", this.accounts);
      tag.method_10556("config", this.config);
      tag.method_10556("friends", this.friends);
      tag.method_10556("macros", this.macros);
      tag.method_10556("modules", this.modules);
      tag.method_10556("waypoints", this.waypoints);
      tag.method_10556("hud", this.hud);
      this.loadOnJoinIps.removeIf(String::isEmpty);
      class_2499 ipsTag = new class_2499();
      Iterator var3 = this.loadOnJoinIps.iterator();

      while(var3.hasNext()) {
         String ip = (String)var3.next();
         ipsTag.add(class_2519.method_23256(ip));
      }

      tag.method_10566("loadOnJoinIps", ipsTag);
      return tag;
   }

   public Profile fromTag(class_2487 tag) {
      this.name = tag.method_10558("name");
      this.onLaunch = tag.method_10545("onLaunch") && tag.method_10577("onLaunch");
      this.accounts = tag.method_10545("accounts") && tag.method_10577("accounts");
      this.config = tag.method_10545("config") && tag.method_10577("config");
      this.friends = tag.method_10545("friends") && tag.method_10577("friends");
      this.macros = tag.method_10545("macros") && tag.method_10577("macros");
      this.modules = tag.method_10545("modules") && tag.method_10577("modules");
      this.waypoints = tag.method_10545("waypoints") && tag.method_10577("waypoints");
      this.hud = tag.method_10545("hud") && tag.method_10577("hud");
      this.loadOnJoinIps.clear();
      if (tag.method_10545("loadOnJoinIps")) {
         class_2499 ipsTag = tag.method_10554("loadOnJoinIps", 8);
         Iterator var3 = ipsTag.iterator();

         while(var3.hasNext()) {
            class_2520 ip = (class_2520)var3.next();
            this.loadOnJoinIps.add(ip.method_10714());
         }
      }

      return this;
   }

   public Profile set(Profile profile) {
      this.name = profile.name;
      this.onLaunch = profile.onLaunch;
      this.loadOnJoinIps = profile.loadOnJoinIps;
      this.accounts = profile.accounts;
      this.config = profile.config;
      this.friends = profile.friends;
      this.macros = profile.macros;
      this.modules = profile.modules;
      this.waypoints = profile.waypoints;
      this.hud = profile.hud;
      return this;
   }

   public boolean equals(Object o) {
      if (this == o) {
         return true;
      } else if (o != null && this.getClass() == o.getClass()) {
         Profile profile = (Profile)o;
         return this.name.equalsIgnoreCase(profile.name);
      } else {
         return false;
      }
   }
}
