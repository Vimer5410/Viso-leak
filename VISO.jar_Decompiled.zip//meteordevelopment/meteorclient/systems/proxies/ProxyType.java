package meteordevelopment.meteorclient.systems.proxies;

public enum ProxyType {
   Socks4,
   Socks5;

   // $FF: synthetic method
   private static ProxyType[] $values() {
      return new ProxyType[]{Socks4, Socks5};
   }
}
