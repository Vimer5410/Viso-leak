package meteordevelopment.meteorclient.systems.proxies;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import net.minecraft.class_2487;
import org.jetbrains.annotations.NotNull;

public class Proxies extends System<Proxies> implements Iterable<Proxy> {
   private List<Proxy> proxies = new ArrayList();

   public Proxies() {
      super("proxies");
   }

   public static Proxies get() {
      return (Proxies)Systems.get(Proxies.class);
   }

   public boolean add(Proxy proxy) {
      Iterator var2 = this.proxies.iterator();

      Proxy p;
      do {
         if (!var2.hasNext()) {
            if (this.proxies.isEmpty()) {
               proxy.enabled = true;
            }

            this.proxies.add(proxy);
            this.save();
            return true;
         }

         p = (Proxy)var2.next();
      } while(p.type != proxy.type || !p.address.equals(proxy.address) || p.port != proxy.port);

      return false;
   }

   public void remove(Proxy proxy) {
      if (this.proxies.remove(proxy)) {
         this.save();
      }

   }

   public Proxy getEnabled() {
      Iterator var1 = this.proxies.iterator();

      Proxy proxy;
      do {
         if (!var1.hasNext()) {
            return null;
         }

         proxy = (Proxy)var1.next();
      } while(!proxy.enabled);

      return proxy;
   }

   public void setEnabled(Proxy proxy, boolean enabled) {
      Proxy p;
      for(Iterator var3 = this.proxies.iterator(); var3.hasNext(); p.enabled = false) {
         p = (Proxy)var3.next();
      }

      proxy.enabled = enabled;
      this.save();
   }

   @NotNull
   public Iterator<Proxy> iterator() {
      return this.proxies.iterator();
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10566("proxies", NbtUtils.listToTag(this.proxies));
      return tag;
   }

   public Proxies fromTag(class_2487 tag) {
      this.proxies = NbtUtils.listFromTag(tag.method_10554("proxies", 10), (tag1) -> {
         return (new Proxy()).fromTag((class_2487)tag1);
      });
      return this;
   }
}
