package meteordevelopment.meteorclient.systems.proxies;

import java.net.InetSocketAddress;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import net.minecraft.class_2487;

public class Proxy implements ISerializable<Proxy> {
   public ProxyType type;
   public String address;
   public int port;
   public String name;
   public String username;
   public String password;
   public boolean enabled;

   public Proxy() {
      this.type = ProxyType.Socks5;
      this.address = "";
      this.port = 0;
      this.name = "";
      this.username = "";
      this.password = "";
      this.enabled = false;
   }

   public boolean resolveAddress() {
      if (this.port >= 0 && this.port <= 65535) {
         InetSocketAddress socketAddress = new InetSocketAddress(this.address, this.port);
         return !socketAddress.isUnresolved();
      } else {
         return false;
      }
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10582("type", this.type.name());
      tag.method_10582("ip", this.address);
      tag.method_10569("port", this.port);
      tag.method_10582("name", this.name);
      tag.method_10582("username", this.username);
      tag.method_10582("password", this.password);
      tag.method_10556("enabled", this.enabled);
      return tag;
   }

   public Proxy fromTag(class_2487 tag) {
      this.type = ProxyType.valueOf(tag.method_10558("type"));
      this.address = tag.method_10558("ip");
      this.port = tag.method_10550("port");
      this.name = tag.method_10558("name");
      this.username = tag.method_10558("username");
      this.password = tag.method_10558("password");
      this.enabled = tag.method_10577("enabled");
      return this;
   }
}
