package meteordevelopment.meteorclient.systems.friends;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import meteordevelopment.meteorclient.utils.render.color.RainbowColors;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import org.jetbrains.annotations.NotNull;

public class Friends extends System<Friends> implements Iterable<Friend> {
   private List<Friend> friends = new ArrayList();
   public final SettingColor color = new SettingColor(0, 255, 180);
   public boolean attack = false;

   public Friends() {
      super("friends");
   }

   public static Friends get() {
      return (Friends)Systems.get(Friends.class);
   }

   public void init() {
      RainbowColors.add(this.color);
   }

   public boolean add(Friend friend) {
      if (friend.name.isEmpty()) {
         return false;
      } else if (!this.friends.contains(friend)) {
         this.friends.add(friend);
         this.save();
         return true;
      } else {
         return false;
      }
   }

   public boolean remove(Friend friend) {
      if (this.friends.remove(friend)) {
         this.save();
         return true;
      } else {
         return false;
      }
   }

   public Friend get(String name) {
      Iterator var2 = this.friends.iterator();

      Friend friend;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         friend = (Friend)var2.next();
      } while(!friend.name.equals(name));

      return friend;
   }

   public Friend get(class_1657 player) {
      return this.get(player.method_5820());
   }

   public boolean isFriend(class_1657 player) {
      return this.get(player) != null;
   }

   public boolean shouldAttack(class_1657 player) {
      return !this.isFriend(player) || this.attack;
   }

   public int count() {
      return this.friends.size();
   }

   @NotNull
   public Iterator<Friend> iterator() {
      return this.friends.iterator();
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      class_2499 friendsTag = new class_2499();
      Iterator var3 = this.friends.iterator();

      while(var3.hasNext()) {
         Friend friend = (Friend)var3.next();
         friendsTag.add(friend.toTag());
      }

      tag.method_10566("friends", friendsTag);
      tag.method_10566("color", this.color.toTag());
      tag.method_10556("attack", this.attack);
      return tag;
   }

   public Friends fromTag(class_2487 tag) {
      this.friends = NbtUtils.listFromTag(tag.method_10554("friends", 10), (tag1) -> {
         return new Friend((class_2487)tag1);
      });
      if (tag.method_10545("color")) {
         this.color.fromTag(tag.method_10562("color"));
      }

      this.attack = tag.method_10545("attack") && tag.method_10577("attack");
      return this;
   }
}
