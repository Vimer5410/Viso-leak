package meteordevelopment.meteorclient.systems.friends;

import java.util.Objects;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import net.minecraft.class_1657;
import net.minecraft.class_2487;

public class Friend implements ISerializable<Friend> {
   public String name;

   public Friend(String name) {
      this.name = name;
   }

   public Friend(class_1657 player) {
      this(player.method_5820());
   }

   public Friend(class_2487 tag) {
      this.fromTag(tag);
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10582("name", this.name);
      return tag;
   }

   public Friend fromTag(class_2487 tag) {
      this.name = tag.method_10558("name");
      return this;
   }

   public boolean equals(Object o) {
      if (this == o) {
         return true;
      } else if (o != null && this.getClass() == o.getClass()) {
         Friend friend = (Friend)o;
         return Objects.equals(this.name, friend.name);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.name});
   }
}
