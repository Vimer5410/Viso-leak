package meteordevelopment.meteorclient.systems.macros;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

public class Macro implements ISerializable<Macro> {
   public String name = "";
   public List<String> messages = new ArrayList(1);
   public Keybind keybind = Keybind.none();

   public void addMessage(String command) {
      this.messages.add(command);
   }

   public void removeMessage(int i) {
      this.messages.remove(i);
   }

   public boolean onAction(boolean isKey, int value) {
      if (this.keybind.matches(isKey, value) && MeteorClient.mc.field_1755 == null) {
         Iterator var3 = this.messages.iterator();

         while(var3.hasNext()) {
            String command = (String)var3.next();
            MeteorClient.mc.field_1724.method_3142(command);
         }

         return true;
      } else {
         return false;
      }
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10582("name", this.name);
      tag.method_10566("keybind", this.keybind.toTag());
      class_2499 messagesTag = new class_2499();
      Iterator var3 = this.messages.iterator();

      while(var3.hasNext()) {
         String message = (String)var3.next();
         messagesTag.add(class_2519.method_23256(message));
      }

      tag.method_10566("messages", messagesTag);
      return tag;
   }

   public Macro fromTag(class_2487 tag) {
      this.name = tag.method_10558("name");
      if (tag.method_10545("key")) {
         this.keybind.set(true, tag.method_10550("key"));
      } else {
         this.keybind.fromTag(tag.method_10562("keybind"));
      }

      this.messages = NbtUtils.listFromTag(tag.method_10554("messages", 8), class_2520::method_10714);
      return this;
   }

   public boolean equals(Object o) {
      if (this == o) {
         return true;
      } else if (o != null && this.getClass() == o.getClass()) {
         Macro macro = (Macro)o;
         return Objects.equals(this.name, macro.name);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.name});
   }
}
