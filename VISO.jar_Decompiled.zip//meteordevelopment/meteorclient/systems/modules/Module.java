package meteordevelopment.meteorclient.systems.modules;

import java.util.Objects;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.settings.Settings;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import org.jetbrains.annotations.NotNull;

public abstract class Module implements ISerializable<Module>, Comparable<Module> {
   protected final class_310 mc = class_310.method_1551();
   public final Category category;
   public final String name;
   public final String title;
   public final String description;
   public final Color color;
   public final Settings settings = new Settings();
   private boolean active;
   public boolean serialize = true;
   public boolean runInMainMenu = false;
   public boolean autoSubscribe = true;
   public final Keybind keybind = Keybind.none();
   public boolean toggleOnBindRelease = false;

   public Module(Category category, String name, String description) {
      this.category = category;
      this.name = name;
      this.title = Utils.nameToTitle(name);
      this.description = description;
      this.color = Color.fromHsv(Utils.random(0.0D, 360.0D), 0.35D, 1.0D);
   }

   public WWidget getWidget(GuiTheme theme) {
      return null;
   }

   public void onActivate() {
   }

   public void onDeactivate() {
   }

   public void toggle() {
      if (!this.active) {
         this.active = true;
         Modules.get().addActive(this);
         this.settings.onActivated();
         if (this.runInMainMenu || Utils.canUpdate()) {
            if (this.autoSubscribe) {
               MeteorClient.EVENT_BUS.subscribe((Object)this);
            }

            this.onActivate();
         }
      } else {
         if (this.runInMainMenu || Utils.canUpdate()) {
            if (this.autoSubscribe) {
               MeteorClient.EVENT_BUS.unsubscribe((Object)this);
            }

            this.onDeactivate();
         }

         this.active = false;
         Modules.get().removeActive(this);
      }

   }

   public void sendToggledMsg() {
      if ((Boolean)Config.get().chatFeedback.get()) {
         ChatUtils.forceNextPrefixClass(this.getClass());
         ChatUtils.sendMsg(this.hashCode(), class_124.field_1080, "Toggled (highlight)%s(default) %s(default).", this.title, this.isActive() ? class_124.field_1060 + "on" : class_124.field_1061 + "off");
      }

   }

   public void info(class_2561 message) {
      ChatUtils.forceNextPrefixClass(this.getClass());
      ChatUtils.sendMsg(this.title, message);
   }

   public void info(String message, Object... args) {
      ChatUtils.forceNextPrefixClass(this.getClass());
      ChatUtils.info(this.title, message, args);
   }

   public void warning(String message, Object... args) {
      ChatUtils.forceNextPrefixClass(this.getClass());
      ChatUtils.warning(this.title, message, args);
   }

   public void error(String message, Object... args) {
      ChatUtils.forceNextPrefixClass(this.getClass());
      ChatUtils.error(this.title, message, args);
   }

   public boolean isActive() {
      return this.active;
   }

   public String getInfoString() {
      return null;
   }

   public class_2487 toTag() {
      if (!this.serialize) {
         return null;
      } else {
         class_2487 tag = new class_2487();
         tag.method_10582("name", this.name);
         tag.method_10566("keybind", this.keybind.toTag());
         tag.method_10556("toggleOnKeyRelease", this.toggleOnBindRelease);
         tag.method_10566("settings", this.settings.toTag());
         tag.method_10556("active", this.active);
         return tag;
      }
   }

   public Module fromTag(class_2487 tag) {
      if (tag.method_10545("key")) {
         this.keybind.set(true, tag.method_10550("key"));
      } else {
         this.keybind.fromTag(tag.method_10562("keybind"));
      }

      this.toggleOnBindRelease = tag.method_10577("toggleOnKeyRelease");
      class_2520 settingsTag = tag.method_10580("settings");
      if (settingsTag instanceof class_2487) {
         this.settings.fromTag((class_2487)settingsTag);
      }

      boolean active = tag.method_10577("active");
      if (active != this.isActive()) {
         this.toggle();
      }

      return this;
   }

   public boolean equals(Object o) {
      if (this == o) {
         return true;
      } else if (o != null && this.getClass() == o.getClass()) {
         Module module = (Module)o;
         return Objects.equals(this.name, module.name);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.name});
   }

   public int compareTo(@NotNull Module o) {
      return this.name.compareTo(o.name);
   }
}
