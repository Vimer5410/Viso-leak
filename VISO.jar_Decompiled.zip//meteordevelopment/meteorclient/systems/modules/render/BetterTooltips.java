package meteordevelopment.meteorclient.systems.modules.render;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.io.IOException;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.game.ItemStackTooltipEvent;
import meteordevelopment.meteorclient.events.render.TooltipDataEvent;
import meteordevelopment.meteorclient.mixin.EntityAccessor;
import meteordevelopment.meteorclient.mixin.EntityBucketItemAccessor;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.ByteCountDataOutput;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.EChestMemory;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.tooltip.BannerTooltipComponent;
import meteordevelopment.meteorclient.utils.tooltip.BookTooltipComponent;
import meteordevelopment.meteorclient.utils.tooltip.ContainerTooltipComponent;
import meteordevelopment.meteorclient.utils.tooltip.EntityTooltipComponent;
import meteordevelopment.meteorclient.utils.tooltip.MapTooltipComponent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1262;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1745;
import net.minecraft.class_1746;
import net.minecraft.class_1767;
import net.minecraft.class_1785;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1806;
import net.minecraft.class_1819;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_2582;
import net.minecraft.class_2585;
import net.minecraft.class_2588;
import net.minecraft.class_4174;
import net.minecraft.class_5250;
import net.minecraft.class_5761;
import net.minecraft.class_2561.class_2562;
import net.minecraft.class_2582.class_3750;

public class BetterTooltips extends Module {
   public static final Color ECHEST_COLOR = new Color(0, 50, 50);
   private final SettingGroup sgGeneral;
   private final SettingGroup sgPreviews;
   private final SettingGroup sgOther;
   private final Setting<BetterTooltips.DisplayWhen> displayWhen;
   private final Setting<Keybind> keybind;
   private final Setting<Boolean> middleClickOpen;
   private final Setting<Boolean> shulkers;
   private final Setting<Boolean> shulkerCompactTooltip;
   public final Setting<Boolean> echest;
   private final Setting<Boolean> maps;
   public final Setting<Double> mapsScale;
   private final Setting<Boolean> books;
   private final Setting<Boolean> banners;
   private final Setting<Boolean> entities;
   public final Setting<Boolean> byteSize;
   private final Setting<Boolean> statusEffects;
   private final Setting<Boolean> beehive;

   public BetterTooltips() {
      super(Categories.Render, "better-tooltips", "Displays more useful tooltips for certain items.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgPreviews = this.settings.createGroup("Previews");
      this.sgOther = this.settings.createGroup("Other");
      this.displayWhen = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("display-when")).description("When to display previews.")).defaultValue(BetterTooltips.DisplayWhen.Keybind)).build());
      this.keybind = this.sgGeneral.add(((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder()).name("keybind")).description("The bind for keybind mode.")).defaultValue(Keybind.fromKey(342))).visible(() -> {
         return this.displayWhen.get() == BetterTooltips.DisplayWhen.Keybind;
      })).build());
      this.middleClickOpen = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("middle-click-open")).description("Opens a GUI window with the inventory of the storage block when you middle click the item.")).defaultValue(true)).build());
      this.shulkers = this.sgPreviews.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("containers")).description("Shows a preview of a containers when hovering over it in an inventory.")).defaultValue(true)).build());
      SettingGroup var10001 = this.sgPreviews;
      BoolSetting.Builder var10002 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("compact-shulker-tooltip")).description("Compacts the lines of the shulker tooltip.")).defaultValue(true);
      Setting var10003 = this.shulkers;
      Objects.requireNonNull(var10003);
      this.shulkerCompactTooltip = var10001.add(((BoolSetting.Builder)var10002.visible(var10003::get)).build());
      this.echest = this.sgPreviews.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("echests")).description("Shows a preview of your echest when hovering over it in an inventory.")).defaultValue(true)).build());
      this.maps = this.sgPreviews.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("maps")).description("Shows a preview of a map when hovering over it in an inventory.")).defaultValue(true)).build());
      var10001 = this.sgPreviews;
      DoubleSetting.Builder var1 = ((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("map-scale")).description("The scale of the map preview.")).defaultValue(1.0D).min(0.001D).sliderMax(1.0D);
      var10003 = this.maps;
      Objects.requireNonNull(var10003);
      this.mapsScale = var10001.add(((DoubleSetting.Builder)var1.visible(var10003::get)).build());
      this.books = this.sgPreviews.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("books")).description("Shows contents of a book when hovering over it in an inventory.")).defaultValue(true)).build());
      this.banners = this.sgPreviews.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("banners")).description("Shows banners' patterns when hovering over it in an inventory. Also works with shields.")).defaultValue(true)).build());
      this.entities = this.sgPreviews.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("entities")).description("Shows entities in buckets when hovering over it in an inventory.")).defaultValue(true)).build());
      this.byteSize = this.sgOther.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("byte-size")).description("Displays an item's size in bytes in the tooltip.")).defaultValue(true)).build());
      this.statusEffects = this.sgOther.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("status-effects")).description("Adds list of status effects to tooltips of food items.")).defaultValue(true)).build());
      this.beehive = this.sgOther.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("beehive")).description("Displays information about a beehive or bee nest.")).defaultValue(true)).build());
   }

   @EventHandler
   private void appendTooltip(ItemStackTooltipEvent event) {
      class_2487 tag;
      int i;
      if ((Boolean)this.statusEffects.get()) {
         if (event.itemStack.method_7909() == class_1802.field_8766) {
            tag = event.itemStack.method_7969();
            if (tag != null) {
               class_2499 effects = tag.method_10554("Effects", 10);
               if (effects != null) {
                  for(i = 0; i < effects.size(); ++i) {
                     class_2487 effectTag = effects.method_10602(i);
                     byte effectId = effectTag.method_10571("EffectId");
                     int effectDuration = effectTag.method_10545("EffectDuration") ? effectTag.method_10550("EffectDuration") : 160;
                     class_1293 effect = new class_1293(class_1291.method_5569(effectId), effectDuration, 0);
                     event.list.add(1, this.getStatusText(effect));
                  }
               }
            }
         } else if (event.itemStack.method_7909().method_19263()) {
            class_4174 food = event.itemStack.method_7909().method_19264();
            if (food != null) {
               food.method_19235().forEach((e) -> {
                  class_1293 effect = (class_1293)e.getFirst();
                  event.list.add(1, this.getStatusText(effect));
               });
            }
         }
      }

      if ((Boolean)this.beehive.get() && (event.itemStack.method_7909() == class_1802.field_20416 || event.itemStack.method_7909() == class_1802.field_20415)) {
         tag = event.itemStack.method_7969();
         if (tag != null) {
            class_2487 blockStateTag = tag.method_10562("BlockStateTag");
            if (blockStateTag != null) {
               i = blockStateTag.method_10550("honey_level");
               event.list.add(1, new class_2585(String.format("%sHoney level: %s%d%s.", class_124.field_1080, class_124.field_1054, i, class_124.field_1080)));
            }

            class_2487 blockEntityTag = tag.method_10562("BlockEntityTag");
            if (blockEntityTag != null) {
               class_2499 beesTag = blockEntityTag.method_10554("Bees", 10);
               event.list.add(1, new class_2585(String.format("%sBees: %s%d%s.", class_124.field_1080, class_124.field_1054, beesTag.size(), class_124.field_1080)));
            }
         }
      }

      if ((Boolean)this.byteSize.get()) {
         try {
            event.itemStack.method_7953(new class_2487()).method_10713(ByteCountDataOutput.INSTANCE);
            int byteCount = ByteCountDataOutput.INSTANCE.getCount();
            ByteCountDataOutput.INSTANCE.reset();
            String count;
            if (byteCount >= 1024) {
               count = String.format("%.2f kb", (float)byteCount / 1024.0F);
            } else {
               count = String.format("%d bytes", byteCount);
            }

            event.list.add((new class_2585(count)).method_27692(class_124.field_1080));
         } catch (IOException var9) {
            var9.printStackTrace();
         }
      }

      if (Utils.hasItems(event.itemStack) && (Boolean)this.shulkers.get() && !this.previewShulkers() || event.itemStack.method_7909() == class_1802.field_8466 && (Boolean)this.echest.get() && !this.previewEChest() || event.itemStack.method_7909() == class_1802.field_8204 && (Boolean)this.maps.get() && !this.previewMaps() || event.itemStack.method_7909() == class_1802.field_8674 && (Boolean)this.books.get() && !this.previewBooks() || event.itemStack.method_7909() == class_1802.field_8360 && (Boolean)this.books.get() && !this.previewBooks() || event.itemStack.method_7909() instanceof class_1785 && (Boolean)this.entities.get() && !this.previewEntities() || event.itemStack.method_7909() instanceof class_1746 && (Boolean)this.banners.get() && !this.previewBanners() || event.itemStack.method_7909() instanceof class_1745 && (Boolean)this.banners.get() && !this.previewBanners() || event.itemStack.method_7909() == class_1802.field_8255 && (Boolean)this.banners.get() && !this.previewBanners()) {
         event.list.add(new class_2585(""));
         event.list.add(new class_2585("Hold " + class_124.field_1054 + this.keybind + class_124.field_1070 + " to preview"));
      }

   }

   @EventHandler
   private void getTooltipData(TooltipDataEvent event) {
      if (Utils.hasItems(event.itemStack) && this.previewShulkers()) {
         class_2487 compoundTag = event.itemStack.method_7941("BlockEntityTag");
         class_2371<class_1799> itemStacks = class_2371.method_10213(27, class_1799.field_8037);
         class_1262.method_5429(compoundTag, itemStacks);
         event.tooltipData = new ContainerTooltipComponent(itemStacks, Utils.getShulkerColor(event.itemStack));
      } else if (event.itemStack.method_7909() == class_1802.field_8466 && this.previewEChest()) {
         event.tooltipData = new ContainerTooltipComponent(EChestMemory.ITEMS, ECHEST_COLOR);
      } else if (event.itemStack.method_7909() == class_1802.field_8204 && this.previewMaps()) {
         Integer mapId = class_1806.method_8003(event.itemStack);
         if (mapId != null) {
            event.tooltipData = new MapTooltipComponent(mapId);
         }
      } else if ((event.itemStack.method_7909() == class_1802.field_8674 || event.itemStack.method_7909() == class_1802.field_8360) && this.previewBooks()) {
         class_2561 page = this.getFirstPage(event.itemStack);
         if (page != null) {
            event.tooltipData = new BookTooltipComponent(page);
         }
      } else if (event.itemStack.method_7909() instanceof class_1746 && this.previewBanners()) {
         event.tooltipData = new BannerTooltipComponent(event.itemStack);
      } else {
         class_1792 var4 = event.itemStack.method_7909();
         if (var4 instanceof class_1745) {
            class_1745 patternItem = (class_1745)var4;
            if (this.previewBanners()) {
               event.tooltipData = new BannerTooltipComponent(this.createBannerFromPattern(patternItem.method_7704()));
               return;
            }
         }

         if (event.itemStack.method_7909() == class_1802.field_8255 && this.previewBanners()) {
            class_1799 banner = this.createBannerFromShield(event.itemStack);
            if (banner != null) {
               event.tooltipData = new BannerTooltipComponent(banner);
            }
         } else {
            var4 = event.itemStack.method_7909();
            if (var4 instanceof class_1785) {
               class_1785 bucketItem = (class_1785)var4;
               if (this.previewEntities()) {
                  class_1299<?> type = ((EntityBucketItemAccessor)bucketItem).getEntityType();
                  class_1297 entity = type.method_5883(this.mc.field_1687);
                  if (entity != null) {
                     ((class_5761)entity).method_35170(event.itemStack.method_7948());
                     ((EntityAccessor)entity).setInWater(true);
                     event.tooltipData = new EntityTooltipComponent(entity);
                  }
               }
            }
         }
      }

   }

   public void applyCompactShulkerTooltip(class_1799 stack, List<class_2561> tooltip) {
      class_2487 tag = stack.method_7941("BlockEntityTag");
      if (tag != null) {
         if (tag.method_10573("LootTable", 8)) {
            tooltip.add(new class_2585("???????"));
         }

         if (tag.method_10573("Items", 9)) {
            class_2371<class_1799> items = class_2371.method_10213(27, class_1799.field_8037);
            class_1262.method_5429(tag, items);
            Object2IntMap<class_1792> counts = new Object2IntOpenHashMap();
            Iterator var6 = items.iterator();

            while(var6.hasNext()) {
               class_1799 item = (class_1799)var6.next();
               if (!item.method_7960()) {
                  int count = counts.getInt(item.method_7909());
                  counts.put(item.method_7909(), count + item.method_7947());
               }
            }

            counts.keySet().stream().sorted(Comparator.comparingInt((value) -> {
               return -counts.getInt(value);
            })).limit(5L).forEach((itemx) -> {
               class_5250 mutableText = itemx.method_7848().method_27661();
               mutableText.method_10852((new class_2585(" x")).method_27693(String.valueOf(counts.getInt(itemx))).method_27692(class_124.field_1080));
               tooltip.add(mutableText);
            });
            if (counts.size() > 5) {
               tooltip.add((new class_2588("container.shulkerBox.more", new Object[]{counts.size() - 5})).method_27692(class_124.field_1056));
            }
         }
      }

   }

   private class_5250 getStatusText(class_1293 effect) {
      class_5250 text = new class_2588(effect.method_5586());
      if (effect.method_5578() != 0) {
         text.method_27693(String.format(" %d (%s)", effect.method_5578() + 1, class_1292.method_5577(effect, 1.0F)));
      } else {
         text.method_27693(String.format(" (%s)", class_1292.method_5577(effect, 1.0F)));
      }

      return effect.method_5579().method_5573() ? text.method_27692(class_124.field_1078) : text.method_27692(class_124.field_1061);
   }

   private class_2561 getFirstPage(class_1799 stack) {
      class_2487 tag = stack.method_7969();
      if (tag == null) {
         return null;
      } else {
         class_2499 ltag = tag.method_10554("pages", 8);
         if (ltag.size() < 1) {
            return null;
         } else {
            return (class_2561)(stack.method_7909() == class_1802.field_8674 ? new class_2585(ltag.method_10608(0)) : class_2562.method_10873(ltag.method_10608(0)));
         }
      }
   }

   private class_1799 createBannerFromPattern(class_2582 pattern) {
      class_1799 itemStack = new class_1799(class_1802.field_8617);
      class_2487 nbt = itemStack.method_7911("BlockEntityTag");
      class_2499 listNbt = (new class_3750()).method_16376(class_2582.field_11834, class_1767.field_7963).method_16376(pattern, class_1767.field_7952).method_16375();
      nbt.method_10566("Patterns", listNbt);
      return itemStack;
   }

   private class_1799 createBannerFromShield(class_1799 item) {
      if (item.method_7985() && item.method_7969().method_10545("BlockEntityTag") && item.method_7969().method_10562("BlockEntityTag").method_10545("Base")) {
         class_2499 listNbt = (new class_3750()).method_16376(class_2582.field_11834, class_1819.method_8013(item)).method_16375();
         class_2487 nbt = item.method_7911("BlockEntityTag");
         class_1799 bannerItem = new class_1799(class_1802.field_8617);
         class_2487 bannerTag = bannerItem.method_7911("BlockEntityTag");
         bannerTag.method_10566("Patterns", listNbt);
         if (!nbt.method_10545("Patterns")) {
            return bannerItem;
         } else {
            class_2499 shieldPatterns = nbt.method_10554("Patterns", 10);
            listNbt.addAll(shieldPatterns);
            return bannerItem;
         }
      } else {
         return null;
      }
   }

   public boolean middleClickOpen() {
      return this.isActive() && (Boolean)this.middleClickOpen.get();
   }

   public boolean previewShulkers() {
      return this.isActive() && this.isPressed() && (Boolean)this.shulkers.get();
   }

   public boolean shulkerCompactTooltip() {
      return this.isActive() && (Boolean)this.shulkerCompactTooltip.get();
   }

   private boolean previewEChest() {
      return this.isPressed() && (Boolean)this.echest.get();
   }

   private boolean previewMaps() {
      return this.isPressed() && (Boolean)this.maps.get();
   }

   private boolean previewBooks() {
      return this.isPressed() && (Boolean)this.books.get();
   }

   private boolean previewBanners() {
      return this.isPressed() && (Boolean)this.banners.get();
   }

   private boolean previewEntities() {
      return this.isPressed() && (Boolean)this.entities.get();
   }

   private boolean isPressed() {
      return ((Keybind)this.keybind.get()).isPressed() && this.displayWhen.get() == BetterTooltips.DisplayWhen.Keybind || this.displayWhen.get() == BetterTooltips.DisplayWhen.Always;
   }

   public static enum DisplayWhen {
      Keybind,
      Always;

      // $FF: synthetic method
      private static BetterTooltips.DisplayWhen[] $values() {
         return new BetterTooltips.DisplayWhen[]{Keybind, Always};
      }
   }
}
