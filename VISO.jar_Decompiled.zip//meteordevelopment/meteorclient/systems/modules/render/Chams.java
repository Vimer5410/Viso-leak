package meteordevelopment.meteorclient.systems.modules.render;

import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import java.util.Objects;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.EntityShaders;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2960;

public class Chams extends Module {
   private final SettingGroup sgThroughWalls;
   private final SettingGroup sgPlayers;
   private final SettingGroup sgCrystals;
   private final SettingGroup sgHand;
   public final Setting<Object2BooleanMap<class_1299<?>>> entities;
   public final Setting<Chams.Shader> shader;
   public final Setting<Boolean> ignoreSelfDepth;
   public final Setting<Boolean> players;
   public final Setting<Boolean> ignoreSelf;
   public final Setting<Double> playersScale;
   public final Setting<Boolean> playersTexture;
   public final Setting<SettingColor> playersColor;
   public final Setting<Boolean> crystals;
   public final Setting<Double> crystalsScale;
   public final Setting<Double> crystalsBounce;
   public final Setting<Double> crystalsRotationSpeed;
   public final Setting<Boolean> crystalsTexture;
   public final Setting<Boolean> renderCore;
   public final Setting<SettingColor> crystalsCoreColor;
   public final Setting<Boolean> renderFrame1;
   public final Setting<SettingColor> crystalsFrame1Color;
   public final Setting<Boolean> renderFrame2;
   public final Setting<SettingColor> crystalsFrame2Color;
   public final Setting<Boolean> hand;
   public final Setting<Boolean> handTexture;
   public final Setting<SettingColor> handColor;
   public static final class_2960 BLANK = new class_2960("meteor-client", "textures/blank.png");

   public Chams() {
      super(Categories.Render, "chams", "Tweaks rendering of entities.");
      this.sgThroughWalls = this.settings.createGroup("Through Walls");
      this.sgPlayers = this.settings.createGroup("Players");
      this.sgCrystals = this.settings.createGroup("Crystals");
      this.sgHand = this.settings.createGroup("Hand");
      this.entities = this.sgThroughWalls.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder()).name("entities")).description("Select entities to show through walls.")).defaultValue(class_1299.field_6097).build());
      this.shader = this.sgThroughWalls.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shader")).description("Renders a shader instead of the entities.")).defaultValue(Chams.Shader.Liquid1)).onModuleActivated((shaderSetting) -> {
         if (shaderSetting.get() != Chams.Shader.None) {
            EntityShaders.initOverlay(((Chams.Shader)shaderSetting.get()).shaderName);
         }

      })).onChanged((value) -> {
         if (value != Chams.Shader.None) {
            EntityShaders.initOverlay(value.shaderName);
         }

      })).build());
      this.ignoreSelfDepth = this.sgThroughWalls.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ignore-self")).description("Ignores yourself drawing the player.")).defaultValue(true)).build());
      this.players = this.sgPlayers.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("players")).description("Enables model tweaks for players.")).defaultValue(true)).build());
      SettingGroup var10001 = this.sgPlayers;
      BoolSetting.Builder var10002 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ignore-self")).description("Ignores yourself when tweaking player models.")).defaultValue(true);
      Setting var10003 = this.players;
      Objects.requireNonNull(var10003);
      this.ignoreSelf = var10001.add(((BoolSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgPlayers;
      DoubleSetting.Builder var1 = ((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("Players scale.")).defaultValue(1.0D).min(0.0D);
      var10003 = this.players;
      Objects.requireNonNull(var10003);
      this.playersScale = var10001.add(((DoubleSetting.Builder)var1.visible(var10003::get)).build());
      var10001 = this.sgPlayers;
      var10002 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("texture")).description("Enables player model textures.")).defaultValue(false);
      var10003 = this.players;
      Objects.requireNonNull(var10003);
      this.playersTexture = var10001.add(((BoolSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgPlayers;
      ColorSetting.Builder var2 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("color")).description("The color of player models.")).defaultValue(new SettingColor(0, 255, 255, 100));
      var10003 = this.players;
      Objects.requireNonNull(var10003);
      this.playersColor = var10001.add(((ColorSetting.Builder)var2.visible(var10003::get)).build());
      this.crystals = this.sgCrystals.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("crystals")).description("Enables model tweaks for end crystals.")).defaultValue(true)).build());
      var10001 = this.sgCrystals;
      var1 = ((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("Crystal scale.")).defaultValue(0.6D).min(0.0D);
      var10003 = this.crystals;
      Objects.requireNonNull(var10003);
      this.crystalsScale = var10001.add(((DoubleSetting.Builder)var1.visible(var10003::get)).build());
      var10001 = this.sgCrystals;
      var1 = ((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("bounce")).description("How high crystals bounce.")).defaultValue(0.3D).min(0.0D);
      var10003 = this.crystals;
      Objects.requireNonNull(var10003);
      this.crystalsBounce = var10001.add(((DoubleSetting.Builder)var1.visible(var10003::get)).build());
      var10001 = this.sgCrystals;
      var1 = ((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("rotation-speed")).description("Multiplies the roation speed of the crystal.")).defaultValue(3.0D).min(0.0D);
      var10003 = this.crystals;
      Objects.requireNonNull(var10003);
      this.crystalsRotationSpeed = var10001.add(((DoubleSetting.Builder)var1.visible(var10003::get)).build());
      var10001 = this.sgCrystals;
      var10002 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("texture")).description("Whether to render crystal model textures.")).defaultValue(false);
      var10003 = this.crystals;
      Objects.requireNonNull(var10003);
      this.crystalsTexture = var10001.add(((BoolSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgCrystals;
      var10002 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("render-core")).description("Enables rendering of the core of the crystal.")).defaultValue(false);
      var10003 = this.crystals;
      Objects.requireNonNull(var10003);
      this.renderCore = var10001.add(((BoolSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgCrystals;
      var2 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("core-color")).description("The color of end crystal models.")).defaultValue(new SettingColor(0, 255, 255, 100));
      var10003 = this.renderCore;
      Objects.requireNonNull(var10003);
      this.crystalsCoreColor = var10001.add(((ColorSetting.Builder)var2.visible(var10003::get)).build());
      var10001 = this.sgCrystals;
      var10002 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("render-inner-frame")).description("Enables rendering of the frame of the crystal.")).defaultValue(true);
      var10003 = this.crystals;
      Objects.requireNonNull(var10003);
      this.renderFrame1 = var10001.add(((BoolSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgCrystals;
      var2 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("inner-frame-color")).description("The color of end crystal models.")).defaultValue(new SettingColor(0, 255, 255, 100));
      var10003 = this.renderFrame1;
      Objects.requireNonNull(var10003);
      this.crystalsFrame1Color = var10001.add(((ColorSetting.Builder)var2.visible(var10003::get)).build());
      var10001 = this.sgCrystals;
      var10002 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("render-outer-frame")).description("Enables rendering of the frame of the crystal.")).defaultValue(true);
      var10003 = this.crystals;
      Objects.requireNonNull(var10003);
      this.renderFrame2 = var10001.add(((BoolSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgCrystals;
      var2 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("outer-frame-color")).description("The color of end crystal models.")).defaultValue(new SettingColor(0, 255, 255, 100));
      var10003 = this.renderFrame2;
      Objects.requireNonNull(var10003);
      this.crystalsFrame2Color = var10001.add(((ColorSetting.Builder)var2.visible(var10003::get)).build());
      this.hand = this.sgHand.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("enabled")).description("Enables tweaks of hand rendering.")).defaultValue(true)).build());
      this.handTexture = this.sgHand.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("texture")).description("Whether to render hand textures.")).defaultValue(false)).build());
      this.handColor = this.sgHand.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("hand-color")).description("The color of your hand.")).defaultValue(new SettingColor(0, 255, 255, 100))).build());
   }

   public boolean shouldRender(class_1297 entity) {
      return this.isActive() && !this.isShader() && ((Object2BooleanMap)this.entities.get()).getBoolean(entity.method_5864()) && (entity != this.mc.field_1724 || (Boolean)this.ignoreSelfDepth.get());
   }

   public boolean isShader() {
      return this.isActive() && this.shader.get() != Chams.Shader.None;
   }

   public static enum Shader {
      Liquid1("liquid"),
      None((String)null);

      public final String shaderName;

      private Shader(String shaderName) {
         this.shaderName = shaderName;
      }

      // $FF: synthetic method
      private static Chams.Shader[] $values() {
         return new Chams.Shader[]{Liquid1, None};
      }
   }
}
