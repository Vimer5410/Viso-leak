package meteordevelopment.meteorclient.systems.modules.render;

import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnchantmentListSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.NameProtect;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1533;
import net.minecraft.class_1541;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1934;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class Nametags extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgPlayers;
   private final SettingGroup sgItems;
   private final Setting<Object2BooleanMap<class_1299<?>>> entities;
   private final Setting<Double> scale;
   private final Setting<Boolean> yourself;
   private final Setting<SettingColor> background;
   private final Setting<SettingColor> names;
   private final Setting<Boolean> culling;
   private final Setting<Double> maxCullRange;
   private final Setting<Integer> maxCullCount;
   private final Setting<Boolean> displayItems;
   private final Setting<Double> itemSpacing;
   private final Setting<Boolean> ignoreEmpty;
   private final Setting<Boolean> displayItemEnchants;
   private final Setting<Nametags.Position> enchantPos;
   private final Setting<Integer> enchantLength;
   private final Setting<List<class_1887>> ignoredEnchantments;
   private final Setting<Double> enchantTextScale;
   private final Setting<Boolean> displayGameMode;
   private final Setting<Boolean> displayPing;
   private final Setting<Boolean> displayDistance;
   private final Setting<Boolean> itemCount;
   private final Color WHITE;
   private final Color RED;
   private final Color AMBER;
   private final Color GREEN;
   private final Color GOLD;
   private final Color GREY;
   private final Color BLUE;
   private final Vec3 pos;
   private final double[] itemWidths;
   private final Map<class_1887, Integer> enchantmentsToShowScale;
   private final List<class_1297> entityList;

   public Nametags() {
      super(Categories.Render, "nametags", "Displays customizable nametags above players.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgPlayers = this.settings.createGroup("Players");
      this.sgItems = this.settings.createGroup("Items");
      this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder()).name("entities")).description("Select entities to draw nametags on.")).defaultValue(class_1299.field_6097, class_1299.field_6052).build());
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale of the nametag.")).defaultValue(1.5D).min(0.1D).build());
      this.yourself = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("self")).description("Displays a nametag on your player if you're in Freecam.")).defaultValue(true)).build());
      this.background = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("background-color")).description("The color of the nametag background.")).defaultValue(new SettingColor(0, 0, 0, 75))).build());
      this.names = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("primary-color")).description("The color of the nametag names.")).defaultValue(new SettingColor())).build());
      this.culling = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("culling")).description("Only render a certain number of nametags at a certain distance.")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      DoubleSetting.Builder var10002 = ((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("culling-range")).description("Only render nametags within this distance of your player.")).defaultValue(20.0D).min(0.0D).sliderMax(200.0D);
      Setting var10003 = this.culling;
      Objects.requireNonNull(var10003);
      this.maxCullRange = var10001.add(((DoubleSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgGeneral;
      IntSetting.Builder var1 = ((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("culling-count")).description("Only render this many nametags.")).defaultValue(50)).min(1).sliderRange(1, 100);
      var10003 = this.culling;
      Objects.requireNonNull(var10003);
      this.maxCullCount = var10001.add(((IntSetting.Builder)var1.visible(var10003::get)).build());
      this.displayItems = this.sgPlayers.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("display-items")).description("Displays armor and hand items above the name tags.")).defaultValue(true)).build());
      var10001 = this.sgPlayers;
      var10002 = ((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("item-spacing")).description("The spacing between items.")).defaultValue(2.0D).range(0.0D, 10.0D);
      var10003 = this.displayItems;
      Objects.requireNonNull(var10003);
      this.itemSpacing = var10001.add(((DoubleSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgPlayers;
      BoolSetting.Builder var2 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ignore-empty-slots")).description("Doesn't add spacing where an empty item stack would be.")).defaultValue(true);
      var10003 = this.displayItems;
      Objects.requireNonNull(var10003);
      this.ignoreEmpty = var10001.add(((BoolSetting.Builder)var2.visible(var10003::get)).build());
      var10001 = this.sgPlayers;
      var2 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("display-enchants")).description("Displays item enchantments on the items.")).defaultValue(true);
      var10003 = this.displayItems;
      Objects.requireNonNull(var10003);
      this.displayItemEnchants = var10001.add(((BoolSetting.Builder)var2.visible(var10003::get)).build());
      var10001 = this.sgPlayers;
      EnumSetting.Builder var3 = (EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("enchantment-position")).description("Where the enchantments are rendered.")).defaultValue(Nametags.Position.Above);
      var10003 = this.displayItemEnchants;
      Objects.requireNonNull(var10003);
      this.enchantPos = var10001.add(((EnumSetting.Builder)var3.visible(var10003::get)).build());
      var10001 = this.sgPlayers;
      var1 = ((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("enchant-name-length")).description("The length enchantment names are trimmed to.")).defaultValue(3)).range(1, 5).sliderRange(1, 5);
      var10003 = this.displayItemEnchants;
      Objects.requireNonNull(var10003);
      this.enchantLength = var10001.add(((IntSetting.Builder)var1.visible(var10003::get)).build());
      var10001 = this.sgPlayers;
      EnchantmentListSetting.Builder var4 = (EnchantmentListSetting.Builder)((EnchantmentListSetting.Builder)(new EnchantmentListSetting.Builder()).name("ignored-enchantments")).description("The enchantments that aren't shown on nametags.");
      var10003 = this.displayItemEnchants;
      Objects.requireNonNull(var10003);
      this.ignoredEnchantments = var10001.add(((EnchantmentListSetting.Builder)var4.visible(var10003::get)).build());
      var10001 = this.sgPlayers;
      var10002 = ((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("enchant-text-scale")).description("The scale of the enchantment text.")).defaultValue(1.0D).range(0.1D, 2.0D).sliderRange(0.1D, 2.0D);
      var10003 = this.displayItemEnchants;
      Objects.requireNonNull(var10003);
      this.enchantTextScale = var10001.add(((DoubleSetting.Builder)var10002.visible(var10003::get)).build());
      this.displayGameMode = this.sgPlayers.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("gamemode")).description("Shows the player's GameMode.")).defaultValue(true)).build());
      this.displayPing = this.sgPlayers.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ping")).description("Shows the player's ping.")).defaultValue(true)).build());
      this.displayDistance = this.sgPlayers.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("distance")).description("Shows the distance between you and the player.")).defaultValue(true)).build());
      this.itemCount = this.sgItems.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("show-count")).description("Displays the number of items in the stack.")).defaultValue(true)).build());
      this.WHITE = new Color(255, 255, 255);
      this.RED = new Color(255, 25, 25);
      this.AMBER = new Color(255, 105, 25);
      this.GREEN = new Color(25, 252, 25);
      this.GOLD = new Color(232, 185, 35);
      this.GREY = new Color(150, 150, 150);
      this.BLUE = new Color(20, 170, 170);
      this.pos = new Vec3();
      this.itemWidths = new double[6];
      this.enchantmentsToShowScale = new HashMap();
      this.entityList = new ArrayList();
   }

   private static String ticksToTime(int ticks) {
      int s;
      if (ticks > 72000) {
         s = ticks / 20 / 3600;
         return s + " h";
      } else if (ticks > 1200) {
         s = ticks / 20 / 60;
         return s + " m";
      } else {
         s = ticks / 20;
         int ms = ticks % 20 / 2;
         return s + "." + ms + " s";
      }
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      this.entityList.clear();
      boolean freecamNotActive = !Modules.get().isActive(Freecam.class);
      class_243 cameraPos = this.mc.field_1773.method_19418().method_19326();
      Iterator var4 = this.mc.field_1687.method_18112().iterator();

      while(true) {
         class_1297 entity;
         class_1299 type;
         do {
            do {
               do {
                  if (!var4.hasNext()) {
                     this.entityList.sort(Comparator.comparing((e) -> {
                        return e.method_5707(cameraPos);
                     }));
                     return;
                  }

                  entity = (class_1297)var4.next();
                  type = entity.method_5864();
               } while(!((Object2BooleanMap)this.entities.get()).containsKey(type));
            } while(type == class_1299.field_6097 && (!(Boolean)this.yourself.get() || freecamNotActive) && entity == this.mc.field_1724);
         } while((Boolean)this.culling.get() && !(entity.method_19538().method_1022(cameraPos) < (Double)this.maxCullRange.get()));

         this.entityList.add(entity);
      }
   }

   @EventHandler
   private void onRender2D(Render2DEvent event) {
      int count = this.getRenderCount();

      for(int i = count - 1; i > -1; --i) {
         class_1297 entity = (class_1297)this.entityList.get(i);
         this.pos.set(entity, (double)event.tickDelta);
         this.pos.add(0.0D, this.getHeight(entity), 0.0D);
         class_1299<?> type = entity.method_5864();
         if (NametagUtils.to2D(this.pos, (Double)this.scale.get())) {
            if (type == class_1299.field_6097) {
               this.renderNametagPlayer((class_1657)entity);
            } else if (type == class_1299.field_6052) {
               this.renderNametagItem(((class_1542)entity).method_6983());
            } else if (type == class_1299.field_6043) {
               this.renderNametagItem(((class_1533)entity).method_6940());
            } else if (type == class_1299.field_6063) {
               this.renderTntNametag((class_1541)entity);
            } else if (entity instanceof class_1309) {
               this.renderGenericNametag((class_1309)entity);
            }
         }
      }

   }

   private int getRenderCount() {
      int count = (Boolean)this.culling.get() ? (Integer)this.maxCullCount.get() : this.entityList.size();
      count = class_3532.method_15340(count, 0, this.entityList.size());
      return count;
   }

   public String getInfoString() {
      return Integer.toString(this.getRenderCount());
   }

   private double getHeight(class_1297 entity) {
      double height = (double)entity.method_18381(entity.method_18376());
      if (entity.method_5864() != class_1299.field_6052 && entity.method_5864() != class_1299.field_6043) {
         height += 0.5D;
      } else {
         height += 0.2D;
      }

      return height;
   }

   private void renderNametagPlayer(class_1657 player) {
      TextRenderer text = TextRenderer.get();
      NametagUtils.begin(this.pos);
      class_1934 gm = EntityUtils.getGameMode(player);
      String gmText = "BOT";
      String var10000;
      if (gm != null) {
         switch(gm) {
         case field_9219:
            var10000 = "Sp";
            break;
         case field_9215:
            var10000 = "S";
            break;
         case field_9220:
            var10000 = "C";
            break;
         case field_9216:
            var10000 = "A";
            break;
         default:
            throw new IncompatibleClassChangeError();
         }

         gmText = var10000;
      }

      gmText = "[" + gmText + "] ";
      Color nameColor = PlayerUtils.getPlayerColor(player, (Color)this.names.get());
      String name;
      if (player == this.mc.field_1724) {
         name = ((NameProtect)Modules.get().get(NameProtect.class)).getName(player.method_5820());
      } else {
         name = player.method_5820();
      }

      name = name + " ";
      float absorption = player.method_6067();
      int health = Math.round(player.method_6032() + absorption);
      double healthPercentage = (double)((float)health / (player.method_6063() + absorption));
      String healthText = String.valueOf(health);
      Color healthColor;
      if (healthPercentage <= 0.333D) {
         healthColor = this.RED;
      } else if (healthPercentage <= 0.666D) {
         healthColor = this.AMBER;
      } else {
         healthColor = this.GREEN;
      }

      int ping = EntityUtils.getPing(player);
      String pingText = " [" + ping + "ms]";
      double dist = (double)Math.round(PlayerUtils.distanceToCamera(player) * 10.0D) / 10.0D;
      String distText = " " + dist + "m";
      double gmWidth = text.getWidth(gmText, true);
      double nameWidth = text.getWidth(name, true);
      double healthWidth = text.getWidth(healthText, true);
      double pingWidth = text.getWidth(pingText, true);
      double distWidth = text.getWidth(distText, true);
      double width = nameWidth + healthWidth;
      if ((Boolean)this.displayGameMode.get()) {
         width += gmWidth;
      }

      if ((Boolean)this.displayPing.get()) {
         width += pingWidth;
      }

      if ((Boolean)this.displayDistance.get()) {
         width += distWidth;
      }

      double widthHalf = width / 2.0D;
      double heightDown = text.getHeight(true);
      this.drawBg(-widthHalf, -heightDown, width, heightDown);
      text.beginBig();
      double hX = -widthHalf;
      double hY = -heightDown;
      if ((Boolean)this.displayGameMode.get()) {
         hX = text.render(gmText, hX, hY, this.GOLD, true);
      }

      hX = text.render(name, hX, hY, nameColor, true);
      hX = text.render(healthText, hX, hY, healthColor, true);
      if ((Boolean)this.displayPing.get()) {
         hX = text.render(pingText, hX, hY, this.BLUE, true);
      }

      if ((Boolean)this.displayDistance.get()) {
         text.render(distText, hX, hY, this.GREY, true);
      }

      text.end();
      if ((Boolean)this.displayItems.get()) {
         Arrays.fill(this.itemWidths, 0.0D);
         boolean hasItems = false;
         int maxEnchantCount = 0;

         for(int i = 0; i < 6; ++i) {
            class_1799 itemStack = this.getItem(player, i);
            if (this.itemWidths[i] == 0.0D && (!(Boolean)this.ignoreEmpty.get() || !itemStack.method_7960())) {
               this.itemWidths[i] = 32.0D + (Double)this.itemSpacing.get();
            }

            if (!itemStack.method_7960()) {
               hasItems = true;
            }

            if ((Boolean)this.displayItemEnchants.get()) {
               Map<class_1887, Integer> enchantments = class_1890.method_8222(itemStack);
               this.enchantmentsToShowScale.clear();
               Iterator var43 = enchantments.keySet().iterator();

               class_1887 enchantment;
               while(var43.hasNext()) {
                  enchantment = (class_1887)var43.next();
                  if (!((List)this.ignoredEnchantments.get()).contains(enchantment)) {
                     this.enchantmentsToShowScale.put(enchantment, (Integer)enchantments.get(enchantment));
                  }
               }

               String enchantName;
               for(var43 = this.enchantmentsToShowScale.keySet().iterator(); var43.hasNext(); this.itemWidths[i] = Math.max(this.itemWidths[i], text.getWidth(enchantName, true) / 2.0D)) {
                  enchantment = (class_1887)var43.next();
                  var10000 = Utils.getEnchantSimpleName(enchantment, (Integer)this.enchantLength.get());
                  enchantName = var10000 + " " + this.enchantmentsToShowScale.get(enchantment);
               }

               maxEnchantCount = Math.max(maxEnchantCount, this.enchantmentsToShowScale.size());
            }
         }

         double itemsHeight = (double)(hasItems ? 32 : 0);
         double itemWidthTotal = 0.0D;
         double[] var69 = this.itemWidths;
         int var71 = var69.length;

         for(int var46 = 0; var46 < var71; ++var46) {
            double w = var69[var46];
            itemWidthTotal += w;
         }

         double itemWidthHalf = itemWidthTotal / 2.0D;
         double y = -heightDown - 7.0D - itemsHeight;
         double x = -itemWidthHalf;

         for(int i = 0; i < 6; ++i) {
            class_1799 stack = this.getItem(player, i);
            RenderUtils.drawItem(stack, (int)x, (int)y, 2.0D, true);
            if (maxEnchantCount > 0 && (Boolean)this.displayItemEnchants.get()) {
               text.begin(0.5D * (Double)this.enchantTextScale.get(), false, true);
               Map<class_1887, Integer> enchantments = class_1890.method_8222(stack);
               Map<class_1887, Integer> enchantmentsToShow = new HashMap();
               Iterator var54 = enchantments.keySet().iterator();

               while(var54.hasNext()) {
                  class_1887 enchantment = (class_1887)var54.next();
                  if (!((List)this.ignoredEnchantments.get()).contains(enchantment)) {
                     enchantmentsToShow.put(enchantment, (Integer)enchantments.get(enchantment));
                  }
               }

               double aW = this.itemWidths[i];
               double enchantY = 0.0D;
               double var66;
               switch((Nametags.Position)this.enchantPos.get()) {
               case Above:
                  var66 = -((double)(enchantmentsToShow.size() + 1) * text.getHeight(true));
                  break;
               case OnTop:
                  var66 = (itemsHeight - (double)enchantmentsToShow.size() * text.getHeight(true)) / 2.0D;
                  break;
               default:
                  throw new IncompatibleClassChangeError();
               }

               double addY = var66;

               for(Iterator var62 = enchantmentsToShow.keySet().iterator(); var62.hasNext(); enchantY += text.getHeight(true)) {
                  class_1887 enchantment = (class_1887)var62.next();
                  var10000 = Utils.getEnchantSimpleName(enchantment, (Integer)this.enchantLength.get());
                  String enchantName = var10000 + " " + enchantmentsToShow.get(enchantment);
                  Color enchantColor = this.WHITE;
                  if (enchantment.method_8195()) {
                     enchantColor = this.RED;
                  }

                  switch((Nametags.Position)this.enchantPos.get()) {
                  case Above:
                     var66 = x + aW / 2.0D - text.getWidth(enchantName, true) / 2.0D;
                     break;
                  case OnTop:
                     var66 = x + (aW - text.getWidth(enchantName, true)) / 2.0D;
                     break;
                  default:
                     throw new IncompatibleClassChangeError();
                  }

                  double enchantX = var66;
                  text.render(enchantName, enchantX, y + addY + enchantY, enchantColor, true);
               }

               text.end();
            }

            x += this.itemWidths[i];
         }
      } else if ((Boolean)this.displayItemEnchants.get()) {
         this.displayItemEnchants.set(false);
      }

      NametagUtils.end();
   }

   private void renderNametagItem(class_1799 stack) {
      TextRenderer text = TextRenderer.get();
      NametagUtils.begin(this.pos);
      String name = stack.method_7964().getString();
      String count = " x" + stack.method_7947();
      double nameWidth = text.getWidth(name, true);
      double countWidth = text.getWidth(count, true);
      double heightDown = text.getHeight(true);
      double width = nameWidth;
      if ((Boolean)this.itemCount.get()) {
         width = nameWidth + countWidth;
      }

      double widthHalf = width / 2.0D;
      this.drawBg(-widthHalf, -heightDown, width, heightDown);
      text.beginBig();
      double hX = -widthHalf;
      double hY = -heightDown;
      hX = text.render(name, hX, hY, (Color)this.names.get(), true);
      if ((Boolean)this.itemCount.get()) {
         text.render(count, hX, hY, this.GOLD, true);
      }

      text.end();
      NametagUtils.end();
   }

   private void renderGenericNametag(class_1309 entity) {
      TextRenderer text = TextRenderer.get();
      NametagUtils.begin(this.pos);
      String nameText = entity.method_5864().method_5897().getString();
      nameText = nameText + " ";
      float absorption = entity.method_6067();
      int health = Math.round(entity.method_6032() + absorption);
      double healthPercentage = (double)((float)health / (entity.method_6063() + absorption));
      String healthText = String.valueOf(health);
      Color healthColor;
      if (healthPercentage <= 0.333D) {
         healthColor = this.RED;
      } else if (healthPercentage <= 0.666D) {
         healthColor = this.AMBER;
      } else {
         healthColor = this.GREEN;
      }

      double nameWidth = text.getWidth(nameText, true);
      double healthWidth = text.getWidth(healthText, true);
      double heightDown = text.getHeight(true);
      double width = nameWidth + healthWidth;
      double widthHalf = width / 2.0D;
      this.drawBg(-widthHalf, -heightDown, width, heightDown);
      text.beginBig();
      double hX = -widthHalf;
      double hY = -heightDown;
      hX = text.render(nameText, hX, hY, (Color)this.names.get(), true);
      text.render(healthText, hX, hY, healthColor, true);
      text.end();
      NametagUtils.end();
   }

   private void renderTntNametag(class_1541 entity) {
      TextRenderer text = TextRenderer.get();
      NametagUtils.begin(this.pos);
      String fuseText = ticksToTime(entity.method_6969());
      double width = text.getWidth(fuseText, true);
      double heightDown = text.getHeight(true);
      double widthHalf = width / 2.0D;
      this.drawBg(-widthHalf, -heightDown, width, heightDown);
      text.beginBig();
      double hX = -widthHalf;
      double hY = -heightDown;
      text.render(fuseText, hX, hY, (Color)this.names.get(), true);
      text.end();
      NametagUtils.end();
   }

   private class_1799 getItem(class_1657 entity, int index) {
      class_1799 var10000;
      switch(index) {
      case 0:
         var10000 = entity.method_6047();
         break;
      case 1:
         var10000 = (class_1799)entity.method_31548().field_7548.get(3);
         break;
      case 2:
         var10000 = (class_1799)entity.method_31548().field_7548.get(2);
         break;
      case 3:
         var10000 = (class_1799)entity.method_31548().field_7548.get(1);
         break;
      case 4:
         var10000 = (class_1799)entity.method_31548().field_7548.get(0);
         break;
      case 5:
         var10000 = entity.method_6079();
         break;
      default:
         var10000 = class_1799.field_8037;
      }

      return var10000;
   }

   private void drawBg(double x, double y, double width, double height) {
      Renderer2D.COLOR.begin();
      Renderer2D.COLOR.quad(x - 1.0D, y - 1.0D, width + 2.0D, height + 2.0D, (Color)this.background.get());
      Renderer2D.COLOR.render((class_4587)null);
   }

   public static enum Position {
      Above,
      OnTop;

      // $FF: synthetic method
      private static Nametags.Position[] $values() {
         return new Nametags.Position[]{Above, OnTop};
      }
   }
}
