package meteordevelopment.meteorclient.systems.modules.render;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.mixin.ClientPlayerInteractionManagerAccessor;
import meteordevelopment.meteorclient.mixin.WorldRendererAccessor;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.player.PacketMine;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3191;

public class BreakIndicators extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<ShapeMode> shapeMode;
   public final Setting<Boolean> packetMine;
   private final Setting<SettingColor> startColor;
   private final Setting<SettingColor> endColor;
   private final Color cSides;
   private final Color cLines;

   public BreakIndicators() {
      super(Categories.Render, "break-indicators", "Renders the progress of a block being broken.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.shapeMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
      this.packetMine = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("packet-mine")).description("Whether or not to render blocks being packet mined.")).defaultValue(true)).build());
      this.startColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("start-color")).description("The color for the non-broken block.")).defaultValue(new SettingColor(25, 252, 25, 150))).build());
      this.endColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("end-color")).description("The color for the fully-broken block.")).defaultValue(new SettingColor(255, 25, 25, 150))).build());
      this.cSides = new Color();
      this.cLines = new Color();
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      this.renderNormal(event);
      if ((Boolean)this.packetMine.get() && !((PacketMine)Modules.get().get(PacketMine.class)).blocks.isEmpty()) {
         this.renderPacket(event, ((PacketMine)Modules.get().get(PacketMine.class)).blocks);
      }

   }

   private void renderNormal(Render3DEvent event) {
      Map<Integer, class_3191> blocks = ((WorldRendererAccessor)this.mc.field_1769).getBlockBreakingInfos();
      float ownBreakingStage = ((ClientPlayerInteractionManagerAccessor)this.mc.field_1761).getBreakingProgress();
      class_2338 ownBreakingPos = ((ClientPlayerInteractionManagerAccessor)this.mc.field_1761).getCurrentBreakingBlockPos();
      blocks.values().forEach((info) -> {
         class_2338 pos = info.method_13991();
         int stage = info.method_13988();
         class_2680 state = this.mc.field_1687.method_8320(pos);
         class_265 shape = state.method_26218(this.mc.field_1687, pos);
         if (!shape.method_1110()) {
            class_238 orig = shape.method_1107();
            double shrinkFactor = (double)(9 - (stage + 1)) / 9.0D;
            if (ownBreakingPos != null && ownBreakingStage > 0.0F && ownBreakingPos.equals(pos)) {
               shrinkFactor = 1.0D - (double)ownBreakingStage;
            }

            double progress = 1.0D - shrinkFactor;
            this.renderBlock(event, orig, orig, pos, shrinkFactor, progress);
         }
      });
   }

   private void renderPacket(Render3DEvent event, List<PacketMine.MyBlock> blocks) {
      Iterator var3 = blocks.iterator();

      while(var3.hasNext()) {
         PacketMine.MyBlock block = (PacketMine.MyBlock)var3.next();
         if (block.mining && block.progress != Double.POSITIVE_INFINITY) {
            class_265 shape = block.blockState.method_26218(this.mc.field_1687, block.blockPos);
            if (shape.method_1110()) {
               return;
            }

            class_238 orig = shape.method_1107();
            double progressNormalised = block.progress > 1.0D ? 1.0D : block.progress;
            double shrinkFactor = 1.0D - progressNormalised;
            class_2338 pos = block.blockPos;
            this.renderBlock(event, orig, orig, pos, shrinkFactor, progressNormalised);
         }
      }

   }

   private void renderBlock(Render3DEvent event, class_238 box, class_238 orig, class_2338 pos, double shrinkFactor, double progress) {
      box = box.method_1002(box.method_17939() * shrinkFactor, box.method_17940() * shrinkFactor, box.method_17941() * shrinkFactor);
      double xShrink = orig.method_17939() * shrinkFactor / 2.0D;
      double yShrink = orig.method_17940() * shrinkFactor / 2.0D;
      double zShrink = orig.method_17941() * shrinkFactor / 2.0D;
      double x1 = (double)pos.method_10263() + box.field_1323 + xShrink;
      double y1 = (double)pos.method_10264() + box.field_1322 + yShrink;
      double z1 = (double)pos.method_10260() + box.field_1321 + zShrink;
      double x2 = (double)pos.method_10263() + box.field_1320 + xShrink;
      double y2 = (double)pos.method_10264() + box.field_1325 + yShrink;
      double z2 = (double)pos.method_10260() + box.field_1324 + zShrink;
      Color c1Sides = ((SettingColor)this.startColor.get()).copy().a(((SettingColor)this.startColor.get()).a / 2);
      Color c2Sides = ((SettingColor)this.endColor.get()).copy().a(((SettingColor)this.endColor.get()).a / 2);
      this.cSides.set((int)Math.round((double)c1Sides.r + (double)(c2Sides.r - c1Sides.r) * progress), (int)Math.round((double)c1Sides.g + (double)(c2Sides.g - c1Sides.g) * progress), (int)Math.round((double)c1Sides.b + (double)(c2Sides.b - c1Sides.b) * progress), (int)Math.round((double)c1Sides.a + (double)(c2Sides.a - c1Sides.a) * progress));
      Color c1Lines = (Color)this.startColor.get();
      Color c2Lines = (Color)this.endColor.get();
      this.cLines.set((int)Math.round((double)c1Lines.r + (double)(c2Lines.r - c1Lines.r) * progress), (int)Math.round((double)c1Lines.g + (double)(c2Lines.g - c1Lines.g) * progress), (int)Math.round((double)c1Lines.b + (double)(c2Lines.b - c1Lines.b) * progress), (int)Math.round((double)c1Lines.a + (double)(c2Lines.a - c1Lines.a) * progress));
      event.renderer.box(x1, y1, z1, x2, y2, z2, this.cSides, this.cLines, (ShapeMode)this.shapeMode.get(), 0);
   }
}
