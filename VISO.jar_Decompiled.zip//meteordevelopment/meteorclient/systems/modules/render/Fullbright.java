package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_310;

public class Fullbright extends Module {
   private final SettingGroup sgGeneral;
   public final Setting<Fullbright.Mode> mode;
   private final Setting<Integer> minimumLightLevel;

   public Fullbright() {
      super(Categories.Render, "fullbright", "Lights up your world!");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).description("The mode to use for Fullbright.")).defaultValue(Fullbright.Mode.Luminance)).onChanged((mode) -> {
         if (mode == Fullbright.Mode.Luminance) {
            this.mc.field_1690.field_1840 = Fullbright.StaticListener.prevGamma;
         }

      })).build());
      this.minimumLightLevel = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("minimum-light-level")).description("Minimum light level when using Luminance mode.")).visible(() -> {
         return this.mode.get() == Fullbright.Mode.Luminance;
      })).defaultValue(8)).onChanged((integer) -> {
         if (this.mc.field_1769 != null) {
            this.mc.field_1769.method_3279();
         }

      })).range(0, 15).sliderMax(15).build());
      MeteorClient.EVENT_BUS.subscribe(Fullbright.StaticListener.class);
   }

   public void onActivate() {
      enable();
      if (this.mode.get() == Fullbright.Mode.Luminance) {
         this.mc.field_1769.method_3279();
      }

   }

   public void onDeactivate() {
      disable();
      if (this.mode.get() == Fullbright.Mode.Luminance) {
         this.mc.field_1769.method_3279();
      }

   }

   public int getMinimumLightLevel() {
      return this.isActive() && this.mode.get() == Fullbright.Mode.Luminance ? (Integer)this.minimumLightLevel.get() : 0;
   }

   public static boolean isEnabled() {
      return Fullbright.StaticListener.timesEnabled > 0;
   }

   public static void enable() {
      ++Fullbright.StaticListener.timesEnabled;
   }

   public static void disable() {
      --Fullbright.StaticListener.timesEnabled;
   }

   public static enum Mode {
      Gamma,
      Luminance;

      // $FF: synthetic method
      private static Fullbright.Mode[] $values() {
         return new Fullbright.Mode[]{Gamma, Luminance};
      }
   }

   private static class StaticListener {
      private static final class_310 mc = class_310.method_1551();
      private static final Fullbright fullbright = (Fullbright)Modules.get().get(Fullbright.class);
      private static int timesEnabled;
      private static int lastTimesEnabled;
      private static double prevGamma;

      @EventHandler
      private static void onTick(TickEvent.Post event) {
         if (timesEnabled > 0 && lastTimesEnabled == 0) {
            prevGamma = mc.field_1690.field_1840;
         } else if (timesEnabled == 0 && lastTimesEnabled > 0 && fullbright.mode.get() == Fullbright.Mode.Gamma) {
            mc.field_1690.field_1840 = prevGamma == 16.0D ? 1.0D : prevGamma;
         }

         if (timesEnabled > 0 && fullbright.mode.get() == Fullbright.Mode.Gamma) {
            mc.field_1690.field_1840 = 16.0D;
         }

         lastTimesEnabled = timesEnabled;
      }

      static {
         prevGamma = mc.field_1690.field_1840;
      }
   }
}
