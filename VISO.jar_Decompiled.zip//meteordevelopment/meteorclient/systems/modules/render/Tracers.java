package meteordevelopment.meteorclient.systems.modules.render;

import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import java.util.Iterator;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.Target;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;

public class Tracers extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgAppearance;
   private final SettingGroup sgColors;
   private final Setting<Object2BooleanMap<class_1299<?>>> entities;
   private final Setting<Target> target;
   private final Setting<Boolean> stem;
   private final Setting<Integer> maxDist;
   public final Setting<Boolean> showInvis;
   public final Setting<Boolean> distance;
   private final Setting<SettingColor> playersColor;
   private final Setting<SettingColor> animalsColor;
   private final Setting<SettingColor> waterAnimalsColor;
   private final Setting<SettingColor> monstersColor;
   private final Setting<SettingColor> ambientColor;
   private final Setting<SettingColor> miscColor;
   private int count;
   private final Color distanceColor;

   public Tracers() {
      super(Categories.Render, "tracers", "Displays tracer lines to specified entities.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgAppearance = this.settings.createGroup("Appearance");
      this.sgColors = this.settings.createGroup("Colors");
      this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder()).name("entites")).description("Select specific entities.")).defaultValue(class_1299.field_6097).build());
      this.target = this.sgAppearance.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("target")).description("What part of the entity to target.")).defaultValue(Target.Body)).build());
      this.stem = this.sgAppearance.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("stem")).description("Draw a line through the center of the tracer target.")).defaultValue(true)).build());
      this.maxDist = this.sgAppearance.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("max-distance")).description("Maximum distance for tracers to show.")).defaultValue(256)).min(0).sliderMax(256).build());
      this.showInvis = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("show-invisible")).description("Shows invisibile entities.")).defaultValue(true)).build());
      this.distance = this.sgColors.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("distance-colors")).description("Changes the color of tracers depending on distance.")).defaultValue(false)).build());
      this.playersColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("players-colors")).description("The player's color.")).defaultValue(new SettingColor(205, 205, 205, 127))).visible(() -> {
         return !(Boolean)this.distance.get();
      })).build());
      this.animalsColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("animals-color")).description("The animal's color.")).defaultValue(new SettingColor(145, 255, 145, 127))).visible(() -> {
         return !(Boolean)this.distance.get();
      })).build());
      this.waterAnimalsColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("water-animals-color")).description("The water animal's color.")).defaultValue(new SettingColor(145, 145, 255, 127))).visible(() -> {
         return !(Boolean)this.distance.get();
      })).build());
      this.monstersColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("monsters-color")).description("The monster's color.")).defaultValue(new SettingColor(255, 145, 145, 127))).visible(() -> {
         return !(Boolean)this.distance.get();
      })).build());
      this.ambientColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("ambient-color")).description("The ambient color.")).defaultValue(new SettingColor(75, 75, 75, 127))).visible(() -> {
         return !(Boolean)this.distance.get();
      })).build());
      this.miscColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("misc-color")).description("The misc color.")).defaultValue(new SettingColor(145, 145, 145, 127))).visible(() -> {
         return !(Boolean)this.distance.get();
      })).build());
      this.distanceColor = new Color(255, 255, 255);
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (!this.mc.field_1690.field_1842) {
         this.count = 0;
         Iterator var2 = this.mc.field_1687.method_18112().iterator();

         while(true) {
            class_1297 entity;
            do {
               do {
                  do {
                     if (!var2.hasNext()) {
                        return;
                     }

                     entity = (class_1297)var2.next();
                  } while(this.mc.field_1724.method_5739(entity) > (float)(Integer)this.maxDist.get());
               } while(!Modules.get().isActive(Freecam.class) && entity == this.mc.field_1724);
            } while(!((Object2BooleanMap)this.entities.get()).getBoolean(entity.method_5864()));

            if (!((!(Boolean)this.showInvis.get() && entity.method_5767()) | !EntityUtils.isInRenderDistance(entity))) {
               Object color;
               if ((Boolean)this.distance.get()) {
                  color = this.getColorFromDistance(entity);
               } else if (entity instanceof class_1657) {
                  color = PlayerUtils.getPlayerColor((class_1657)entity, (Color)this.playersColor.get());
               } else {
                  SettingColor var10000;
                  switch(entity.method_5864().method_5891()) {
                  case field_6294:
                     var10000 = (SettingColor)this.animalsColor.get();
                     break;
                  case field_24460:
                  case field_6300:
                  case field_30092:
                     var10000 = (SettingColor)this.waterAnimalsColor.get();
                     break;
                  case field_6302:
                     var10000 = (SettingColor)this.monstersColor.get();
                     break;
                  case field_6303:
                     var10000 = (SettingColor)this.ambientColor.get();
                     break;
                  default:
                     var10000 = (SettingColor)this.miscColor.get();
                  }

                  color = var10000;
               }

               double x = entity.field_6014 + (entity.method_23317() - entity.field_6014) * (double)event.tickDelta;
               double y = entity.field_6036 + (entity.method_23318() - entity.field_6036) * (double)event.tickDelta;
               double z = entity.field_5969 + (entity.method_23321() - entity.field_5969) * (double)event.tickDelta;
               double height = entity.method_5829().field_1325 - entity.method_5829().field_1322;
               if (this.target.get() == Target.Head) {
                  y += height;
               } else if (this.target.get() == Target.Body) {
                  y += height / 2.0D;
               }

               event.renderer.line(RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350, x, y, z, (Color)color);
               if ((Boolean)this.stem.get()) {
                  event.renderer.line(x, entity.method_23318(), z, x, entity.method_23318() + height, z, (Color)color);
               }

               ++this.count;
            }
         }
      }
   }

   private Color getColorFromDistance(class_1297 entity) {
      double distance = this.mc.field_1773.method_19418().method_19326().method_1022(entity.method_19538());
      double percent = distance / 60.0D;
      if (!(percent < 0.0D) && !(percent > 1.0D)) {
         int r;
         int g;
         if (percent < 0.5D) {
            r = 255;
            g = (int)(255.0D * percent / 0.5D);
         } else {
            g = 255;
            r = 255 - (int)(255.0D * (percent - 0.5D) / 0.5D);
         }

         this.distanceColor.set(r, g, 0, 255);
         return this.distanceColor;
      } else {
         this.distanceColor.set(0, 255, 0, 255);
         return this.distanceColor;
      }
   }

   public String getInfoString() {
      return Integer.toString(this.count);
   }
}
