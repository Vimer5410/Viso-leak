package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_1158;
import net.minecraft.class_4587;

public class HandView extends Module {
   private final SettingGroup sgScale;
   private final SettingGroup sgPosition;
   private final SettingGroup sgRotation;
   private final SettingGroup sgSwing;
   private final Setting<Double> scaleX;
   private final Setting<Double> scaleY;
   private final Setting<Double> scaleZ;
   private final Setting<Double> posX;
   private final Setting<Double> posY;
   private final Setting<Double> posZ;
   private final Setting<Double> rotationX;
   private final Setting<Double> rotationY;
   private final Setting<Double> rotationZ;
   public final Setting<HandView.SwingMode> swingMode;
   public final Setting<Double> mainSwing;
   public final Setting<Double> offSwing;

   public HandView() {
      super(Categories.Render, "hand-view", "Alters the way items are rendered in your hands.");
      this.sgScale = this.settings.createGroup("Scale");
      this.sgPosition = this.settings.createGroup("Position");
      this.sgRotation = this.settings.createGroup("Rotation");
      this.sgSwing = this.settings.createGroup("Swing");
      this.scaleX = this.sgScale.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("x")).description("The X scale of your hands.")).defaultValue(0.239D).sliderMax(5.0D).build());
      this.scaleY = this.sgScale.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("y")).description("The Y scale of your hands.")).defaultValue(0.294D).sliderMax(5.0D).build());
      this.scaleZ = this.sgScale.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("z")).description("The Z scale of your hands.")).defaultValue(0.349D).sliderMax(5.0D).build());
      this.posX = this.sgPosition.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("x")).description("The X position offset of your hands.")).defaultValue(0.0D).sliderRange(-3.0D, 3.0D).build());
      this.posY = this.sgPosition.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("y")).description("The Y position offset of your hands.")).defaultValue(0.626D).sliderRange(-3.0D, 3.0D).build());
      this.posZ = this.sgPosition.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("z")).description("The Z position offset of your hands.")).defaultValue(-0.829D).sliderRange(-3.0D, 3.0D).build());
      this.rotationX = this.sgRotation.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("x")).description("The X orientation of your hands.")).defaultValue(-0.141D).sliderRange(-1.0D, 1.0D).build());
      this.rotationY = this.sgRotation.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("y")).description("The Y orientation of your hands.")).defaultValue(0.0D).sliderRange(-1.0D, 1.0D).build());
      this.rotationZ = this.sgRotation.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("z")).description("The Z orientation of your hands.")).defaultValue(0.0D).sliderRange(-1.0D, 1.0D).build());
      this.swingMode = this.sgSwing.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).description("Modifies your client & server hand swinging.")).defaultValue(HandView.SwingMode.None)).build());
      this.mainSwing = this.sgSwing.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("main-progress")).description("The swing progress of your main hand.")).defaultValue(0.0D).range(0.0D, 1.0D).sliderMax(1.0D).build());
      this.offSwing = this.sgSwing.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("offhand-progress")).description("The swing progress of your offhand.")).defaultValue(0.0D).range(0.0D, 1.0D).sliderMax(1.0D).build());
   }

   public void transform(class_4587 matrices) {
      if (this.isActive()) {
         matrices.method_22905(((Double)this.scaleX.get()).floatValue(), ((Double)this.scaleY.get()).floatValue(), ((Double)this.scaleZ.get()).floatValue());
         matrices.method_22904((Double)this.posX.get(), (Double)this.posY.get(), (Double)this.posZ.get());
         matrices.method_22907(class_1158.method_35825(((Double)this.rotationX.get()).floatValue(), ((Double)this.rotationY.get()).floatValue(), ((Double)this.rotationZ.get()).floatValue()));
      }
   }

   public static enum SwingMode {
      Offhand,
      Mainhand,
      None;

      // $FF: synthetic method
      private static HandView.SwingMode[] $values() {
         return new HandView.SwingMode[]{Offhand, Mainhand, None};
      }
   }
}
