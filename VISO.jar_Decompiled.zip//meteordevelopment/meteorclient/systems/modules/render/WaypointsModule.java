package meteordevelopment.meteorclient.systems.modules.render;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.pathing.goals.GoalGetToBlock;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Objects;
import java.util.function.Consumer;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.screens.settings.ColorSettingScreen;
import meteordevelopment.meteorclient.gui.widgets.WLabel;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WDoubleEdit;
import meteordevelopment.meteorclient.gui.widgets.input.WDropdown;
import meteordevelopment.meteorclient.gui.widgets.input.WIntEdit;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WMinus;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.IVisible;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.waypoints.Waypoint;
import meteordevelopment.meteorclient.systems.waypoints.Waypoints;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.world.Dimension;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2554;
import net.minecraft.class_2585;
import net.minecraft.class_418;

public class WaypointsModule extends Module {
   private static final Color GRAY = new Color(200, 200, 200);
   private final SettingGroup sgGeneral;
   private final SettingGroup sgDeathPosition;
   public final Setting<Integer> textRenderDistance;
   private final Setting<Integer> maxDeathPositions;
   private final Setting<Boolean> dpChat;
   private final SimpleDateFormat dateFormat;

   public WaypointsModule() {
      super(Categories.Render, "waypoints", "Allows you to create waypoints.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgDeathPosition = this.settings.createGroup("Death Position");
      this.textRenderDistance = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("text-render-distance")).description("Maximum distance from the center of the screen at which text will be rendered.")).defaultValue(100)).min(0).sliderMax(200).build());
      this.maxDeathPositions = this.sgDeathPosition.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("max-death-positions")).description("The amount of death positions to save, 0 to disable")).defaultValue(0)).min(0).sliderMax(20).onChanged(this::cleanDeathWPs)).build());
      this.dpChat = this.sgDeathPosition.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("chat")).description("Send a chat message with your position once you die")).defaultValue(false)).build());
      this.dateFormat = new SimpleDateFormat("HH:mm:ss");
   }

   @EventHandler
   private void onOpenScreen(OpenScreenEvent event) {
      if (event.screen instanceof class_418) {
         if (!event.isCancelled()) {
            this.addDeath(this.mc.field_1724.method_19538());
         }

      }
   }

   public void addDeath(class_243 deathPos) {
      String time = this.dateFormat.format(new Date());
      if ((Boolean)this.dpChat.get()) {
         class_2554 text = new class_2585("Died at ");
         text.method_10852(ChatUtils.formatCoords(deathPos));
         text.method_27693(String.format(" on %s.", time));
         this.info(text);
      }

      if ((Integer)this.maxDeathPositions.get() > 0) {
         Waypoint waypoint = new Waypoint();
         waypoint.name = "Death " + time;
         waypoint.icon = "skull";
         waypoint.scale = 2.0D;
         waypoint.x = (int)deathPos.field_1352;
         waypoint.y = (int)deathPos.field_1351 + 2;
         waypoint.z = (int)deathPos.field_1350;
         waypoint.maxVisibleDistance = Integer.MAX_VALUE;
         waypoint.actualDimension = PlayerUtils.getDimension();
         switch(waypoint.actualDimension) {
         case Overworld:
            waypoint.overworld = true;
            break;
         case Nether:
            waypoint.nether = true;
            break;
         case End:
            waypoint.end = true;
         }

         Waypoints.get().add(waypoint);
      }

      this.cleanDeathWPs((Integer)this.maxDeathPositions.get());
   }

   private void cleanDeathWPs(int max) {
      int oldWpC = 0;
      ListIterator wps = Waypoints.get().iteratorReverse();

      while(wps.hasPrevious()) {
         Waypoint wp = (Waypoint)wps.previous();
         if (wp.name.startsWith("Death ") && "skull".equals(wp.icon)) {
            ++oldWpC;
            if (oldWpC > max) {
               Waypoints.get().remove(wp);
            }
         }
      }

   }

   public WWidget getWidget(GuiTheme theme) {
      if (!Utils.canUpdate()) {
         return theme.label("You need to be in a world.");
      } else {
         WTable table = theme.table();
         this.fillTable(theme, table);
         return table;
      }
   }

   private void fillTable(GuiTheme theme, WTable table) {
      WButton create = (WButton)table.add(theme.button("Create")).expandX().widget();
      create.action = () -> {
         this.mc.method_1507(new WaypointsModule.EditWaypointScreen(theme, (Waypoint)null, () -> {
            table.clear();
            this.fillTable(theme, table);
         }));
      };
      table.row();

      for(Iterator var4 = Waypoints.get().iterator(); var4.hasNext(); table.row()) {
         Waypoint waypoint = (Waypoint)var4.next();
         table.add(new WaypointsModule.WIcon(waypoint));
         WLabel name = (WLabel)table.add(theme.label(waypoint.name)).expandCellX().widget();
         boolean goodDimension = false;
         Dimension dimension = PlayerUtils.getDimension();
         if (waypoint.overworld && dimension == Dimension.Overworld) {
            goodDimension = true;
         } else if (waypoint.nether && dimension == Dimension.Nether) {
            goodDimension = true;
         } else if (waypoint.end && dimension == Dimension.End) {
            goodDimension = true;
         }

         if (!goodDimension) {
            name.color = GRAY;
         }

         WCheckbox visible = (WCheckbox)table.add(theme.checkbox(waypoint.visible)).widget();
         visible.action = () -> {
            waypoint.visible = visible.checked;
            Waypoints.get().save();
         };
         WButton edit = (WButton)table.add(theme.button(GuiRenderer.EDIT)).widget();
         edit.action = () -> {
            this.mc.method_1507(new WaypointsModule.EditWaypointScreen(theme, waypoint, (Runnable)null));
         };
         WMinus remove = (WMinus)table.add(theme.minus()).widget();
         remove.action = () -> {
            Waypoints.get().remove(waypoint);
            table.clear();
            this.fillTable(theme, table);
         };
         if (waypoint.actualDimension == dimension) {
            WButton gotoB = (WButton)table.add(theme.button("Goto")).widget();
            gotoB.action = () -> {
               if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
                  IBaritone baritone = BaritoneAPI.getProvider().getPrimaryBaritone();
                  if (baritone.getPathingBehavior().isPathing()) {
                     baritone.getPathingBehavior().cancelEverything();
                  }

                  baritone.getCustomGoalProcess().setGoalAndPath(new GoalGetToBlock(waypoint.getCoords().toBlockPos()));
               }
            };
         }
      }

   }

   private Integer getMaxHeight() {
      return this.mc.field_1687.method_8597().method_32924() - Math.abs(this.getMinHeight()) - 1;
   }

   private Integer getMinHeight() {
      return this.mc.field_1687.method_8597().method_29959();
   }

   private static class WIcon extends WWidget {
      private final Waypoint waypoint;

      public WIcon(Waypoint waypoint) {
         this.waypoint = waypoint;
      }

      protected void onCalculateSize() {
         double s = this.theme.scale(32.0D);
         this.width = s;
         this.height = s;
      }

      protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
         renderer.post(() -> {
            this.waypoint.renderIcon(this.x, this.y, 1.0D, this.width);
         });
      }
   }

   private class EditWaypointScreen extends WindowScreen {
      private final Waypoint waypoint;
      private final boolean newWaypoint;
      private final Runnable action;

      public EditWaypointScreen(GuiTheme theme, Waypoint waypoint, Runnable action) {
         super(theme, waypoint == null ? "New Waypoint" : "Edit Waypoint");
         this.newWaypoint = waypoint == null;
         this.waypoint = this.newWaypoint ? new Waypoint() : waypoint;
         this.action = action;
         this.waypoint.validateIcon();
         if (this.newWaypoint) {
            this.waypoint.x = (int)WaypointsModule.this.mc.field_1724.method_23317();
            this.waypoint.y = (int)WaypointsModule.this.mc.field_1724.method_23318() + 2;
            this.waypoint.z = (int)WaypointsModule.this.mc.field_1724.method_23321();
            this.waypoint.actualDimension = PlayerUtils.getDimension();
            switch(PlayerUtils.getDimension()) {
            case Overworld:
               this.waypoint.overworld = true;
               break;
            case Nether:
               this.waypoint.nether = true;
               break;
            case End:
               this.waypoint.end = true;
            }
         }

      }

      public void initWidgets() {
         WTable table = (WTable)this.add(this.theme.table()).expandX().widget();
         table.add(this.theme.label("Name:"));
         WTextBox name = (WTextBox)table.add(this.theme.textBox(this.waypoint.name)).minWidth(400.0D).expandX().widget();
         name.action = () -> {
            this.waypoint.name = name.get().trim();
         };
         table.row();
         table.add(this.theme.label("Icon:"));
         WHorizontalList list = (WHorizontalList)table.add(this.theme.horizontalList()).widget();
         WButton var10000 = (WButton)list.add(this.theme.button("<")).widget();
         Waypoint var10001 = this.waypoint;
         Objects.requireNonNull(var10001);
         var10000.action = var10001::prevIcon;
         list.add(new WaypointsModule.WIcon(this.waypoint));
         var10000 = (WButton)list.add(this.theme.button(">")).widget();
         var10001 = this.waypoint;
         Objects.requireNonNull(var10001);
         var10000.action = var10001::nextIcon;
         table.row();
         table.add(this.theme.label("Color:"));
         list = (WHorizontalList)table.add(this.theme.horizontalList()).widget();
         list.add(this.theme.quad(this.waypoint.color));
         ((WButton)list.add(this.theme.button(GuiRenderer.EDIT)).widget()).action = () -> {
            WaypointsModule.this.mc.method_1507(new ColorSettingScreen(this.theme, new ColorSetting("", "", this.waypoint.color, (color) -> {
               this.waypoint.color.set((Color)color);
            }, (Consumer)null, (IVisible)null)));
         };
         table.row();
         table.add(this.theme.horizontalSeparator()).expandX();
         table.row();
         table.add(this.theme.label("X:"));
         WIntEdit x = this.theme.intEdit(this.waypoint.x, Integer.MIN_VALUE, Integer.MAX_VALUE, true);
         x.noSlider = true;
         x.action = () -> {
            this.waypoint.x = x.get();
         };
         table.add(x).expandX();
         table.row();
         table.add(this.theme.label("Y:"));
         WIntEdit y = this.theme.intEdit(this.waypoint.y, WaypointsModule.this.getMinHeight(), WaypointsModule.this.getMaxHeight(), true);
         y.noSlider = true;
         y.actionOnRelease = () -> {
            if (y.get() < WaypointsModule.this.getMinHeight()) {
               y.set(WaypointsModule.this.getMinHeight());
            } else if (y.get() > WaypointsModule.this.getMaxHeight()) {
               y.set(WaypointsModule.this.getMaxHeight());
            }

            this.waypoint.y = y.get();
         };
         table.add(y).expandX();
         table.row();
         table.add(this.theme.label("Z:"));
         WIntEdit z = this.theme.intEdit(this.waypoint.z, Integer.MIN_VALUE, Integer.MAX_VALUE, true);
         z.action = () -> {
            this.waypoint.z = z.get();
         };
         table.add(z).expandX();
         table.row();
         table.add(this.theme.horizontalSeparator()).expandX();
         table.row();
         table.add(this.theme.label("Visible:"));
         WCheckbox visible = (WCheckbox)table.add(this.theme.checkbox(this.waypoint.visible)).widget();
         visible.action = () -> {
            this.waypoint.visible = visible.checked;
         };
         table.row();
         table.add(this.theme.label("Max Visible Distance"));
         WIntEdit maxVisibleDist = (WIntEdit)table.add(this.theme.intEdit(this.waypoint.maxVisibleDistance, 0, Integer.MAX_VALUE, 0, 10000)).expandX().widget();
         maxVisibleDist.action = () -> {
            this.waypoint.maxVisibleDistance = maxVisibleDist.get();
         };
         table.row();
         table.add(this.theme.label("Scale:"));
         WDoubleEdit scale = (WDoubleEdit)table.add(this.theme.doubleEdit(this.waypoint.scale, 0.0D, 4.0D, 0.0D, 4.0D)).expandX().widget();
         scale.action = () -> {
            this.waypoint.scale = scale.get();
         };
         table.row();
         table.add(this.theme.horizontalSeparator()).expandX();
         table.row();
         table.add(this.theme.label("Actual Dimension:"));
         WDropdown<Dimension> dimensionDropdown = (WDropdown)table.add(this.theme.dropdown(this.waypoint.actualDimension)).widget();
         dimensionDropdown.action = () -> {
            this.waypoint.actualDimension = (Dimension)dimensionDropdown.get();
         };
         table.row();
         table.add(this.theme.label("Visible in Overworld:"));
         WCheckbox overworld = (WCheckbox)table.add(this.theme.checkbox(this.waypoint.overworld)).widget();
         overworld.action = () -> {
            this.waypoint.overworld = overworld.checked;
         };
         table.row();
         table.add(this.theme.label("Visible in Nether:"));
         WCheckbox nether = (WCheckbox)table.add(this.theme.checkbox(this.waypoint.nether)).widget();
         nether.action = () -> {
            this.waypoint.nether = nether.checked;
         };
         table.row();
         table.add(this.theme.label("Visible in End:"));
         WCheckbox end = (WCheckbox)table.add(this.theme.checkbox(this.waypoint.end)).widget();
         end.action = () -> {
            this.waypoint.end = end.checked;
         };
         table.row();
         WButton save = (WButton)table.add(this.theme.button("Save")).expandX().widget();
         save.action = () -> {
            if (this.newWaypoint) {
               Waypoints.get().add(this.waypoint);
            } else {
               Waypoints.get().save();
            }

            this.method_25419();
         };
         this.enterAction = save.action;
      }

      protected void onClosed() {
         if (this.action != null) {
            this.action.run();
         }

      }
   }
}
