package meteordevelopment.meteorclient.systems.modules.render;

import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import java.util.Iterator;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.WireframeEntityRenderer;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class ESP extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgColors;
   public final Setting<ESP.Mode> mode;
   public final Setting<Boolean> ignoreSelf;
   public final Setting<ShapeMode> shapeMode;
   public final Setting<Integer> fillOpacity;
   public final Setting<Integer> outlineWidth;
   private final Setting<Double> fadeDistance;
   private final Setting<Object2BooleanMap<class_1299<?>>> entities;
   private final Setting<SettingColor> playersColor;
   private final Setting<SettingColor> animalsColor;
   private final Setting<SettingColor> waterAnimalsColor;
   private final Setting<SettingColor> monstersColor;
   private final Setting<SettingColor> ambientColor;
   private final Setting<SettingColor> miscColor;
   private final Color lineColor;
   private final Color sideColor;
   private final Vec3 pos1;
   private final Vec3 pos2;
   private final Vec3 pos;
   private int count;

   public ESP() {
      super(Categories.Render, "esp", "Renders entities through walls.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgColors = this.settings.createGroup("Colors");
      this.mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).description("Rendering mode.")).defaultValue(ESP.Mode.Shader)).build());
      this.ignoreSelf = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ignore-self")).description("Ignores yourself drawing the shader.")).defaultValue(true)).visible(() -> {
         return this.mode.get() == ESP.Mode.Shader;
      })).build());
      this.shapeMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
      this.fillOpacity = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("fill-opacity")).description("The opacity of the shape fill.")).visible(() -> {
         return this.shapeMode.get() != ShapeMode.Lines;
      })).defaultValue(80)).range(0, 255).sliderMax(255).build());
      this.outlineWidth = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("width")).description("The width of the shader outline.")).visible(() -> {
         return this.mode.get() == ESP.Mode.Shader;
      })).defaultValue(2)).range(1, 10).sliderRange(1, 5).build());
      this.fadeDistance = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("fade-distance")).description("The distance from an entity where the color begins to fade.")).defaultValue(2.0D).min(0.0D).sliderMax(12.0D).build());
      this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder()).name("entities")).description("Select specific entities.")).defaultValue(class_1299.field_6097).build());
      this.playersColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("players-color")).description("The other player's color.")).defaultValue(new SettingColor(255, 255, 255))).build());
      this.animalsColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("animals-color")).description("The animal's color.")).defaultValue(new SettingColor(25, 255, 25, 255))).build());
      this.waterAnimalsColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("water-animals-color")).description("The water animal's color.")).defaultValue(new SettingColor(25, 25, 255, 255))).build());
      this.monstersColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("monsters-color")).description("The monster's color.")).defaultValue(new SettingColor(255, 25, 25, 255))).build());
      this.ambientColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("ambient-color")).description("The ambient's color.")).defaultValue(new SettingColor(25, 25, 25, 255))).build());
      this.miscColor = this.sgColors.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("misc-color")).description("The misc color.")).defaultValue(new SettingColor(175, 175, 175, 255))).build());
      this.lineColor = new Color();
      this.sideColor = new Color();
      this.pos1 = new Vec3();
      this.pos2 = new Vec3();
      this.pos = new Vec3();
   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      if (this.mode.get() != ESP.Mode._2D) {
         this.count = 0;
         Iterator var2 = this.mc.field_1687.method_18112().iterator();

         while(true) {
            class_1297 entity;
            do {
               if (!var2.hasNext()) {
                  return;
               }

               entity = (class_1297)var2.next();
            } while(this.shouldSkip(entity));

            if (this.mode.get() == ESP.Mode.Box || this.mode.get() == ESP.Mode.Wireframe) {
               this.drawBoundingBox(event, entity);
            }

            ++this.count;
         }
      }
   }

   private void drawBoundingBox(Render3DEvent event, class_1297 entity) {
      this.lineColor.set(this.getColor(entity));
      this.sideColor.set(this.lineColor).a((Integer)this.fillOpacity.get());
      double a = this.getFadeAlpha(entity);
      int prevLineA = this.lineColor.a;
      int prevSideA = this.sideColor.a;
      Color var10000 = this.lineColor;
      var10000.a = (int)((double)var10000.a * a);
      var10000 = this.sideColor;
      var10000.a = (int)((double)var10000.a * a);
      if (this.mode.get() == ESP.Mode.Box) {
         double x = class_3532.method_16436((double)event.tickDelta, entity.field_6038, entity.method_23317()) - entity.method_23317();
         double y = class_3532.method_16436((double)event.tickDelta, entity.field_5971, entity.method_23318()) - entity.method_23318();
         double z = class_3532.method_16436((double)event.tickDelta, entity.field_5989, entity.method_23321()) - entity.method_23321();
         class_238 box = entity.method_5829();
         event.renderer.box(x + box.field_1323, y + box.field_1322, z + box.field_1321, x + box.field_1320, y + box.field_1325, z + box.field_1324, this.sideColor, this.lineColor, (ShapeMode)this.shapeMode.get(), 0);
      } else {
         WireframeEntityRenderer.render(event, entity, 1.0D, this.sideColor, this.lineColor, (ShapeMode)this.shapeMode.get());
      }

      this.lineColor.a = prevLineA;
      this.sideColor.a = prevSideA;
   }

   @EventHandler
   private void onRender2D(Render2DEvent event) {
      if (this.mode.get() == ESP.Mode._2D) {
         Renderer2D.COLOR.begin();
         this.count = 0;
         Iterator var2 = this.mc.field_1687.method_18112().iterator();

         while(var2.hasNext()) {
            class_1297 entity = (class_1297)var2.next();
            if (!this.shouldSkip(entity)) {
               class_238 box = entity.method_5829();
               double x = class_3532.method_16436((double)event.tickDelta, entity.field_6038, entity.method_23317()) - entity.method_23317();
               double y = class_3532.method_16436((double)event.tickDelta, entity.field_5971, entity.method_23318()) - entity.method_23318();
               double z = class_3532.method_16436((double)event.tickDelta, entity.field_5989, entity.method_23321()) - entity.method_23321();
               this.pos1.set(Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE);
               this.pos2.set(0.0D, 0.0D, 0.0D);
               if (!this.checkCorner(box.field_1323 + x, box.field_1322 + y, box.field_1321 + z, this.pos1, this.pos2) && !this.checkCorner(box.field_1320 + x, box.field_1322 + y, box.field_1321 + z, this.pos1, this.pos2) && !this.checkCorner(box.field_1323 + x, box.field_1322 + y, box.field_1324 + z, this.pos1, this.pos2) && !this.checkCorner(box.field_1320 + x, box.field_1322 + y, box.field_1324 + z, this.pos1, this.pos2) && !this.checkCorner(box.field_1323 + x, box.field_1325 + y, box.field_1321 + z, this.pos1, this.pos2) && !this.checkCorner(box.field_1320 + x, box.field_1325 + y, box.field_1321 + z, this.pos1, this.pos2) && !this.checkCorner(box.field_1323 + x, box.field_1325 + y, box.field_1324 + z, this.pos1, this.pos2) && !this.checkCorner(box.field_1320 + x, box.field_1325 + y, box.field_1324 + z, this.pos1, this.pos2)) {
                  this.lineColor.set(this.getColor(entity));
                  this.sideColor.set(this.lineColor).a((Integer)this.fillOpacity.get());
                  double a = this.getFadeAlpha(entity);
                  int prevLineA = this.lineColor.a;
                  int prevSideA = this.sideColor.a;
                  Color var10000 = this.lineColor;
                  var10000.a = (int)((double)var10000.a * a);
                  var10000 = this.sideColor;
                  var10000.a = (int)((double)var10000.a * a);
                  if (this.shapeMode.get() != ShapeMode.Lines && this.sideColor.a > 0) {
                     Renderer2D.COLOR.quad(this.pos1.x, this.pos1.y, this.pos2.x - this.pos1.x, this.pos2.y - this.pos1.y, this.sideColor);
                  }

                  if (this.shapeMode.get() != ShapeMode.Sides) {
                     Renderer2D.COLOR.line(this.pos1.x, this.pos1.y, this.pos1.x, this.pos2.y, this.lineColor);
                     Renderer2D.COLOR.line(this.pos2.x, this.pos1.y, this.pos2.x, this.pos2.y, this.lineColor);
                     Renderer2D.COLOR.line(this.pos1.x, this.pos1.y, this.pos2.x, this.pos1.y, this.lineColor);
                     Renderer2D.COLOR.line(this.pos1.x, this.pos2.y, this.pos2.x, this.pos2.y, this.lineColor);
                  }

                  this.lineColor.a = prevLineA;
                  this.sideColor.a = prevSideA;
                  ++this.count;
               }
            }
         }

         Renderer2D.COLOR.render((class_4587)null);
      }
   }

   private boolean checkCorner(double x, double y, double z, Vec3 min, Vec3 max) {
      this.pos.set(x, y, z);
      if (!NametagUtils.to2D(this.pos, 1.0D)) {
         return true;
      } else {
         if (this.pos.x < min.x) {
            min.x = this.pos.x;
         }

         if (this.pos.y < min.y) {
            min.y = this.pos.y;
         }

         if (this.pos.z < min.z) {
            min.z = this.pos.z;
         }

         if (this.pos.x > max.x) {
            max.x = this.pos.x;
         }

         if (this.pos.y > max.y) {
            max.y = this.pos.y;
         }

         if (this.pos.z > max.z) {
            max.z = this.pos.z;
         }

         return false;
      }
   }

   public boolean shouldDrawOutline(class_1297 entity) {
      return this.mode.get() == ESP.Mode.Shader && this.isActive() && this.getOutlineColor(entity) != null;
   }

   public Color getOutlineColor(class_1297 entity) {
      if (!((Object2BooleanMap)this.entities.get()).getBoolean(entity.method_5864())) {
         return null;
      } else {
         Color color = this.getColor(entity);
         double alpha = this.getFadeAlpha(entity);
         return this.lineColor.set(color).a((int)(alpha * 255.0D));
      }
   }

   private double getFadeAlpha(class_1297 entity) {
      double dist = PlayerUtils.distanceToCamera(entity.method_23317() + (double)(entity.method_17681() / 2.0F), entity.method_23318() + (double)(entity.method_17682() / 2.0F), entity.method_23321() + (double)(entity.method_17681() / 2.0F));
      double fadeDist = (double)(((Double)this.fadeDistance.get()).floatValue() * ((Double)this.fadeDistance.get()).floatValue());
      double alpha = 1.0D;
      if (dist <= fadeDist) {
         alpha = (double)((float)(dist / fadeDist));
      }

      if (alpha <= 0.075D) {
         alpha = 0.0D;
      }

      return alpha;
   }

   public Color getColor(class_1297 entity) {
      if (entity instanceof class_1657) {
         return PlayerUtils.getPlayerColor((class_1657)entity, (Color)this.playersColor.get());
      } else {
         SettingColor var10000;
         switch(entity.method_5864().method_5891()) {
         case field_6294:
            var10000 = (SettingColor)this.animalsColor.get();
            break;
         case field_24460:
         case field_6300:
         case field_30092:
            var10000 = (SettingColor)this.waterAnimalsColor.get();
            break;
         case field_6302:
            var10000 = (SettingColor)this.monstersColor.get();
            break;
         case field_6303:
            var10000 = (SettingColor)this.ambientColor.get();
            break;
         default:
            var10000 = (SettingColor)this.miscColor.get();
         }

         return var10000;
      }
   }

   private boolean shouldSkip(class_1297 entity) {
      if ((Modules.get().isActive(Freecam.class) || entity != this.mc.field_1724) && ((Object2BooleanMap)this.entities.get()).getBoolean(entity.method_5864())) {
         return !EntityUtils.isInRenderDistance(entity);
      } else {
         return true;
      }
   }

   public String getInfoString() {
      return Integer.toString(this.count);
   }

   public boolean isShader() {
      return this.isActive() && this.mode.get() == ESP.Mode.Shader;
   }

   public static enum Mode {
      Box,
      Wireframe,
      _2D,
      Shader;

      public String toString() {
         return this == _2D ? "2D" : super.toString();
      }

      // $FF: synthetic method
      private static ESP.Mode[] $values() {
         return new ESP.Mode[]{Box, Wireframe, _2D, Shader};
      }
   }
}
