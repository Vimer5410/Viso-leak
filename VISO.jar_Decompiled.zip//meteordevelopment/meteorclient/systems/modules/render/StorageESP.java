package meteordevelopment.meteorclient.systems.modules.render;

import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StorageBlockListSetting;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.Dir;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2281;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2595;
import net.minecraft.class_2601;
import net.minecraft.class_2609;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_2646;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3719;

public class StorageESP extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<List<class_2591<?>>> storageBlocks;
   private final Setting<Boolean> tracers;
   private final Setting<ShapeMode> shapeMode;
   private final Setting<SettingColor> chest;
   private final Setting<SettingColor> trappedChest;
   private final Setting<SettingColor> barrel;
   private final Setting<SettingColor> shulker;
   private final Setting<SettingColor> enderChest;
   private final Setting<SettingColor> other;
   private final Setting<Double> fadeDistance;
   private final Color lineColor;
   private final Color sideColor;
   private boolean render;
   private int count;

   public StorageESP() {
      super(Categories.Render, "storage-esp", "Renders all specified storage blocks.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.storageBlocks = this.sgGeneral.add(((StorageBlockListSetting.Builder)((StorageBlockListSetting.Builder)(new StorageBlockListSetting.Builder()).name("storage-blocks")).description("Select the storage blocks to display.")).defaultValue(StorageBlockListSetting.STORAGE_BLOCKS).build());
      this.tracers = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("tracers")).description("Draws tracers to storage blocks.")).defaultValue(false)).build());
      this.shapeMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
      this.chest = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("chest")).description("The color of chests.")).defaultValue(new SettingColor(255, 160, 0, 255))).build());
      this.trappedChest = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("trapped-chest")).description("The color of trapped chests.")).defaultValue(new SettingColor(255, 0, 0, 255))).build());
      this.barrel = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("barrel")).description("The color of barrels.")).defaultValue(new SettingColor(255, 160, 0, 255))).build());
      this.shulker = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("shulker")).description("The color of Shulker Boxes.")).defaultValue(new SettingColor(255, 160, 0, 255))).build());
      this.enderChest = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("ender-chest")).description("The color of Ender Chests.")).defaultValue(new SettingColor(120, 0, 255, 255))).build());
      this.other = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("other")).description("The color of furnaces, dispenders, droppers and hoppers.")).defaultValue(new SettingColor(140, 140, 140, 255))).build());
      this.fadeDistance = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("fade-distance")).description("The distance at which the color will fade.")).defaultValue(6.0D).min(0.0D).sliderMax(12.0D).build());
      this.lineColor = new Color(0, 0, 0, 0);
      this.sideColor = new Color(0, 0, 0, 0);
   }

   private void getTileEntityColor(class_2586 blockEntity) {
      this.render = false;
      if (((List)this.storageBlocks.get()).contains(blockEntity.method_11017())) {
         if (blockEntity instanceof class_2646) {
            this.lineColor.set((Color)this.trappedChest.get());
         } else if (blockEntity instanceof class_2595) {
            this.lineColor.set((Color)this.chest.get());
         } else if (blockEntity instanceof class_3719) {
            this.lineColor.set((Color)this.barrel.get());
         } else if (blockEntity instanceof class_2627) {
            this.lineColor.set((Color)this.shulker.get());
         } else if (blockEntity instanceof class_2611) {
            this.lineColor.set((Color)this.enderChest.get());
         } else {
            if (!(blockEntity instanceof class_2609) && !(blockEntity instanceof class_2601) && !(blockEntity instanceof class_2614)) {
               return;
            }

            this.lineColor.set((Color)this.other.get());
         }

         this.render = true;
         if (this.shapeMode.get() == ShapeMode.Sides || this.shapeMode.get() == ShapeMode.Both) {
            this.sideColor.set(this.lineColor);
            Color var10000 = this.sideColor;
            var10000.a -= 225;
            if (this.sideColor.a < 0) {
               this.sideColor.a = 0;
            }
         }

      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      this.count = 0;
      Iterator var2 = Utils.blockEntities().iterator();

      while(true) {
         class_2586 blockEntity;
         do {
            if (!var2.hasNext()) {
               return;
            }

            blockEntity = (class_2586)var2.next();
            this.getTileEntityColor(blockEntity);
         } while(!this.render);

         double x1 = (double)blockEntity.method_11016().method_10263();
         double y1 = (double)blockEntity.method_11016().method_10264();
         double z1 = (double)blockEntity.method_11016().method_10260();
         double x2 = (double)(blockEntity.method_11016().method_10263() + 1);
         double y2 = (double)(blockEntity.method_11016().method_10264() + 1);
         double z2 = (double)(blockEntity.method_11016().method_10260() + 1);
         int excludeDir = 0;
         if (blockEntity instanceof class_2595) {
            class_2680 state = this.mc.field_1687.method_8320(blockEntity.method_11016());
            if ((state.method_26204() == class_2246.field_10034 || state.method_26204() == class_2246.field_10380) && state.method_11654(class_2281.field_10770) != class_2745.field_12569) {
               excludeDir = Dir.get(class_2281.method_9758(state));
            }
         }

         double a;
         if (blockEntity instanceof class_2595 || blockEntity instanceof class_2611) {
            a = 0.0625D;
            if (Dir.isNot(excludeDir, (byte)32)) {
               x1 += a;
            }

            if (Dir.isNot(excludeDir, (byte)8)) {
               z1 += a;
            }

            if (Dir.isNot(excludeDir, (byte)64)) {
               x2 -= a;
            }

            y2 -= a * 2.0D;
            if (Dir.isNot(excludeDir, (byte)16)) {
               z2 -= a;
            }
         }

         a = this.mc.field_1724.method_5649((double)blockEntity.method_11016().method_10263() + 0.5D, (double)blockEntity.method_11016().method_10264() + 0.5D, (double)blockEntity.method_11016().method_10260() + 0.5D);
         double a = 1.0D;
         if (a <= (Double)this.fadeDistance.get() * (Double)this.fadeDistance.get()) {
            a = a / ((Double)this.fadeDistance.get() * (Double)this.fadeDistance.get());
         }

         int prevLineA = this.lineColor.a;
         int prevSideA = this.sideColor.a;
         Color var10000 = this.lineColor;
         var10000.a = (int)((double)var10000.a * a);
         var10000 = this.sideColor;
         var10000.a = (int)((double)var10000.a * a);
         if (a >= 0.075D) {
            event.renderer.box(x1, y1, z1, x2, y2, z2, this.sideColor, this.lineColor, (ShapeMode)this.shapeMode.get(), excludeDir);
         }

         if ((Boolean)this.tracers.get()) {
            event.renderer.line(RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350, (double)blockEntity.method_11016().method_10263() + 0.5D, (double)blockEntity.method_11016().method_10264() + 0.5D, (double)blockEntity.method_11016().method_10260() + 0.5D, this.lineColor);
         }

         this.lineColor.a = prevLineA;
         this.sideColor.a = prevSideA;
         ++this.count;
      }
   }

   public String getInfoString() {
      return Integer.toString(this.count);
   }
}
