package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.events.render.RenderItemEntityEvent;
import meteordevelopment.meteorclient.mixininterface.IItemEntity;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1087;
import net.minecraft.class_1160;
import net.minecraft.class_1309;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1798;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_243;
import net.minecraft.class_2484;
import net.minecraft.class_265;
import net.minecraft.class_3486;
import net.minecraft.class_3726;
import net.minecraft.class_4608;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_809.class_811;

public class ItemPhysics extends Module {
   public ItemPhysics() {
      super(Categories.Render, "item-physics", "Applies physics to items on the ground.");
   }

   @EventHandler
   private void onRenderItemEntity(RenderItemEntityEvent event) {
      class_1799 itemStack = event.itemEntity.method_6983();
      int seed = itemStack.method_7960() ? 187 : class_1792.method_7880(itemStack.method_7909()) + itemStack.method_7919();
      event.random.setSeed((long)seed);
      event.matrixStack.method_22903();
      class_1087 bakedModel = event.itemRenderer.method_4019(itemStack, event.itemEntity.field_6002, (class_1309)null, 0);
      boolean hasDepthInGui = bakedModel.method_4712();
      int renderCount = this.getRenderedAmount(itemStack);
      IItemEntity rotator = (IItemEntity)event.itemEntity;
      boolean renderBlockFlat = false;
      if (event.itemEntity.method_6983().method_7909() instanceof class_1747 && !(event.itemEntity.method_6983().method_7909() instanceof class_1798)) {
         class_2248 b = ((class_1747)event.itemEntity.method_6983().method_7909()).method_7711();
         class_265 shape = b.method_9530(b.method_9564(), event.itemEntity.field_6002, event.itemEntity.method_24515(), class_3726.method_16194());
         if (shape.method_1105(class_2351.field_11052) <= 0.5D) {
            renderBlockFlat = true;
         }
      }

      class_1792 item = event.itemEntity.method_6983().method_7909();
      if (item instanceof class_1747 && !(item instanceof class_1798) && !renderBlockFlat) {
         event.matrixStack.method_22904(0.0D, -0.06D, 0.0D);
      }

      if (!renderBlockFlat) {
         event.matrixStack.method_22904(0.0D, 0.185D, 0.0D);
         event.matrixStack.method_22907(class_1160.field_20703.method_23626(1.571F));
         event.matrixStack.method_22904(0.0D, -0.185D, -0.0D);
      }

      boolean isAboveWater = event.itemEntity.field_6002.method_8320(event.itemEntity.method_24515()).method_26227().method_15772().method_15791(class_3486.field_15517);
      float scaleX;
      if (!event.itemEntity.method_24828() && !event.itemEntity.method_5869() && !isAboveWater) {
         scaleX = ((float)event.itemEntity.method_6985() + event.tickDelta) / 20.0F + event.itemEntity.field_7203;
         if (!renderBlockFlat) {
            event.matrixStack.method_22904(0.0D, 0.185D, 0.0D);
            event.matrixStack.method_22907(class_1160.field_20707.method_23626(scaleX));
            event.matrixStack.method_22904(0.0D, -0.185D, 0.0D);
            rotator.setRotation(new class_243(0.0D, 0.0D, (double)scaleX));
         } else {
            event.matrixStack.method_22907(class_1160.field_20705.method_23626(scaleX));
            rotator.setRotation(new class_243(0.0D, (double)scaleX, 0.0D));
            event.matrixStack.method_22904(0.0D, -0.065D, 0.0D);
         }

         if (event.itemEntity.method_6983().method_7909() instanceof class_1798) {
            event.matrixStack.method_22904(0.0D, 0.0D, 0.195D);
         } else if (!(event.itemEntity.method_6983().method_7909() instanceof class_1747)) {
            event.matrixStack.method_22904(0.0D, 0.0D, 0.195D);
         }
      } else if (event.itemEntity.method_6983().method_7909() instanceof class_1798) {
         event.matrixStack.method_22904(0.0D, 0.185D, 0.0D);
         event.matrixStack.method_22907(class_1160.field_20707.method_23626((float)rotator.getRotation().field_1350));
         event.matrixStack.method_22904(0.0D, -0.185D, 0.0D);
         event.matrixStack.method_22904(0.0D, 0.0D, 0.195D);
      } else if (renderBlockFlat) {
         event.matrixStack.method_22907(class_1160.field_20705.method_23626((float)rotator.getRotation().field_1351));
         event.matrixStack.method_22904(0.0D, -0.065D, 0.0D);
      } else {
         if (!(event.itemEntity.method_6983().method_7909() instanceof class_1747)) {
            event.matrixStack.method_22904(0.0D, 0.0D, 0.195D);
         }

         event.matrixStack.method_22904(0.0D, 0.185D, 0.0D);
         event.matrixStack.method_22907(class_1160.field_20707.method_23626((float)rotator.getRotation().field_1350));
         event.matrixStack.method_22904(0.0D, -0.185D, 0.0D);
      }

      if (event.itemEntity.field_6002.method_8320(event.itemEntity.method_24515()).method_26204().equals(class_2246.field_10114)) {
         event.matrixStack.method_22904(0.0D, 0.0D, -0.1D);
      }

      if (event.itemEntity.method_6983().method_7909() instanceof class_1747 && ((class_1747)event.itemEntity.method_6983().method_7909()).method_7711() instanceof class_2484) {
         event.matrixStack.method_22904(0.0D, 0.11D, 0.0D);
      }

      scaleX = bakedModel.method_4709().field_4303.field_4285.method_4943();
      float scaleY = bakedModel.method_4709().field_4303.field_4285.method_4945();
      float scaleZ = bakedModel.method_4709().field_4303.field_4285.method_4947();
      float x;
      float y;
      if (!hasDepthInGui) {
         float r = -0.0F * (float)renderCount * 0.5F * scaleX;
         x = -0.0F * (float)renderCount * 0.5F * scaleY;
         y = -0.09375F * (float)renderCount * 0.5F * scaleZ;
         event.matrixStack.method_22904((double)r, (double)x, (double)y);
      }

      for(int u = 0; u < renderCount; ++u) {
         event.matrixStack.method_22903();
         if (u > 0) {
            if (hasDepthInGui) {
               x = (event.random.nextFloat() * 2.0F - 1.0F) * 0.15F;
               y = (event.random.nextFloat() * 2.0F - 1.0F) * 0.15F;
               float z = (event.random.nextFloat() * 2.0F - 1.0F) * 0.15F;
               event.matrixStack.method_22904((double)x, (double)y, (double)z);
            } else {
               x = (event.random.nextFloat() * 2.0F - 1.0F) * 0.15F * 0.5F;
               y = (event.random.nextFloat() * 2.0F - 1.0F) * 0.15F * 0.5F;
               event.matrixStack.method_22904((double)x, (double)y, 0.0D);
               event.matrixStack.method_22907(class_1160.field_20707.method_23626(event.random.nextFloat()));
            }
         }

         event.itemRenderer.method_23179(itemStack, class_811.field_4318, false, event.matrixStack, event.vertexConsumerProvider, event.light, class_4608.field_21444, bakedModel);
         event.matrixStack.method_22909();
         if (!hasDepthInGui) {
            event.matrixStack.method_22904((double)(0.0F * scaleX), (double)(0.0F * scaleY), (double)(0.0625F * scaleZ));
         }
      }

      event.matrixStack.method_22909();
      event.setCancelled(true);
   }

   private int getRenderedAmount(class_1799 stack) {
      int i = 1;
      if (stack.method_7947() > 48) {
         i = 5;
      } else if (stack.method_7947() > 32) {
         i = 4;
      } else if (stack.method_7947() > 16) {
         i = 3;
      } else if (stack.method_7947() > 1) {
         i = 2;
      }

      return i;
   }
}
