package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.game.WindowResizedEvent;
import meteordevelopment.meteorclient.events.render.RenderAfterWorldEvent;
import meteordevelopment.meteorclient.gui.WidgetScreen;
import meteordevelopment.meteorclient.renderer.Framebuffer;
import meteordevelopment.meteorclient.renderer.GL;
import meteordevelopment.meteorclient.renderer.PostProcessRenderer;
import meteordevelopment.meteorclient.renderer.Shader;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.listeners.ConsumerListener;
import meteordevelopment.orbit.listeners.IListener;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_465;

public class Blur extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgScreens;
   private final Setting<Blur.Mode> mode;
   private final Setting<Integer> radius;
   private final Setting<Integer> fadeTime;
   private final Setting<Boolean> meteor;
   private final Setting<Boolean> inventories;
   private final Setting<Boolean> chat;
   private final Setting<Boolean> other;
   private Shader shader;
   private Framebuffer fbo1;
   private Framebuffer fbo2;
   private boolean enabled;
   private long fadeEndAt;

   public Blur() {
      super(Categories.Render, "blur", "Blurs background when in GUI screens.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgScreens = this.settings.createGroup("Screens");
      this.mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).description("Which mode the blur should use.")).defaultValue(Blur.Mode.Fancy)).build());
      this.radius = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("radius")).description("How large the blur should be.")).defaultValue(4)).min(1).sliderRange(1, 32).build());
      this.fadeTime = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("fade-time")).description("How long the fade will last in milliseconds.")).defaultValue(100)).min(0).sliderMax(500).build());
      this.meteor = this.sgScreens.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("meteor")).description("Applies blur to Meteor screens.")).defaultValue(true)).build());
      this.inventories = this.sgScreens.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("inventories")).description("Applies blur to inventory screens.")).defaultValue(true)).build());
      this.chat = this.sgScreens.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("chat")).description("Applies blur when in chat.")).defaultValue(false)).build());
      this.other = this.sgScreens.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("other")).description("Applies blur to all other screen types.")).defaultValue(true)).build());
      MeteorClient.EVENT_BUS.subscribe((IListener)(new ConsumerListener(WindowResizedEvent.class, (event) -> {
         if (this.fbo1 != null) {
            this.fbo1.resize();
            this.fbo2.resize();
         }

      })));
      MeteorClient.EVENT_BUS.subscribe((IListener)(new ConsumerListener(RenderAfterWorldEvent.class, (event) -> {
         this.onRenderAfterWorld();
      })));
   }

   private void onRenderAfterWorld() {
      boolean shouldRender = this.shouldRender();
      long time = System.currentTimeMillis();
      if (this.enabled) {
         if (!shouldRender) {
            if (this.fadeEndAt == -1L) {
               this.fadeEndAt = System.currentTimeMillis() + (long)(Integer)this.fadeTime.get();
            }

            if (time >= this.fadeEndAt) {
               this.enabled = false;
               this.fadeEndAt = -1L;
            }
         }
      } else if (shouldRender) {
         this.enabled = true;
         this.fadeEndAt = System.currentTimeMillis() + (long)(Integer)this.fadeTime.get();
      }

      if (this.enabled) {
         if (this.shader == null) {
            this.shader = new Shader("blur.vert", "blur.frag");
            this.fbo1 = new Framebuffer();
            this.fbo2 = new Framebuffer();
         }

         int sourceTexture = this.mc.method_1522().method_30277();
         this.shader.bind();
         this.shader.set("u_Size", (double)this.mc.method_22683().method_4489(), (double)this.mc.method_22683().method_4506());
         this.shader.set("u_Texture", 0);
         double progress = 1.0D;
         if (time < this.fadeEndAt) {
            if (shouldRender) {
               progress = 1.0D - (double)(this.fadeEndAt - time) / ((Integer)this.fadeTime.get()).doubleValue();
            } else {
               progress = (double)(this.fadeEndAt - time) / ((Integer)this.fadeTime.get()).doubleValue();
            }
         } else {
            this.fadeEndAt = -1L;
         }

         this.shader.set("u_Radius", Math.floor((double)(Integer)this.radius.get() * progress));
         PostProcessRenderer.beginRender();
         this.fbo1.bind();
         GL.bindTexture(sourceTexture);
         this.shader.set("u_Direction", 1.0D, 0.0D);
         PostProcessRenderer.render();
         if (this.mode.get() == Blur.Mode.Fancy) {
            this.fbo2.bind();
         } else {
            this.fbo2.unbind();
         }

         GL.bindTexture(this.fbo1.texture);
         this.shader.set("u_Direction", 0.0D, 1.0D);
         PostProcessRenderer.render();
         if (this.mode.get() == Blur.Mode.Fancy) {
            this.fbo1.bind();
            GL.bindTexture(this.fbo2.texture);
            this.shader.set("u_Direction", 1.0D, 0.0D);
            PostProcessRenderer.render();
            this.fbo2.unbind();
            GL.bindTexture(this.fbo1.texture);
            this.shader.set("u_Direction", 0.0D, 1.0D);
            PostProcessRenderer.render();
         }

         PostProcessRenderer.endRender();
      }
   }

   private boolean shouldRender() {
      if (!this.isActive()) {
         return false;
      } else {
         class_437 screen = this.mc.field_1755;
         if (screen instanceof WidgetScreen) {
            return (Boolean)this.meteor.get();
         } else if (screen instanceof class_465) {
            return (Boolean)this.inventories.get();
         } else if (screen instanceof class_408) {
            return (Boolean)this.chat.get();
         } else {
            return screen != null ? (Boolean)this.other.get() : false;
         }
      }
   }

   public static enum Mode {
      Fancy,
      Fast;

      // $FF: synthetic method
      private static Blur.Mode[] $values() {
         return new Blur.Mode[]{Fancy, Fast};
      }
   }
}
