package meteordevelopment.meteorclient.systems.modules.render.search;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BlockDataSetting;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.GenericSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.UnorderedArrayList;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.RainbowColors;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.Dimension;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_2248;
import net.minecraft.class_2791;
import net.minecraft.class_2338.class_2339;

public class Search extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<List<class_2248>> blocks;
   private final Setting<SBlockData> defaultBlockConfig;
   private final Setting<Map<class_2248, SBlockData>> blockConfigs;
   private final Setting<Boolean> tracers;
   private final class_2339 blockPos;
   private final Long2ObjectMap<SChunk> chunks;
   private final List<SGroup> groups;
   private Dimension lastDimension;

   public Search() {
      super(Categories.Render, "search", "Searches for specified blocks.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.blocks = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("blocks")).description("Blocks to search for.")).onChanged((blocks1) -> {
         if (this.isActive() && Utils.canUpdate()) {
            this.onActivate();
         }

      })).build());
      this.defaultBlockConfig = this.sgGeneral.add(((GenericSetting.Builder)((GenericSetting.Builder)((GenericSetting.Builder)(new GenericSetting.Builder()).name("default-block-config")).description("Default block config.")).defaultValue(new SBlockData(ShapeMode.Lines, new SettingColor(0, 255, 200), new SettingColor(0, 255, 200, 25), true, new SettingColor(0, 255, 200, 125)))).build());
      this.blockConfigs = this.sgGeneral.add(((BlockDataSetting.Builder)((BlockDataSetting.Builder)(new BlockDataSetting.Builder()).name("block-configs")).description("Config for each block.")).defaultData(this.defaultBlockConfig).build());
      this.tracers = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("tracers")).description("Render tracer lines.")).defaultValue(false)).build());
      this.blockPos = new class_2339();
      this.chunks = new Long2ObjectOpenHashMap();
      this.groups = new UnorderedArrayList();
      RainbowColors.register(this::onTickRainbow);
   }

   public void onActivate() {
      synchronized(this.chunks) {
         this.chunks.clear();
         this.groups.clear();
      }

      Iterator var1 = Utils.chunks().iterator();

      while(var1.hasNext()) {
         class_2791 chunk = (class_2791)var1.next();
         this.searchChunk(chunk, (ChunkDataEvent)null);
      }

      this.lastDimension = PlayerUtils.getDimension();
   }

   public void onDeactivate() {
      synchronized(this.chunks) {
         this.chunks.clear();
         this.groups.clear();
      }
   }

   private void onTickRainbow() {
      if (this.isActive()) {
         ((SBlockData)this.defaultBlockConfig.get()).tickRainbow();
         Iterator var1 = ((Map)this.blockConfigs.get()).values().iterator();

         while(var1.hasNext()) {
            SBlockData blockData = (SBlockData)var1.next();
            blockData.tickRainbow();
         }

      }
   }

   SBlockData getBlockData(class_2248 block) {
      SBlockData blockData = (SBlockData)((Map)this.blockConfigs.get()).get(block);
      return blockData == null ? (SBlockData)this.defaultBlockConfig.get() : blockData;
   }

   private void updateChunk(int x, int z) {
      SChunk chunk = (SChunk)this.chunks.get(class_1923.method_8331(x, z));
      if (chunk != null) {
         chunk.update();
      }

   }

   private void updateBlock(int x, int y, int z) {
      SChunk chunk = (SChunk)this.chunks.get(class_1923.method_8331(x >> 4, z >> 4));
      if (chunk != null) {
         chunk.update(x, y, z);
      }

   }

   public SBlock getBlock(int x, int y, int z) {
      SChunk chunk = (SChunk)this.chunks.get(class_1923.method_8331(x >> 4, z >> 4));
      return chunk == null ? null : chunk.get(x, y, z);
   }

   public SGroup newGroup(class_2248 block) {
      synchronized(this.chunks) {
         SGroup group = new SGroup(block);
         this.groups.add(group);
         return group;
      }
   }

   public void removeGroup(SGroup group) {
      synchronized(this.chunks) {
         this.groups.remove(group);
      }
   }

   @EventHandler
   private void onChunkData(ChunkDataEvent event) {
      this.searchChunk(event.chunk, event);
   }

   private void searchChunk(class_2791 chunk, ChunkDataEvent event) {
      MeteorExecutor.execute(() -> {
         if (this.isActive()) {
            SChunk schunk = SChunk.searchChunk(chunk, (List)this.blocks.get());
            if (schunk.size() > 0) {
               synchronized(this.chunks) {
                  this.chunks.put(chunk.method_12004().method_8324(), schunk);
                  schunk.update();
                  this.updateChunk(chunk.method_12004().field_9181 - 1, chunk.method_12004().field_9180);
                  this.updateChunk(chunk.method_12004().field_9181 + 1, chunk.method_12004().field_9180);
                  this.updateChunk(chunk.method_12004().field_9181, chunk.method_12004().field_9180 - 1);
                  this.updateChunk(chunk.method_12004().field_9181, chunk.method_12004().field_9180 + 1);
               }
            }

            if (event != null) {
               ChunkDataEvent.returnChunkDataEvent(event);
            }

         }
      });
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      int bx = event.pos.method_10263();
      int by = event.pos.method_10264();
      int bz = event.pos.method_10260();
      int chunkX = bx >> 4;
      int chunkZ = bz >> 4;
      long key = class_1923.method_8331(chunkX, chunkZ);
      boolean added = ((List)this.blocks.get()).contains(event.newState.method_26204()) && !((List)this.blocks.get()).contains(event.oldState.method_26204());
      boolean removed = !added && !((List)this.blocks.get()).contains(event.newState.method_26204()) && ((List)this.blocks.get()).contains(event.oldState.method_26204());
      if (added || removed) {
         MeteorExecutor.execute(() -> {
            synchronized(this.chunks) {
               SChunk chunk = (SChunk)this.chunks.get(key);
               if (chunk == null) {
                  chunk = new SChunk(chunkX, chunkZ);
                  if (chunk.shouldBeDeleted()) {
                     return;
                  }

                  this.chunks.put(key, chunk);
               }

               this.blockPos.method_10103(bx, by, bz);
               if (added) {
                  chunk.add(this.blockPos);
               } else {
                  chunk.remove(this.blockPos);
               }

               for(int x = -1; x < 2; ++x) {
                  for(int z = -1; z < 2; ++z) {
                     for(int y = -1; y < 2; ++y) {
                        if (x != 0 || y != 0 || z != 0) {
                           this.updateBlock(bx + x, by + y, bz + z);
                        }
                     }
                  }
               }

            }
         });
      }

   }

   @EventHandler
   private void onPostTick(TickEvent.Post event) {
      Dimension dimension = PlayerUtils.getDimension();
      if (this.lastDimension != dimension) {
         this.onActivate();
      }

      this.lastDimension = dimension;
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      synchronized(this.chunks) {
         ObjectIterator it = this.chunks.values().iterator();

         while(it.hasNext()) {
            SChunk chunk = (SChunk)it.next();
            if (chunk.shouldBeDeleted()) {
               MeteorExecutor.execute(() -> {
                  SBlock block;
                  for(ObjectIterator var1 = chunk.blocks.values().iterator(); var1.hasNext(); block.loaded = false) {
                     block = (SBlock)var1.next();
                     block.group.remove(block, false);
                  }

               });
               it.remove();
            } else {
               chunk.render(event);
            }
         }

         if ((Boolean)this.tracers.get()) {
            Iterator it = this.groups.iterator();

            while(it.hasNext()) {
               SGroup group = (SGroup)it.next();
               if (group.blocks.isEmpty()) {
                  it.remove();
               } else {
                  group.render(event);
               }
            }
         }

      }
   }
}
