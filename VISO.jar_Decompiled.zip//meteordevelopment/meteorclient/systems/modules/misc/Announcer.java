package meteordevelopment.meteorclient.systems.modules.misc;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.entity.DropItemsEvent;
import meteordevelopment.meteorclient.events.entity.player.BreakBlockEvent;
import meteordevelopment.meteorclient.events.entity.player.PickItemsEvent;
import meteordevelopment.meteorclient.events.entity.player.PlaceBlockEvent;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_465;

public class Announcer extends Module {
   private static final double TICK = 0.05D;
   private final Announcer.Feature[] features = new Announcer.Feature[]{new Announcer.Moving(), new Announcer.Mining(), new Announcer.Placing(), new Announcer.DropItems(), new Announcer.PickItems(), new Announcer.OpenContainer()};

   public Announcer() {
      super(Categories.Misc, "announcer", "Announces specified actions into chat.");
   }

   public void onActivate() {
      Announcer.Feature[] var1 = this.features;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         Announcer.Feature feature = var1[var3];
         if (feature.isEnabled()) {
            MeteorClient.EVENT_BUS.subscribe((Object)feature);
            feature.reset();
         }
      }

   }

   public void onDeactivate() {
      Announcer.Feature[] var1 = this.features;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         Announcer.Feature feature = var1[var3];
         if (feature.isEnabled()) {
            MeteorClient.EVENT_BUS.unsubscribe((Object)feature);
         }
      }

   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      Announcer.Feature[] var2 = this.features;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Announcer.Feature feature = var2[var4];
         if (feature.isEnabled()) {
            feature.tick();
         }
      }

   }

   private abstract class Feature {
      protected SettingGroup sg;
      private final Setting<Boolean> enabled;

      protected Feature(String name, String enabledName, String enabledDescription) {
         this.sg = Announcer.this.settings.createGroup(name);
         this.enabled = this.sg.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name(enabledName)).description(enabledDescription)).defaultValue(true)).onChanged((aBoolean) -> {
            if (Announcer.this.isActive() && this.isEnabled()) {
               MeteorClient.EVENT_BUS.subscribe((Object)this);
               this.reset();
            } else if (Announcer.this.isActive() && !this.isEnabled()) {
               MeteorClient.EVENT_BUS.unsubscribe((Object)this);
            }

         })).build());
      }

      abstract void reset();

      abstract void tick();

      boolean isEnabled() {
         return (Boolean)this.enabled.get();
      }
   }

   private class Moving extends Announcer.Feature {
      private final Setting<String> msg;
      private final Setting<Double> delay;
      private final Setting<Double> minDist;
      private double dist;
      private double timer;
      private double lastX;
      private double lastZ;
      private boolean first;

      Moving() {
         super("Moving", "moving-enabled", "Send msg how much you moved.");
         this.msg = this.sg.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("moving-msg")).description("The chat message for moving a certain amount of blocks.")).defaultValue("I just moved {dist} blocks!")).build());
         this.delay = this.sg.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("moving-delay")).description("The amount of delay between moving messages in seconds.")).defaultValue(10.0D).sliderMax(60.0D).build());
         this.minDist = this.sg.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("moving-min-dist")).description("The minimum distance for a moving message to send into chat.")).defaultValue(10.0D).sliderMax(100.0D).build());
      }

      void reset() {
         this.dist = 0.0D;
         this.timer = 0.0D;
         this.first = true;
      }

      void tick() {
         if (this.first) {
            this.first = false;
            this.updateLastPos();
         }

         double deltaX = Announcer.this.mc.field_1724.method_23317() - this.lastX;
         double deltaZ = Announcer.this.mc.field_1724.method_23321() - this.lastZ;
         this.dist += Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
         if (this.timer >= (Double)this.delay.get()) {
            this.timer = 0.0D;
            if (this.dist >= (Double)this.minDist.get()) {
               this.sendMsg();
               this.dist = 0.0D;
            }
         } else {
            this.timer += 0.05D;
         }

         this.updateLastPos();
      }

      void updateLastPos() {
         this.lastX = Announcer.this.mc.field_1724.method_23317();
         this.lastZ = Announcer.this.mc.field_1724.method_23321();
      }

      void sendMsg() {
         Announcer.this.mc.field_1724.method_3142(((String)this.msg.get()).replace("{dist}", String.format("%.1f", this.dist)));
      }
   }

   private class Mining extends Announcer.Feature {
      private final Setting<String> msg;
      private class_2248 lastBlock;
      private int count;
      private double notBrokenTimer;

      Mining() {
         super("Mining", "mining-enabled", "Send msg how much blocks you mined.");
         this.msg = this.sg.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("mining-msg")).description("The chat message for mining blocks.")).defaultValue("I just mined {count} {block}!")).build());
      }

      void reset() {
         this.lastBlock = null;
         this.count = 0;
         this.notBrokenTimer = 0.0D;
      }

      @EventHandler
      private void onBreakBlock(BreakBlockEvent event) {
         class_2248 block = event.getBlockState(Announcer.this.mc.field_1687).method_26204();
         if (this.lastBlock != null && this.lastBlock != block) {
            this.sendMsg();
         }

         this.lastBlock = block;
         ++this.count;
         this.notBrokenTimer = 0.0D;
      }

      void tick() {
         if (this.notBrokenTimer >= 2.0D) {
            this.sendMsg();
         } else {
            this.notBrokenTimer += 0.05D;
         }

      }

      void sendMsg() {
         if (this.count > 0) {
            Announcer.this.mc.field_1724.method_3142(((String)this.msg.get()).replace("{count}", Integer.toString(this.count)).replace("{block}", this.lastBlock.method_9518().getString()));
            this.count = 0;
         }

      }
   }

   private class Placing extends Announcer.Feature {
      private final Setting<String> msg;
      private class_2248 lastBlock;
      private int count;
      private double notPlacedTimer;

      Placing() {
         super("Placing", "placing-enabled", "Send msg how much blocks you placed.");
         this.msg = this.sg.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("placing-msg")).description("The chat message for placing blocks.")).defaultValue("I just placed {count} {block}!")).build());
      }

      void reset() {
         this.lastBlock = null;
         this.count = 0;
         this.notPlacedTimer = 0.0D;
      }

      @EventHandler
      private void onPlaceBlock(PlaceBlockEvent event) {
         if (this.lastBlock != null && this.lastBlock != event.block) {
            this.sendMsg();
         }

         this.lastBlock = event.block;
         ++this.count;
         this.notPlacedTimer = 0.0D;
      }

      void tick() {
         if (this.notPlacedTimer >= 2.0D) {
            this.sendMsg();
         } else {
            this.notPlacedTimer += 0.05D;
         }

      }

      void sendMsg() {
         if (this.count > 0) {
            Announcer.this.mc.field_1724.method_3142(((String)this.msg.get()).replace("{count}", Integer.toString(this.count)).replace("{block}", this.lastBlock.method_9518().getString()));
            this.count = 0;
         }

      }
   }

   private class DropItems extends Announcer.Feature {
      private final Setting<String> msg;
      private class_1792 lastItem;
      private int count;
      private double notDroppedTimer;

      DropItems() {
         super("Drop Items", "drop-items-enabled", "Send msg how much items you dropped.");
         this.msg = this.sg.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("drop-items-msg")).description("The chat message for dropping items.")).defaultValue("I just dropped {count} {item}!")).build());
      }

      void reset() {
         this.lastItem = null;
         this.count = 0;
         this.notDroppedTimer = 0.0D;
      }

      @EventHandler
      private void onDropItems(DropItemsEvent event) {
         if (this.lastItem != null && this.lastItem != event.itemStack.method_7909()) {
            this.sendMsg();
         }

         this.lastItem = event.itemStack.method_7909();
         this.count += event.itemStack.method_7947();
         this.notDroppedTimer = 0.0D;
      }

      void tick() {
         if (this.notDroppedTimer >= 1.0D) {
            this.sendMsg();
         } else {
            this.notDroppedTimer += 0.05D;
         }

      }

      void sendMsg() {
         if (this.count > 0) {
            Announcer.this.mc.field_1724.method_3142(((String)this.msg.get()).replace("{count}", Integer.toString(this.count)).replace("{item}", this.lastItem.method_7848().getString()));
            this.count = 0;
         }

      }
   }

   private class PickItems extends Announcer.Feature {
      private final Setting<String> msg;
      private class_1792 lastItem;
      private int count;
      private double notPickedUpTimer;

      PickItems() {
         super("Pick Items", "pick-items-enabled", "Send msg how much items you pick up.");
         this.msg = this.sg.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("pick-items-msg")).description("The chat message for picking up items.")).defaultValue("I just picked up {count} {item}!")).build());
      }

      void reset() {
         this.lastItem = null;
         this.count = 0;
         this.notPickedUpTimer = 0.0D;
      }

      @EventHandler
      private void onPickItems(PickItemsEvent event) {
         if (this.lastItem != null && this.lastItem != event.itemStack.method_7909()) {
            this.sendMsg();
         }

         this.lastItem = event.itemStack.method_7909();
         this.count += event.itemStack.method_7947();
         this.notPickedUpTimer = 0.0D;
      }

      void tick() {
         if (this.notPickedUpTimer >= 1.0D) {
            this.sendMsg();
         } else {
            this.notPickedUpTimer += 0.05D;
         }

      }

      void sendMsg() {
         if (this.count > 0) {
            Announcer.this.mc.field_1724.method_3142(((String)this.msg.get()).replace("{count}", Integer.toString(this.count)).replace("{item}", this.lastItem.method_7848().getString()));
            this.count = 0;
         }

      }
   }

   private class OpenContainer extends Announcer.Feature {
      private final Setting<String> msg;

      public OpenContainer() {
         super("Open Container", "open-container-enabled", "Sends msg when you open containers.");
         this.msg = this.sg.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("open-container-msg")).description("The chat message for opening a container.")).defaultValue("I just opened {name}!")).build());
      }

      void reset() {
      }

      void tick() {
      }

      @EventHandler
      private void onOpenScreen(OpenScreenEvent event) {
         if (event.screen instanceof class_465) {
            String name = event.screen.method_25440().getString();
            if (!name.isEmpty()) {
               this.sendMsg(name);
            }
         }

      }

      void sendMsg(String name) {
         Announcer.this.mc.field_1724.method_3142(((String)this.msg.get()).replace("{name}", name));
      }
   }
}
