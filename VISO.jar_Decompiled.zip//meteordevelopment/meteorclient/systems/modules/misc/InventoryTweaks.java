package meteordevelopment.meteorclient.systems.modules.misc;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.meteorclient.events.entity.DropItemsEvent;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.meteor.MouseButtonEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.CloseHandledScreenC2SPacketAccessor;
import meteordevelopment.meteorclient.mixin.HandledScreenAccessor;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.InventorySorter;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_2815;
import net.minecraft.class_437;
import net.minecraft.class_465;

public class InventoryTweaks extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgSorting;
   private final SettingGroup sgAutoDrop;
   private final SettingGroup sgAutoSteal;
   private final Setting<Boolean> mouseDragItemMove;
   private final Setting<List<class_1792>> antiDropItems;
   private final Setting<Boolean> buttons;
   private final Setting<Boolean> xCarry;
   private final Setting<Boolean> sortingEnabled;
   private final Setting<Keybind> sortingKey;
   private final Setting<Integer> sortingDelay;
   private final Setting<List<class_1792>> autoDropItems;
   private final Setting<Boolean> autoDropExcludeHotbar;
   private final Setting<Boolean> autoSteal;
   private final Setting<Boolean> autoDump;
   private final Setting<Integer> autoStealDelay;
   private final Setting<Integer> autoStealRandomDelay;
   private InventorySorter sorter;
   private boolean invOpened;

   public InventoryTweaks() {
      super(Categories.Misc, "inventory-tweaks", "Various inventory related utilities.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgSorting = this.settings.createGroup("Sorting");
      this.sgAutoDrop = this.settings.createGroup("Auto Drop");
      this.sgAutoSteal = this.settings.createGroup("Auto Steal");
      this.mouseDragItemMove = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("mouse-drag-item-move")).description("Moving mouse over items while holding shift will transfer it to the other container.")).defaultValue(true)).build());
      this.antiDropItems = this.sgGeneral.add(((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder()).name("anti-drop-items")).description("Items to prevent dropping. Doesn't work in creative inventory screen.")).build());
      this.buttons = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("inventory-buttons")).description("Shows steal and dump buttons in container guis.")).defaultValue(true)).build());
      this.xCarry = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("xcarry")).description("Allows you to store four extra items in your crafting grid.")).defaultValue(true)).onChanged((v) -> {
         if (!v && Utils.canUpdate()) {
            this.mc.field_1724.field_3944.method_2883(new class_2815(this.mc.field_1724.field_7498.field_7763));
            this.invOpened = false;
         }
      })).build());
      this.sortingEnabled = this.sgSorting.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("sorting-enabled")).description("Automatically sorts stacks in inventory.")).defaultValue(true)).build());
      SettingGroup var10001 = this.sgSorting;
      KeybindSetting.Builder var10002 = (KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder()).name("sorting-key")).description("Key to trigger the sort.");
      Setting var10003 = this.sortingEnabled;
      Objects.requireNonNull(var10003);
      this.sortingKey = var10001.add(((KeybindSetting.Builder)((KeybindSetting.Builder)var10002.visible(var10003::get)).defaultValue(Keybind.fromButton(2))).build());
      var10001 = this.sgSorting;
      IntSetting.Builder var1 = (IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("sorting-delay")).description("Delay in ticks between moving items when sorting.");
      var10003 = this.sortingEnabled;
      Objects.requireNonNull(var10003);
      this.sortingDelay = var10001.add(((IntSetting.Builder)((IntSetting.Builder)var1.visible(var10003::get)).defaultValue(1)).min(0).build());
      this.autoDropItems = this.sgAutoDrop.add(((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder()).name("auto-drop-items")).description("Items to drop.")).build());
      this.autoDropExcludeHotbar = this.sgAutoDrop.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("auto-drop-exclude-hotbar")).description("Whether or not to drop items from your hotbar.")).defaultValue(false)).build());
      this.autoSteal = this.sgAutoSteal.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("auto-steal")).description("Automatically removes all possible items when you open a container.")).defaultValue(false)).onChanged((val) -> {
         this.checkAutoStealSetttings();
      })).build());
      this.autoDump = this.sgAutoSteal.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("auto-dump")).description("Automatically dumps all possible items when you open a container.")).defaultValue(false)).onChanged((val) -> {
         this.checkAutoStealSetttings();
      })).build());
      this.autoStealDelay = this.sgAutoSteal.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("The minimum delay between stealing the next stack in milliseconds.")).defaultValue(20)).sliderMax(1000).build());
      this.autoStealRandomDelay = this.sgAutoSteal.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("random")).description("Randomly adds a delay of up to the specified time in milliseconds.")).min(0).sliderMax(1000).defaultValue(50)).build());
   }

   public void onActivate() {
      this.invOpened = false;
   }

   public void onDeactivate() {
      this.sorter = null;
      if (this.invOpened) {
         this.mc.field_1724.field_3944.method_2883(new class_2815(this.mc.field_1724.field_7498.field_7763));
      }

   }

   @EventHandler
   private void onKey(KeyEvent event) {
      if (event.action == KeyAction.Press && ((Keybind)this.sortingKey.get()).matches(true, event.key)) {
         this.sort();
      }

   }

   @EventHandler
   private void onMouseButton(MouseButtonEvent event) {
      if (event.action == KeyAction.Press && ((Keybind)this.sortingKey.get()).matches(false, event.button)) {
         this.sort();
      }

   }

   private void sort() {
      if ((Boolean)this.sortingEnabled.get()) {
         class_437 var2 = this.mc.field_1755;
         if (var2 instanceof class_465) {
            class_465<?> screen = (class_465)var2;
            if (this.sorter == null) {
               class_1735 focusedSlot = ((HandledScreenAccessor)screen).getFocusedSlot();
               if (focusedSlot == null) {
                  return;
               }

               this.sorter = new InventorySorter(screen, focusedSlot);
               return;
            }
         }
      }

   }

   @EventHandler
   private void onOpenScreen(OpenScreenEvent event) {
      this.sorter = null;
   }

   @EventHandler
   private void onTickPre(TickEvent.Pre event) {
      if (this.sorter != null && this.sorter.tick((Integer)this.sortingDelay.get())) {
         this.sorter = null;
      }

   }

   @EventHandler
   private void onTickPost(TickEvent.Post event) {
      if (!(this.mc.field_1755 instanceof class_465) && !((List)this.autoDropItems.get()).isEmpty()) {
         for(int i = (Boolean)this.autoDropExcludeHotbar.get() ? 9 : 0; i < this.mc.field_1724.method_31548().method_5439(); ++i) {
            if (((List)this.autoDropItems.get()).contains(this.mc.field_1724.method_31548().method_5438(i).method_7909())) {
               InvUtils.drop().slot(i);
            }
         }

      }
   }

   @EventHandler
   private void onDropItems(DropItemsEvent event) {
      if (((List)this.antiDropItems.get()).contains(event.itemStack.method_7909())) {
         event.cancel();
      }

   }

   @EventHandler
   private void onSendPacket(PacketEvent.Send event) {
      if ((Boolean)this.xCarry.get() && event.packet instanceof class_2815) {
         if (((CloseHandledScreenC2SPacketAccessor)event.packet).getSyncId() == this.mc.field_1724.field_7498.field_7763) {
            this.invOpened = true;
            event.cancel();
         }

      }
   }

   private void checkAutoStealSetttings() {
      if ((Boolean)this.autoSteal.get() && (Boolean)this.autoDump.get()) {
         ChatUtils.error("You can't enable Auto Steal and Auto Dump at the same time!");
         this.autoDump.set(false);
      }

   }

   private int getSleepTime() {
      return (Integer)this.autoStealDelay.get() + ((Integer)this.autoStealRandomDelay.get() > 0 ? ThreadLocalRandom.current().nextInt(0, (Integer)this.autoStealRandomDelay.get()) : 0);
   }

   private int getRows(class_1703 handler) {
      return handler instanceof class_1707 ? ((class_1707)handler).method_17388() : 3;
   }

   private void moveSlots(class_1703 handler, int start, int end) {
      for(int i = start; i < end; ++i) {
         if (handler.method_7611(i).method_7681()) {
            int sleep = this.getSleepTime();
            if (sleep > 0) {
               try {
                  Thread.sleep((long)sleep);
               } catch (InterruptedException var7) {
                  var7.printStackTrace();
               }
            }

            if (this.mc.field_1755 == null) {
               break;
            }

            InvUtils.quickMove().slotId(i);
         }
      }

   }

   public void steal(class_1703 handler) {
      MeteorExecutor.execute(() -> {
         this.moveSlots(handler, 0, this.getRows(handler) * 9);
      });
   }

   public void dump(class_1703 handler) {
      int playerInvOffset = this.getRows(handler) * 9;
      MeteorExecutor.execute(() -> {
         this.moveSlots(handler, playerInvOffset, playerInvOffset + 36);
      });
   }

   public boolean showButtons() {
      return this.isActive() && (Boolean)this.buttons.get();
   }

   public boolean autoSteal() {
      return this.isActive() && (Boolean)this.autoSteal.get();
   }

   public boolean autoDump() {
      return this.isActive() && (Boolean)this.autoDump.get();
   }

   public boolean mouseDragItemMove() {
      return this.isActive() && (Boolean)this.mouseDragItemMove.get();
   }
}
