package meteordevelopment.meteorclient.systems.modules.misc;

import it.unimi.dsi.fastutil.chars.Char2CharArrayMap;
import it.unimi.dsi.fastutil.chars.Char2CharMap;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.game.SendMessageEvent;
import meteordevelopment.meteorclient.mixin.ChatHudAccessor;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.commands.Commands;
import meteordevelopment.meteorclient.systems.commands.commands.SayCommand;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_2554;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2585;
import net.minecraft.class_303;
import net.minecraft.class_5481;
import net.minecraft.class_2558.class_2559;
import net.minecraft.class_2568.class_5247;

public class BetterChat extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgFilter;
   private final SettingGroup sgLongerChat;
   private final SettingGroup sgPrefix;
   private final SettingGroup sgSuffix;
   private final Setting<Boolean> annoy;
   private final Setting<Boolean> fancy;
   private final Setting<Boolean> timestamps;
   private final Setting<Boolean> playerHeads;
   private final Setting<Boolean> coordsProtection;
   private final Setting<Boolean> antiSpam;
   private final Setting<Integer> antiSpamDepth;
   private final Setting<Boolean> filterRegex;
   private final Setting<List<String>> regexFilters;
   private final Setting<Boolean> infiniteChatBox;
   private final Setting<Boolean> longerChatHistory;
   private final Setting<Integer> longerChatLines;
   private final Setting<Boolean> prefix;
   private final Setting<Boolean> prefixRandom;
   private final Setting<String> prefixText;
   private final Setting<Boolean> prefixSmallCaps;
   private final Setting<Boolean> suffix;
   private final Setting<Boolean> suffixRandom;
   private final Setting<String> suffixText;
   private final Setting<Boolean> suffixSmallCaps;
   private final Char2CharMap SMALL_CAPS;
   private final SimpleDateFormat dateFormat;

   public BetterChat() {
      super(Categories.Misc, "better-chat", "Improves your chat experience in various ways.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgFilter = this.settings.createGroup("Filter");
      this.sgLongerChat = this.settings.createGroup("Longer Chat");
      this.sgPrefix = this.settings.createGroup("Prefix");
      this.sgSuffix = this.settings.createGroup("Suffix");
      this.annoy = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("annoy")).description("Makes your messages aNnOyInG.")).defaultValue(false)).build());
      this.fancy = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("fancy-chat")).description("Makes your messages ғᴀɴᴄʏ!")).defaultValue(false)).build());
      this.timestamps = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("timestamps")).description("Adds client side time stamps to the beginning of chat messages.")).defaultValue(false)).build());
      this.playerHeads = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("player-heads")).description("Displays player heads next to their messages.")).defaultValue(true)).build());
      this.coordsProtection = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("coords-protection")).description("Prevents you from sending messages in chat that may contain coordinates.")).defaultValue(true)).build());
      this.antiSpam = this.sgFilter.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("anti-spam")).description("Blocks duplicate messages from filling your chat.")).defaultValue(true)).build());
      SettingGroup var10001 = this.sgFilter;
      IntSetting.Builder var10002 = ((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("depth")).description("How many messages to filter.")).defaultValue(20)).min(1).sliderMin(1);
      Setting var10003 = this.antiSpam;
      Objects.requireNonNull(var10003);
      this.antiSpamDepth = var10001.add(((IntSetting.Builder)var10002.visible(var10003::get)).build());
      this.filterRegex = this.sgFilter.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("filter-regex")).description("Filter out chat messages that match the regex filter.")).defaultValue(false)).build());
      var10001 = this.sgFilter;
      StringListSetting.Builder var4 = (StringListSetting.Builder)((StringListSetting.Builder)(new StringListSetting.Builder()).name("regex-filter")).description("Regex filter used for filtering chat messages.");
      var10003 = this.filterRegex;
      Objects.requireNonNull(var10003);
      this.regexFilters = var10001.add(((StringListSetting.Builder)var4.visible(var10003::get)).build());
      this.infiniteChatBox = this.sgLongerChat.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("infinite-chat-box")).description("Lets you type infinitely long messages.")).defaultValue(true)).build());
      this.longerChatHistory = this.sgLongerChat.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("longer-chat-history")).description("Extends chat length.")).defaultValue(true)).build());
      var10001 = this.sgLongerChat;
      var10002 = ((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("extra-lines")).description("The amount of extra chat lines.")).defaultValue(1000)).min(100).sliderRange(100, 1000);
      var10003 = this.longerChatHistory;
      Objects.requireNonNull(var10003);
      this.longerChatLines = var10001.add(((IntSetting.Builder)var10002.visible(var10003::get)).build());
      this.prefix = this.sgPrefix.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("prefix")).description("Adds a prefix to your chat messages.")).defaultValue(false)).build());
      this.prefixRandom = this.sgPrefix.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("random")).description("Uses a random number as your prefix.")).defaultValue(false)).build());
      this.prefixText = this.sgPrefix.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("text")).description("The text to add as your prefix.")).defaultValue("> ")).visible(() -> {
         return !(Boolean)this.prefixRandom.get();
      })).build());
      this.prefixSmallCaps = this.sgPrefix.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("small-caps")).description("Uses small caps in the prefix.")).defaultValue(false)).visible(() -> {
         return !(Boolean)this.prefixRandom.get();
      })).build());
      this.suffix = this.sgSuffix.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("suffix")).description("Adds a suffix to your chat messages.")).defaultValue(false)).build());
      this.suffixRandom = this.sgSuffix.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("random")).description("Uses a random number as your suffix.")).defaultValue(false)).build());
      this.suffixText = this.sgSuffix.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("text")).description("The text to add as your suffix.")).defaultValue(" | meteor on crack!")).visible(() -> {
         return !(Boolean)this.suffixRandom.get();
      })).build());
      this.suffixSmallCaps = this.sgSuffix.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("small-caps")).description("Uses small caps in the suffix.")).defaultValue(true)).visible(() -> {
         return !(Boolean)this.suffixRandom.get();
      })).build());
      this.SMALL_CAPS = new Char2CharArrayMap();
      this.dateFormat = new SimpleDateFormat("HH:mm");
      String[] a = "abcdefghijklmnopqrstuvwxyz".split("");
      String[] b = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴩqʀꜱᴛᴜᴠᴡxyᴢ".split("");

      for(int i = 0; i < a.length; ++i) {
         this.SMALL_CAPS.put(a[i].charAt(0), b[i].charAt(0));
      }

   }

   @EventHandler
   private void onMessageReceive(ReceiveMessageEvent event) {
      ((ChatHudAccessor)this.mc.field_1705.method_1743()).getVisibleMessages().removeIf((messagex) -> {
         return messagex.method_1413() == event.id && event.id != 0;
      });
      ((ChatHudAccessor)this.mc.field_1705.method_1743()).getMessages().removeIf((messagex) -> {
         return messagex.method_1413() == event.id && event.id != 0;
      });
      class_2561 message = event.getMessage();
      int i;
      if ((Boolean)this.filterRegex.get()) {
         for(i = 0; i < ((List)this.regexFilters.get()).size(); ++i) {
            Pattern p;
            try {
               p = Pattern.compile((String)((List)this.regexFilters.get()).get(i));
            } catch (PatternSyntaxException var6) {
               this.error("Removing Invalid regex: %s", new Object[]{((List)this.regexFilters.get()).get(i)});
               ((List)this.regexFilters.get()).remove(i);
               continue;
            }

            if (p.matcher(((class_2561)message).getString()).find()) {
               event.cancel();
               return;
            }
         }
      }

      if ((Boolean)this.timestamps.get()) {
         Matcher matcher = Pattern.compile("^(<[0-9]{2}:[0-9]{2}>\\s)").matcher(((class_2561)message).getString());
         if (matcher.matches()) {
            ((class_2561)message).method_10855().subList(0, 8).clear();
         }

         SimpleDateFormat var10002 = this.dateFormat;
         Date var10003 = new Date();
         class_2561 timestamp = (new class_2585("<" + var10002.format(var10003) + "> ")).method_27692(class_124.field_1080);
         message = (new class_2585("")).method_10852(timestamp).method_10852((class_2561)message);
      }

      if ((Boolean)this.playerHeads.get()) {
         message = (new class_2585("  ")).method_10852((class_2561)message);
      }

      for(i = 0; i < (Integer)this.antiSpamDepth.get(); ++i) {
         if ((Boolean)this.antiSpam.get()) {
            class_2561 antiSpammed = this.appendAntiSpam((class_2561)message, i);
            if (antiSpammed != null) {
               message = antiSpammed;
               ((ChatHudAccessor)this.mc.field_1705.method_1743()).getMessages().remove(i);
               ((ChatHudAccessor)this.mc.field_1705.method_1743()).getVisibleMessages().remove(i);
            }
         }
      }

      event.setMessage((class_2561)message);
   }

   private class_2561 appendAntiSpam(class_2561 text, int index) {
      List<class_303<class_5481>> visibleMessages = ((ChatHudAccessor)this.mc.field_1705.method_1743()).getVisibleMessages();
      if (!visibleMessages.isEmpty() && index >= 0 && index <= visibleMessages.size() - 1) {
         class_303<class_5481> visibleMessage = (class_303)visibleMessages.get(index);
         class_2585 parsed = new class_2585("");
         ((class_5481)visibleMessage.method_1412()).accept((ix, style, codePoint) -> {
            parsed.method_10852((new class_2585(new String(Character.toChars(codePoint)))).method_10862(style));
            return true;
         });
         String oldMessage = parsed.getString();
         String newMessage = text.getString();
         if (oldMessage.equals(newMessage)) {
            return parsed.method_10852((new class_2585(" (2)")).method_27692(class_124.field_1080));
         } else {
            Matcher matcher = Pattern.compile(".*(\\([0-9]+\\)$)").matcher(oldMessage);
            if (!matcher.matches()) {
               return null;
            } else {
               String group = matcher.group(matcher.groupCount());
               int number = Integer.parseInt(group.substring(1, group.length() - 1));
               String counter = " (" + number + ")";
               if (!oldMessage.substring(0, oldMessage.length() - counter.length()).equals(newMessage)) {
                  return null;
               } else {
                  for(int i = 0; i < counter.length(); ++i) {
                     parsed.method_10855().remove(parsed.method_10855().size() - 1);
                  }

                  return parsed.method_10852((new class_2585(" (" + (number + 1) + ")")).method_27692(class_124.field_1080));
               }
            }
         }
      } else {
         return null;
      }
   }

   @EventHandler
   private void onMessageSend(SendMessageEvent event) {
      String message = event.message;
      if ((Boolean)this.annoy.get()) {
         message = this.applyAnnoy(message);
      }

      if ((Boolean)this.fancy.get()) {
         message = this.applyFancy(message);
      }

      message = this.getPrefix() + message + this.getSuffix();
      if ((Boolean)this.coordsProtection.get() && this.containsCoordinates(message)) {
         class_2554 warningMessage = new class_2585("It looks like there are coordinates in your message! ");
         class_2554 sendButton = this.getSendButton(message);
         warningMessage.method_10852(sendButton);
         ChatUtils.sendMsg(warningMessage);
         event.cancel();
      } else {
         event.message = message;
      }
   }

   private String applyAnnoy(String message) {
      StringBuilder sb = new StringBuilder(message.length());
      boolean upperCase = true;
      int[] var4 = message.codePoints().toArray();
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         int cp = var4[var6];
         if (upperCase) {
            sb.appendCodePoint(Character.toUpperCase(cp));
         } else {
            sb.appendCodePoint(Character.toLowerCase(cp));
         }

         upperCase = !upperCase;
      }

      message = sb.toString();
      return message;
   }

   private String applyFancy(String message) {
      StringBuilder sb = new StringBuilder();
      char[] var3 = message.toCharArray();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         char ch = var3[var5];
         if (this.SMALL_CAPS.containsKey(ch)) {
            sb.append(this.SMALL_CAPS.get(ch));
         } else {
            sb.append(ch);
         }
      }

      return sb.toString();
   }

   private String getPrefix() {
      return (Boolean)this.prefix.get() ? this.getAffix((String)this.prefixText.get(), (Boolean)this.prefixSmallCaps.get(), (Boolean)this.prefixRandom.get()) : "";
   }

   private String getSuffix() {
      return (Boolean)this.suffix.get() ? this.getAffix((String)this.suffixText.get(), (Boolean)this.suffixSmallCaps.get(), (Boolean)this.suffixRandom.get()) : "";
   }

   private String getAffix(String text, boolean smallcaps, boolean random) {
      if (random) {
         return String.format("(%03d) ", Utils.random(0, 1000));
      } else {
         return smallcaps ? this.applyFancy(text) : text;
      }
   }

   private boolean containsCoordinates(String message) {
      return message.matches(".*(?<x>-?\\d{3,}(?:\\.\\d*)?)(?:\\s+(?<y>\\d{1,3}(?:\\.\\d*)?))?\\s+(?<z>-?\\d{3,}(?:\\.\\d*)?).*");
   }

   private class_2554 getSendButton(String message) {
      class_2554 sendButton = new class_2585("[SEND ANYWAY]");
      class_2554 hintBaseText = new class_2585("");
      class_2554 hintMsg = new class_2585("Send your message to the global chat even if there are coordinates:");
      hintMsg.method_10862(hintBaseText.method_10866().method_27706(class_124.field_1080));
      hintBaseText.method_10852(hintMsg);
      hintBaseText.method_10852(new class_2585("\n" + message));
      sendButton.method_10862(sendButton.method_10866().method_27706(class_124.field_1079).method_10958(new class_2558(class_2559.field_11750, ((SayCommand)Commands.get().get(SayCommand.class)).toString(new String[]{message}))).method_10949(new class_2568(class_5247.field_24342, hintBaseText)));
      return sendButton;
   }

   public boolean isInfiniteChatBox() {
      return this.isActive() && (Boolean)this.infiniteChatBox.get();
   }

   public boolean isLongerChat() {
      return this.isActive() && (Boolean)this.longerChatHistory.get();
   }

   public boolean displayPlayerHeads() {
      return this.isActive() && (Boolean)this.playerHeads.get();
   }

   public int getChatLength() {
      return (Integer)this.longerChatLines.get();
   }
}
