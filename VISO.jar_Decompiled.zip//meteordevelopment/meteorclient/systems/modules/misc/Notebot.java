package meteordevelopment.meteorclient.systems.modules.misc;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WLabel;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.notebot.NBSDecoder;
import meteordevelopment.meteorclient.utils.notebot.NotebotUtils;
import meteordevelopment.meteorclient.utils.notebot.nbs.Layer;
import meteordevelopment.meteorclient.utils.notebot.nbs.Note;
import meteordevelopment.meteorclient.utils.notebot.nbs.Song;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_156;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2428;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2885;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;

public class Notebot extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgRender;
   private final Setting<Integer> tickDelay;
   private final Setting<NotebotUtils.InstrumentType> instrument;
   private final Setting<Boolean> polyphonic;
   private final Setting<Boolean> render;
   private final Setting<ShapeMode> shapeMode;
   private final Setting<SettingColor> sideColor;
   private final Setting<SettingColor> lineColor;
   private final List<class_2338> possibleBlockPos;
   private final List<ImmutablePair<Integer, Integer>> song;
   private final List<Integer> uniqueNotes;
   private final HashMap<Integer, class_2338> blockPositions;
   private final List<class_2338> scannedNoteblocks;
   private Notebot.Stage stage;
   private boolean isPlaying;
   private int currentNote;
   private int currentIndex;
   private int offset;
   private int ticks;
   private boolean noSongsFound;
   private WLabel status;

   public Notebot() {
      super(Categories.Misc, "notebot", "Plays noteblock nicely");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgRender = this.settings.createGroup("Render", false);
      this.tickDelay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("tick-delay")).description("The delay when loading a song.")).defaultValue(2)).min(0).sliderMax(20).build());
      this.instrument = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("instrument")).description("Select which instrument will be played")).defaultValue(NotebotUtils.InstrumentType.NotDrums)).build());
      this.polyphonic = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("polyphonic")).description("Whether or not to allow multiple notes to be played at the same time")).defaultValue(true)).build());
      this.render = this.sgRender.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("render")).description("Whether or not to render the outline around the noteblocks.")).defaultValue(true)).build());
      this.shapeMode = this.sgRender.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
      this.sideColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 10))).build());
      this.lineColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 255))).build());
      this.possibleBlockPos = new ArrayList();
      this.song = new ArrayList();
      this.uniqueNotes = new ArrayList();
      this.blockPositions = new HashMap();
      this.scannedNoteblocks = new ArrayList();
      this.stage = Notebot.Stage.None;
      this.isPlaying = false;
      this.currentNote = 0;
      this.currentIndex = 0;
      this.offset = 0;
      this.ticks = 0;
      this.noSongsFound = true;

      for(int y = -5; y < 5; ++y) {
         for(int x = -5; x < 5; ++x) {
            if (y != 0 || x != 0) {
               class_2338 pos = new class_2338(x, 0, y);
               if (pos.method_10268(0.0D, 0.0D, 0.0D, true) < 17.99D) {
                  this.possibleBlockPos.add(pos);
               }
            }
         }
      }

      this.possibleBlockPos.sort(Comparator.comparingDouble((vec) -> {
         return vec.method_10262(new class_2382(0, 0, 0));
      }));
   }

   public String getInfoString() {
      return this.stage.toString();
   }

   public void onActivate() {
      this.ticks = 0;
      this.resetVariables();
   }

   private void resetVariables() {
      this.currentNote = 0;
      this.currentIndex = 0;
      this.offset = 0;
      this.isPlaying = false;
      this.stage = Notebot.Stage.None;
      this.song.clear();
      this.blockPositions.clear();
      this.uniqueNotes.clear();
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if ((Boolean)this.render.get()) {
         if (this.stage == Notebot.Stage.SetUp || this.stage == Notebot.Stage.Tune || this.isPlaying) {
            this.blockPositions.values().forEach((blockPos) -> {
               double x1 = (double)blockPos.method_10263();
               double y1 = (double)blockPos.method_10264();
               double z1 = (double)blockPos.method_10260();
               double x2 = (double)(blockPos.method_10263() + 1);
               double y2 = (double)(blockPos.method_10264() + 1);
               double z2 = (double)(blockPos.method_10260() + 1);
               event.renderer.box(x1, y1, z1, x2, y2, z2, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
            });
         }
      }
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      ++this.ticks;
      if (this.stage == Notebot.Stage.SetUp) {
         this.setup();
      } else if (this.stage == Notebot.Stage.Tune) {
         this.tune();
      } else if (this.stage == Notebot.Stage.Preview || this.stage == Notebot.Stage.Playing) {
         if (!this.isPlaying) {
            return;
         }

         if (this.mc.field_1724 != null && this.currentIndex < this.song.size()) {
            while((Integer)((ImmutablePair)this.song.get(this.currentIndex)).left < this.currentNote) {
               ++this.currentIndex;
            }

            do {
               if ((Integer)((ImmutablePair)this.song.get(this.currentIndex)).left != this.currentNote) {
                  ++this.currentNote;
                  if (this.status != null) {
                     this.status.set(this.getStatus());
                  }

                  return;
               }

               if (this.stage == Notebot.Stage.Preview) {
                  this.onTickPreview();
               } else {
                  this.onTickPlay();
               }

               ++this.currentIndex;
            } while(this.currentIndex < this.song.size());

            return;
         }

         this.stop();
         return;
      }

   }

   public WWidget getWidget(GuiTheme theme) {
      WTable table = theme.table();
      this.status = (WLabel)table.add(theme.label(this.getStatus())).expandCellX().widget();
      WButton pause = (WButton)table.add(theme.button(this.isPlaying ? "Pause" : "Resume")).right().widget();
      pause.action = () -> {
         this.pause();
         pause.set(this.isPlaying ? "Pause" : "Resume");
         this.status.set(this.getStatus());
      };
      WButton stop = (WButton)table.add(theme.button("Stop")).right().widget();
      stop.action = this::stop;
      table.row();
      this.noSongsFound = true;

      try {
         Files.list(MeteorClient.FOLDER.toPath().resolve("notebot")).forEach((path) -> {
            if (this.isValidFile(path)) {
               this.noSongsFound = false;
               table.add(theme.label(this.getFileLabel(path))).expandCellX();
               WButton load = (WButton)table.add(theme.button("Load")).right().widget();
               load.action = () -> {
                  this.loadSong(path.toFile());
                  this.status.set(this.getStatus());
               };
               WButton preview = (WButton)table.add(theme.button("Preview")).right().widget();
               preview.action = () -> {
                  this.previewSong(path.toFile());
                  this.status.set(this.getStatus());
               };
               table.row();
            }

         });
      } catch (IOException var6) {
         table.add(theme.label("Missing meteor-client/notebot folder.")).expandCellX();
         table.row();
      }

      if (this.noSongsFound) {
         table.add(theme.label("No songs found.")).expandCellX();
         table.row();
         WButton guide = (WButton)table.add(theme.button("Guide")).expandX().widget();
         guide.action = () -> {
            class_156.method_668().method_670("https://github.com/MeteorDevelopment/meteor-client/wiki/Notebot-Guide");
         };
      }

      return table;
   }

   private String getStatus() {
      if (!this.isActive()) {
         return "Module disabled.";
      } else if (this.song.isEmpty()) {
         return "No song loaded.";
      } else if (this.isPlaying) {
         return String.format("Playing song. %d/%d", this.currentIndex, this.song.size());
      } else if (this.stage != Notebot.Stage.Playing && this.stage != Notebot.Stage.Preview) {
         return this.stage != Notebot.Stage.SetUp && this.stage != Notebot.Stage.Tune ? String.format("Stage: %s.", this.stage.toString()) : "Setting up the noteblocks.";
      } else {
         return "Ready to play.";
      }
   }

   public void printStatus() {
      this.info(this.getStatus(), new Object[0]);
   }

   private String getFileLabel(Path file) {
      return file.getFileName().toString().replace(".txt", "").replace(".nbs", "");
   }

   private boolean isValidFile(Path file) {
      String extension = FilenameUtils.getExtension(file.toFile().getName());
      return extension.equals("txt") ? true : extension.equals("nbs");
   }

   public void play() {
      if (this.mc.field_1724 != null) {
         if (this.mc.field_1724.method_31549().field_7477 && this.stage != Notebot.Stage.Preview) {
            this.error("You need to be in survival mode.", new Object[0]);
         } else if (this.stage != Notebot.Stage.Preview && this.stage != Notebot.Stage.Playing) {
            this.error("No song loaded.", new Object[0]);
         } else {
            this.isPlaying = true;
            this.info("Playing.", new Object[0]);
         }

      }
   }

   public void pause() {
      if (!this.isActive()) {
         this.toggle();
      }

      if (this.isPlaying) {
         this.info("Pausing.", new Object[0]);
         this.isPlaying = false;
      } else {
         this.info("Resuming.", new Object[0]);
         this.isPlaying = true;
      }

   }

   public void stop() {
      this.info("Stopping.", new Object[0]);
      if (this.stage != Notebot.Stage.SetUp && this.stage != Notebot.Stage.Tune) {
         this.isPlaying = false;
         this.currentNote = 0;
         this.currentIndex = 0;
      } else {
         this.resetVariables();
      }

      if (this.status != null) {
         this.status.set(this.getStatus());
      }

   }

   public void disable() {
      this.resetVariables();
      this.info("Stopping.", new Object[0]);
      if (!this.isActive()) {
         this.toggle();
      }

   }

   public void loadSong(File file) {
      if (!this.isActive()) {
         this.toggle();
      }

      if (this.loadFileToMap(file)) {
         if (this.setupBlocks()) {
            this.info("Loading song \"%s\".", new Object[]{this.getFileLabel(file.toPath())});
         }
      }
   }

   public void previewSong(File file) {
      if (!this.isActive()) {
         this.toggle();
      }

      if (this.loadFileToMap(file)) {
         this.info("Song \"%s\" loaded.", new Object[]{this.getFileLabel(file.toPath())});
         this.stage = Notebot.Stage.Preview;
         this.play();
      }

   }

   private void addNote(int tick, int value) {
      if ((Boolean)this.polyphonic.get()) {
         this.song.add(new ImmutablePair(tick, value));
      } else if (this.song.size() == 0) {
         this.song.add(new ImmutablePair(tick, value));
      } else if ((Integer)((ImmutablePair)this.song.get(this.song.size() - 1)).left != tick) {
         this.song.add(new ImmutablePair(tick, value));
      }

   }

   private boolean loadFileToMap(File file) {
      if (file.exists() && file.isFile()) {
         String extension = FilenameUtils.getExtension(file.getName());
         boolean success = false;
         if (extension.equals("txt")) {
            success = this.loadTextFile(file);
         } else if (extension.equals("nbs")) {
            success = this.loadNbsFile(file);
         }

         if (success) {
            this.song.sort(Comparator.comparingInt((o) -> {
               return (Integer)o.left;
            }));
         }

         return success;
      } else {
         this.error("File not found", new Object[0]);
         return false;
      }
   }

   private boolean loadTextFile(File file) {
      List data;
      try {
         data = Files.readAllLines(file.toPath());
      } catch (IOException var8) {
         this.error("Error while reading \"%s\"", new Object[]{file.getName()});
         return false;
      }

      this.resetVariables();

      for(int i = 0; i < data.size(); ++i) {
         String[] parts = ((String)data.get(i)).split(":");
         if (parts.length < 2) {
            this.warning("Malformed line %d", new Object[]{i});
         } else {
            int key;
            int val;
            try {
               key = Integer.parseInt(parts[0]);
               val = Integer.parseInt(parts[1]);
               if (parts.length > 2) {
                  int type = Integer.parseInt(parts[2]);
                  if (!NotebotUtils.isValidIntrumentTextFile(type, (NotebotUtils.InstrumentType)this.instrument.get())) {
                     continue;
                  }
               }
            } catch (NumberFormatException var9) {
               this.warning("Invalid character at line %d", new Object[]{i});
               continue;
            }

            this.addNote(key, val);
         }
      }

      return true;
   }

   private boolean loadNbsFile(File file) {
      Song nbsSong = NBSDecoder.parse(file);
      if (nbsSong == null) {
         this.error("Couldn't parse the file. Only classic and opennbs v5 are supported", new Object[0]);
         return false;
      } else {
         List<Layer> layers = new ArrayList(nbsSong.getLayerHashMap().values());
         this.resetVariables();
         Iterator var4 = layers.iterator();

         label43:
         while(var4.hasNext()) {
            Layer layer = (Layer)var4.next();
            Iterator var6 = layer.getHashMap().keySet().iterator();

            while(true) {
               while(true) {
                  int tick;
                  Note note;
                  byte instr;
                  do {
                     do {
                        if (!var6.hasNext()) {
                           continue label43;
                        }

                        tick = (Integer)var6.next();
                        note = layer.getNote(tick);
                        tick = (int)((float)tick * nbsSong.getDelay());
                     } while(note == null);

                     instr = note.getInstrument();
                  } while(!NotebotUtils.isValidInstrumentNbsFile(instr, (NotebotUtils.InstrumentType)this.instrument.get()));

                  int n = Byte.toUnsignedInt(note.getKey());
                  n -= 33;
                  if (n >= 0 && n <= 24) {
                     this.addNote(tick, n);
                  } else {
                     this.warning("Note at tick %d out of range.", new Object[]{tick});
                  }
               }
            }
         }

         return true;
      }
   }

   private void scanForNoteblocks() {
      if (this.mc.field_1761 != null && this.mc.field_1687 != null && this.mc.field_1724 != null) {
         this.scannedNoteblocks.clear();
         int min = (int)(-this.mc.field_1761.method_2904()) - 1;
         int max = (int)this.mc.field_1761.method_2904() + 1;

         for(int x = min; x < max; ++x) {
            for(int y = min; y < max; ++y) {
               for(int z = min; z < max; ++z) {
                  class_2338 pos = this.mc.field_1724.method_24515().method_10069(x, y, z);
                  if (this.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10179) {
                     float reach = this.mc.field_1761.method_2904();
                     reach *= reach;
                     if (!(pos.method_19770(this.mc.field_1724.method_19538(), false) > (double)reach) && this.isValidScanSpot(pos) && NotebotUtils.isValidInstrument(pos, (NotebotUtils.InstrumentType)this.instrument.get())) {
                        this.scannedNoteblocks.add(pos);
                     }
                  }
               }
            }
         }

      }
   }

   private boolean setupBlocks() {
      this.song.forEach((v) -> {
         if (!this.uniqueNotes.contains(v.right)) {
            this.uniqueNotes.add((Integer)v.right);
         }

      });
      this.scanForNoteblocks();
      if (this.uniqueNotes.size() > this.possibleBlockPos.size() + this.scannedNoteblocks.size()) {
         this.error("Too many notes. %d is the maximum.", new Object[]{this.possibleBlockPos.size()});
         return false;
      } else {
         this.currentNote = 0;
         this.offset = 0;
         this.stage = Notebot.Stage.SetUp;
         return true;
      }
   }

   private void onTickPreview() {
      if ((Integer)((ImmutablePair)this.song.get(this.currentIndex)).left == this.currentNote) {
         this.mc.field_1724.method_5783(NotebotUtils.getInstrumentSound((NotebotUtils.InstrumentType)this.instrument.get()), 2.0F, (float)Math.pow(2.0D, (double)((Integer)((ImmutablePair)this.song.get(this.currentIndex)).right - 12) / 12.0D));
      }

   }

   private void setup() {
      if (this.ticks >= (Integer)this.tickDelay.get()) {
         this.ticks = 0;
         if (this.currentNote >= this.uniqueNotes.size()) {
            this.stage = Notebot.Stage.Playing;
            this.info("Loading done.", new Object[0]);
            this.play();
         } else {
            int index = this.currentNote + this.offset;
            class_2338 pos;
            if (index < this.scannedNoteblocks.size()) {
               pos = (class_2338)this.scannedNoteblocks.get(index);
               if (this.mc.field_1687.method_8320(pos).method_26204() != class_2246.field_10179) {
                  ++this.offset;
               } else {
                  this.blockPositions.put((Integer)this.uniqueNotes.get(this.currentNote), pos);
                  this.stage = Notebot.Stage.Tune;
               }

            } else {
               FindItemResult noteBlock = InvUtils.findInHotbar(class_1802.field_8643);
               if (!noteBlock.found()) {
                  this.error("Not enough noteblocks", new Object[0]);
                  this.disable();
               } else {
                  index -= this.scannedNoteblocks.size();

                  try {
                     pos = this.mc.field_1724.method_24515().method_10081((class_2382)this.possibleBlockPos.get(index));
                  } catch (IndexOutOfBoundsException var5) {
                     this.error("Not enough valid positions.", new Object[0]);
                     this.disable();
                     return;
                  }

                  if (this.isValidEmptySpot(pos) && NotebotUtils.isValidInstrument(pos, (NotebotUtils.InstrumentType)this.instrument.get())) {
                     if (!BlockUtils.place(pos, noteBlock, true, 100, true)) {
                        ++this.offset;
                     } else {
                        this.blockPositions.put((Integer)this.uniqueNotes.get(this.currentNote), pos);
                        this.stage = Notebot.Stage.Tune;
                     }

                  } else {
                     ++this.offset;
                  }
               }
            }
         }
      }
   }

   private void tune() {
      if (this.ticks >= (Integer)this.tickDelay.get()) {
         this.ticks = 0;
         class_2338 pos = (class_2338)this.blockPositions.get(this.uniqueNotes.get(this.currentNote));
         if (pos != null) {
            Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), 100, this::tuneRotate);
         }
      }
   }

   private void tuneRotate() {
      class_2338 pos = (class_2338)this.blockPositions.get(this.uniqueNotes.get(this.currentNote));
      if (pos != null) {
         if (!this.tuneBlock(pos, (Integer)this.uniqueNotes.get(this.currentNote))) {
            this.disable();
         }

      }
   }

   private boolean tuneBlock(class_2338 pos, int note) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         class_2680 block = this.mc.field_1687.method_8320(pos);
         if (block.method_26204() != class_2246.field_10179) {
            ++this.offset;
            this.stage = Notebot.Stage.SetUp;
            return true;
         } else if (((Integer)block.method_11654(class_2428.field_11324)).equals(note)) {
            ++this.currentNote;
            this.stage = Notebot.Stage.SetUp;
            return true;
         } else {
            this.mc.field_1724.field_3944.method_2883(new class_2885(class_1268.field_5808, new class_3965(this.mc.field_1724.method_19538(), this.rayTraceCheck(pos), pos, true)));
            this.mc.field_1724.method_6104(class_1268.field_5808);
            return true;
         }
      } else {
         return false;
      }
   }

   private void onTickPlay() {
      if ((Integer)((ImmutablePair)this.song.get(this.currentIndex)).left == this.currentNote) {
         int note = (Integer)((ImmutablePair)this.song.get(this.currentIndex)).right;
         class_2338 pos = (class_2338)this.blockPositions.get(note);
         if ((Boolean)this.polyphonic.get()) {
            Rotations.setCamRotation(Rotations.getYaw(pos), Rotations.getPitch(pos));
            this.playRotate();
         } else {
            Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), 100, this::playRotate);
         }
      }

   }

   private void playRotate() {
      if (this.mc.field_1761 != null) {
         try {
            int note = (Integer)((ImmutablePair)this.song.get(this.currentIndex)).right;
            class_2338 pos = (class_2338)this.blockPositions.get(note);
            this.mc.field_1761.method_2910(pos, class_2350.field_11033);
         } catch (NullPointerException var3) {
         }

      }
   }

   private boolean isValidEmptySpot(class_2338 pos) {
      if (!this.mc.field_1687.method_8320(pos).method_26215()) {
         return false;
      } else if (!this.mc.field_1687.method_8320(pos.method_10084()).method_26215()) {
         return false;
      } else {
         return this.mc.field_1687.method_8320(pos.method_10074()).method_26204() != class_2246.field_10179;
      }
   }

   private boolean isValidScanSpot(class_2338 pos) {
      return this.mc.field_1687.method_8320(pos).method_26204() != class_2246.field_10179 ? false : this.mc.field_1687.method_8320(pos.method_10084()).method_26215();
   }

   private class_2350 rayTraceCheck(class_2338 pos) {
      class_243 eyesPos = new class_243(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318() + (double)this.mc.field_1724.method_18381(this.mc.field_1724.method_18376()), this.mc.field_1724.method_23321());
      class_2350[] var3 = class_2350.values();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         class_2350 direction = var3[var5];
         class_3959 raycastContext = new class_3959(eyesPos, new class_243((double)pos.method_10263() + 0.5D + (double)direction.method_10163().method_10263() * 0.5D, (double)pos.method_10264() + 0.5D + (double)direction.method_10163().method_10264() * 0.5D, (double)pos.method_10260() + 0.5D + (double)direction.method_10163().method_10260() * 0.5D), class_3960.field_17558, class_242.field_1348, this.mc.field_1724);
         class_3965 result = this.mc.field_1687.method_17742(raycastContext);
         if (result != null && result.method_17783() == class_240.field_1332 && result.method_17777().equals(pos)) {
            return direction;
         }
      }

      if ((double)pos.method_10264() > eyesPos.field_1351) {
         return class_2350.field_11033;
      } else {
         return class_2350.field_11036;
      }
   }

   private static enum Stage {
      None,
      SetUp,
      Tune,
      Playing,
      Preview;

      // $FF: synthetic method
      private static Notebot.Stage[] $values() {
         return new Notebot.Stage[]{None, SetUp, Tune, Playing, Preview};
      }
   }
}
