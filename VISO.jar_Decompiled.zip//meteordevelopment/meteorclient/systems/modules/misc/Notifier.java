package meteordevelopment.meteorclient.systems.modules.misc;

import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.UUID;
import meteordevelopment.meteorclient.events.entity.EntityAddedEvent;
import meteordevelopment.meteorclient.events.entity.EntityRemovedEvent;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.fakeplayer.FakePlayerEntity;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_2585;
import net.minecraft.class_2663;
import net.minecraft.class_5250;

public class Notifier extends Module {
   private final SettingGroup sgTotemPops;
   private final SettingGroup sgVisualRange;
   private final Setting<Boolean> totemPops;
   private final Setting<Boolean> totemsIgnoreOwn;
   private final Setting<Boolean> totemsIgnoreFriends;
   private final Setting<Boolean> totemsIgnoreOthers;
   private final Setting<Boolean> visualRange;
   private final Setting<Notifier.Event> event;
   private final Setting<Object2BooleanMap<class_1299<?>>> entities;
   private final Setting<Boolean> visualRangeIgnoreFriends;
   private final Setting<Boolean> visualRangeIgnoreFakes;
   private final Object2IntMap<UUID> totemPopMap;
   private final Object2IntMap<UUID> chatIdMap;
   private final Random random;

   public Notifier() {
      super(Categories.Misc, "notifier", "Notifies you of different events.");
      this.sgTotemPops = this.settings.createGroup("Totem Pops");
      this.sgVisualRange = this.settings.createGroup("Visual Range");
      this.totemPops = this.sgTotemPops.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("totem-pops")).description("Notifies you when a player pops a totem.")).defaultValue(true)).build());
      this.totemsIgnoreOwn = this.sgTotemPops.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ignore-own")).description("Notifies you of your own totem pops.")).defaultValue(false)).build());
      this.totemsIgnoreFriends = this.sgTotemPops.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ignore-friends")).description("Ignores friends totem pops.")).defaultValue(false)).build());
      this.totemsIgnoreOthers = this.sgTotemPops.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ignore-others")).description("Ignores other players totem pops.")).defaultValue(false)).build());
      this.visualRange = this.sgVisualRange.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("visual-range")).description("Notifies you when an entity enters your render distance.")).defaultValue(false)).build());
      this.event = this.sgVisualRange.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("event")).description("When to log the entities.")).defaultValue(Notifier.Event.Both)).build());
      this.entities = this.sgVisualRange.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder()).name("entities")).description("Which entities to nofity about.")).defaultValue(class_1299.field_6097).build());
      this.visualRangeIgnoreFriends = this.sgVisualRange.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ignore-friends")).description("Ignores friends.")).defaultValue(true)).build());
      this.visualRangeIgnoreFakes = this.sgVisualRange.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ignore-fake-players")).description("Ignores fake players.")).defaultValue(true)).build());
      this.totemPopMap = new Object2IntOpenHashMap();
      this.chatIdMap = new Object2IntOpenHashMap();
      this.random = new Random();
   }

   @EventHandler
   private void onEntityAdded(EntityAddedEvent event) {
      if (!event.entity.method_5667().equals(this.mc.field_1724.method_5667()) && ((Object2BooleanMap)this.entities.get()).getBoolean(event.entity.method_5864()) && (Boolean)this.visualRange.get() && this.event.get() != Notifier.Event.Despawn) {
         if (event.entity instanceof class_1657) {
            if ((!(Boolean)this.visualRangeIgnoreFriends.get() || !Friends.get().isFriend((class_1657)event.entity)) && (!(Boolean)this.visualRangeIgnoreFakes.get() || !(event.entity instanceof FakePlayerEntity))) {
               ChatUtils.sendMsg(event.entity.method_5628() + 100, class_124.field_1080, "(highlight)%s(default) has entered your visual range!", event.entity.method_5820());
            }
         } else {
            class_5250 text = (new class_2585(event.entity.method_5864().method_5897().getString())).method_27692(class_124.field_1068);
            text.method_10852((new class_2585(" has spawned at ")).method_27692(class_124.field_1080));
            text.method_10852(ChatUtils.formatCoords(event.entity.method_19538()));
            text.method_10852((new class_2585(".")).method_27692(class_124.field_1080));
            this.info(text);
         }

      }
   }

   @EventHandler
   private void onEntityRemoved(EntityRemovedEvent event) {
      if (!event.entity.method_5667().equals(this.mc.field_1724.method_5667()) && ((Object2BooleanMap)this.entities.get()).getBoolean(event.entity.method_5864()) && (Boolean)this.visualRange.get() && this.event.get() != Notifier.Event.Spawn) {
         if (event.entity instanceof class_1657) {
            if ((!(Boolean)this.visualRangeIgnoreFriends.get() || !Friends.get().isFriend((class_1657)event.entity)) && (!(Boolean)this.visualRangeIgnoreFakes.get() || !(event.entity instanceof FakePlayerEntity))) {
               ChatUtils.sendMsg(event.entity.method_5628() + 100, class_124.field_1080, "(highlight)%s(default) has left your visual range!", event.entity.method_5820());
            }
         } else {
            class_5250 text = (new class_2585(event.entity.method_5864().method_5897().getString())).method_27692(class_124.field_1068);
            text.method_10852((new class_2585(" has despawned at ")).method_27692(class_124.field_1080));
            text.method_10852(ChatUtils.formatCoords(event.entity.method_19538()));
            text.method_10852((new class_2585(".")).method_27692(class_124.field_1080));
            this.info(text);
         }

      }
   }

   public void onActivate() {
      this.totemPopMap.clear();
      this.chatIdMap.clear();
   }

   @EventHandler
   private void onGameJoin(GameJoinedEvent event) {
      this.totemPopMap.clear();
      this.chatIdMap.clear();
   }

   @EventHandler
   private void onReceivePacket(PacketEvent.Receive event) {
      if ((Boolean)this.totemPops.get()) {
         if (event.packet instanceof class_2663) {
            class_2663 p = (class_2663)event.packet;
            if (p.method_11470() == 35) {
               class_1297 entity = p.method_11469(this.mc.field_1687);
               if (entity instanceof class_1657) {
                  if ((!entity.equals(this.mc.field_1724) || !(Boolean)this.totemsIgnoreOwn.get()) && (!Friends.get().isFriend((class_1657)entity) || !(Boolean)this.totemsIgnoreOthers.get()) && (Friends.get().isFriend((class_1657)entity) || !(Boolean)this.totemsIgnoreFriends.get())) {
                     synchronized(this.totemPopMap) {
                        int pops = this.totemPopMap.getOrDefault(entity.method_5667(), 0);
                        Object2IntMap var10000 = this.totemPopMap;
                        UUID var10001 = entity.method_5667();
                        ++pops;
                        var10000.put(var10001, pops);
                        ChatUtils.sendMsg(this.getChatId(entity), class_124.field_1080, "(highlight)%s (default)popped (highlight)%d (default)%s.", entity.method_5820(), pops, pops == 1 ? "totem" : "totems");
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if ((Boolean)this.totemPops.get()) {
         synchronized(this.totemPopMap) {
            Iterator var3 = this.mc.field_1687.method_18456().iterator();

            while(true) {
               class_1657 player;
               do {
                  do {
                     if (!var3.hasNext()) {
                        return;
                     }

                     player = (class_1657)var3.next();
                  } while(!this.totemPopMap.containsKey(player.method_5667()));
               } while(player.field_6213 <= 0 && !(player.method_6032() <= 0.0F));

               int pops = this.totemPopMap.removeInt(player.method_5667());
               ChatUtils.sendMsg(this.getChatId(player), class_124.field_1080, "(highlight)%s (default)died after popping (highlight)%d (default)%s.", player.method_5820(), pops, pops == 1 ? "totem" : "totems");
               this.chatIdMap.removeInt(player.method_5667());
            }
         }
      }
   }

   private int getChatId(class_1297 entity) {
      return this.chatIdMap.computeIntIfAbsent(entity.method_5667(), (value) -> {
         return this.random.nextInt();
      });
   }

   public static enum Event {
      Spawn,
      Despawn,
      Both;

      // $FF: synthetic method
      private static Notifier.Event[] $values() {
         return new Notifier.Event[]{Spawn, Despawn, Both};
      }
   }
}
