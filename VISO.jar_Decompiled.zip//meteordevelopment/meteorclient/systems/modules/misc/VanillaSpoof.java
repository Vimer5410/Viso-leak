package meteordevelopment.meteorclient.systems.modules.misc;

import io.netty.buffer.Unpooled;
import java.nio.charset.StandardCharsets;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.mixin.CustomPayloadC2SPacketAccessor;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2540;
import net.minecraft.class_2817;
import net.minecraft.class_2960;
import org.apache.commons.lang3.StringUtils;

public class VanillaSpoof extends Module {
   public VanillaSpoof() {
      super(Categories.Misc, "vanilla-spoof", "When connecting to a server it spoofs the client name to be 'vanilla'.");
      MeteorClient.EVENT_BUS.subscribe((Object)(new VanillaSpoof.Listener()));
   }

   private class Listener {
      @EventHandler
      private void onPacketSend(PacketEvent.Send event) {
         if (VanillaSpoof.this.isActive() && event.packet instanceof class_2817) {
            CustomPayloadC2SPacketAccessor packet = (CustomPayloadC2SPacketAccessor)event.packet;
            class_2960 id = packet.getChannel();
            if (id.equals(class_2817.field_12831)) {
               packet.setData((new class_2540(Unpooled.buffer())).method_10814("vanilla"));
            } else if (StringUtils.containsIgnoreCase(packet.getData().toString(StandardCharsets.UTF_8), "fabric")) {
               event.cancel();
            }

         }
      }
   }
}
