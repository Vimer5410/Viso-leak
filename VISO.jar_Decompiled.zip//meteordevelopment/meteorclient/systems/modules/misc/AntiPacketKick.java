package meteordevelopment.meteorclient.systems.modules.misc;

import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;

public class AntiPacketKick extends Module {
   public AntiPacketKick() {
      super(Categories.Misc, "anti-packet-kick", "Attempts to prevent you from being disconnected by large packets.");
   }
}
