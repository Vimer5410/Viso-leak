package meteordevelopment.meteorclient.systems.modules.misc;

import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;

public class NameProtect extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<String> name;
   private String username;

   public NameProtect() {
      super(Categories.Player, "name-protect", "Hides your name client-side.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.name = this.sgGeneral.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("name")).description("Name to be replaced with.")).defaultValue("seasnail")).build());
      this.username = "If you see this, something is wrong.";
   }

   public void onActivate() {
      this.username = this.mc.method_1548().method_1676();
   }

   public String replaceName(String string) {
      return string != null && this.isActive() ? string.replace(this.username, (CharSequence)this.name.get()) : string;
   }

   public String getName(String original) {
      return ((String)this.name.get()).length() > 0 && this.isActive() ? (String)this.name.get() : original;
   }
}
