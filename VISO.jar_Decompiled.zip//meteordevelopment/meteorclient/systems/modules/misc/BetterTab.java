package meteordevelopment.meteorclient.systems.modules.misc;

import java.util.Objects;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friend;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_5251;
import net.minecraft.class_640;

public class BetterTab extends Module {
   private final SettingGroup sgGeneral;
   public final Setting<Integer> tabSize;
   private final Setting<Boolean> self;
   private final Setting<SettingColor> selfColor;
   private final Setting<Boolean> friends;
   public final Setting<Boolean> accurateLatency;

   public BetterTab() {
      super(Categories.Misc, "better-tab", "Various improvements to the tab list.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.tabSize = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("tablist-size")).description("Bypasses the 80 player limit on the tablist.")).defaultValue(100)).min(1).sliderRange(1, 1000).build());
      this.self = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("highlight-self")).description("Highlights yourself in the tablist.")).defaultValue(true)).build());
      SettingGroup var10001 = this.sgGeneral;
      ColorSetting.Builder var10002 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("self-color")).description("The color to highlight your name with.")).defaultValue(new SettingColor(250, 130, 30));
      Setting var10003 = this.self;
      Objects.requireNonNull(var10003);
      this.selfColor = var10001.add(((ColorSetting.Builder)var10002.visible(var10003::get)).build());
      this.friends = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("highlight-friends")).description("Highlights friends in the tablist.")).defaultValue(true)).build());
      this.accurateLatency = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("accurate-latency")).description("Shows latency as a number in the tablist.")).defaultValue(true)).build());
   }

   public class_2561 getPlayerName(class_640 playerListEntry) {
      Color color = null;
      class_2561 name = playerListEntry.method_2971();
      if (name == null) {
         name = new class_2585(playerListEntry.method_2966().getName());
      }

      if (playerListEntry.method_2966().getId().toString().equals(this.mc.field_1724.method_7334().getId().toString()) && (Boolean)this.self.get()) {
         color = (Color)this.selfColor.get();
      } else if ((Boolean)this.friends.get() && Friends.get().get(playerListEntry.method_2966().getName()) != null) {
         Friend friend = Friends.get().get(playerListEntry.method_2966().getName());
         if (friend != null) {
            color = Friends.get().color;
         }
      }

      if (color != null) {
         String nameString = ((class_2561)name).getString();
         class_124[] var5 = class_124.values();
         int var6 = var5.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            class_124 format = var5[var7];
            if (format.method_543()) {
               nameString = nameString.replace(format.toString(), "");
            }
         }

         name = (new class_2585(nameString)).method_10862(((class_2561)name).method_10866().method_27703(new class_5251(((Color)color).getPacked())));
      }

      return (class_2561)name;
   }
}
