package meteordevelopment.meteorclient.systems.modules.misc;

import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.orbit.EventHandler;
import org.apache.commons.lang3.RandomStringUtils;

public class Spam extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<List<String>> messages;
   private final Setting<Integer> delay;
   private final Setting<Boolean> random;
   private final Setting<Boolean> bypass;
   private final Setting<Integer> length;
   private int messageI;
   private int timer;

   public Spam() {
      super(Categories.Misc, "spam", "Spams specified messages in chat.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.messages = this.sgGeneral.add(((StringListSetting.Builder)((StringListSetting.Builder)(new StringListSetting.Builder()).name("messages")).description("Messages to use for spam.")).build());
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("The delay between specified messages in ticks.")).defaultValue(20)).min(0).sliderMax(200).build());
      this.random = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("randomise")).description("Selects a random message from your spam message list.")).defaultValue(false)).build());
      this.bypass = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("bypass")).description("Add random text at the end of the message to try to bypass anti spams.")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      IntSetting.Builder var10002 = (IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("length")).description("Number of characters used to bypass anti spam.");
      Setting var10003 = this.bypass;
      Objects.requireNonNull(var10003);
      this.length = var10001.add(((IntSetting.Builder)((IntSetting.Builder)var10002.visible(var10003::get)).defaultValue(16)).sliderRange(1, 256).build());
   }

   public void onActivate() {
      this.timer = (Integer)this.delay.get();
      this.messageI = 0;
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (!((List)this.messages.get()).isEmpty()) {
         if (this.timer <= 0) {
            int i;
            if ((Boolean)this.random.get()) {
               i = Utils.random(0, ((List)this.messages.get()).size());
            } else {
               if (this.messageI >= ((List)this.messages.get()).size()) {
                  this.messageI = 0;
               }

               i = this.messageI++;
            }

            String text = (String)((List)this.messages.get()).get(i);
            if ((Boolean)this.bypass.get()) {
               text = text + " " + RandomStringUtils.randomAlphabetic((Integer)this.length.get()).toLowerCase();
            }

            this.mc.field_1724.method_3142(text);
            this.timer = (Integer)this.delay.get();
         } else {
            --this.timer;
         }

      }
   }
}
