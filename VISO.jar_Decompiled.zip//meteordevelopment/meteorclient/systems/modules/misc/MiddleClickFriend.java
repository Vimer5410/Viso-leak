package meteordevelopment.meteorclient.systems.modules.misc;

import meteordevelopment.meteorclient.events.meteor.MouseButtonEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friend;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;

public class MiddleClickFriend extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> message;

   public MiddleClickFriend() {
      super(Categories.Misc, "middle-click-friend", "Adds or removes a player as a friend via middle click.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.message = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("message")).description("Sends a message to the player when you add them as a friend.")).defaultValue(false)).build());
   }

   @EventHandler
   private void onMouseButton(MouseButtonEvent event) {
      if (event.action == KeyAction.Press && event.button == 2 && this.mc.field_1755 == null && this.mc.field_1692 != null && this.mc.field_1692 instanceof class_1657) {
         if (!Friends.get().isFriend((class_1657)this.mc.field_1692)) {
            Friends.get().add(new Friend((class_1657)this.mc.field_1692));
            if ((Boolean)this.message.get()) {
               this.mc.field_1724.method_3142("/msg " + this.mc.field_1692.method_5820() + " Ya dobavil");
            }
         } else {
            Friends.get().remove(Friends.get().get((class_1657)this.mc.field_1692));
         }
      }

   }
}
