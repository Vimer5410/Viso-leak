package meteordevelopment.meteorclient.systems.modules.misc;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.orbit.EventHandler;

public class AutoClicker extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<AutoClicker.Mode> mode;
   private final Setting<AutoClicker.Button> button;
   private final Setting<Integer> delay;
   private int timer;

   public AutoClicker() {
      super(Categories.Player, "auto-clicker", "Automatically clicks.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).description("The method of clicking.")).defaultValue(AutoClicker.Mode.Press)).build());
      this.button = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("button")).description("Which button to press.")).defaultValue(AutoClicker.Button.Right)).build());
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("click-delay")).description("The amount of delay between clicks in ticks.")).defaultValue(2)).min(0).sliderMax(60).build());
   }

   public void onActivate() {
      this.timer = 0;
      this.mc.field_1690.field_1886.method_23481(false);
      this.mc.field_1690.field_1904.method_23481(false);
   }

   public void onDeactivate() {
      this.mc.field_1690.field_1886.method_23481(false);
      this.mc.field_1690.field_1904.method_23481(false);
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      switch((AutoClicker.Mode)this.mode.get()) {
      case Hold:
         switch((AutoClicker.Button)this.button.get()) {
         case Left:
            this.mc.field_1690.field_1886.method_23481(true);
            return;
         case Right:
            this.mc.field_1690.field_1904.method_23481(true);
            return;
         default:
            return;
         }
      case Press:
         ++this.timer;
         if ((Integer)this.delay.get() <= this.timer) {
            switch((AutoClicker.Button)this.button.get()) {
            case Left:
               Utils.leftClick();
               break;
            case Right:
               Utils.rightClick();
            }

            this.timer = 0;
         }
      }

   }

   public static enum Mode {
      Hold,
      Press;

      // $FF: synthetic method
      private static AutoClicker.Mode[] $values() {
         return new AutoClicker.Mode[]{Hold, Press};
      }
   }

   public static enum Button {
      Right,
      Left;

      // $FF: synthetic method
      private static AutoClicker.Button[] $values() {
         return new AutoClicker.Button[]{Right, Left};
      }
   }
}
