package meteordevelopment.meteorclient.systems.modules.misc;

import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.PlaySoundEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.SoundEventListSetting;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_3414;

public class SoundBlocker extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<List<class_3414>> sounds;

   public SoundBlocker() {
      super(Categories.Misc, "sound-blocker", "Cancels out selected sounds.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sounds = this.sgGeneral.add(((SoundEventListSetting.Builder)((SoundEventListSetting.Builder)(new SoundEventListSetting.Builder()).name("sounds")).description("Sounds to block.")).build());
   }

   @EventHandler
   private void onPlaySound(PlaySoundEvent event) {
      Iterator var2 = ((List)this.sounds.get()).iterator();

      while(var2.hasNext()) {
         class_3414 sound = (class_3414)var2.next();
         if (sound.method_14833().equals(event.sound.method_4775())) {
            event.cancel();
            break;
         }
      }

   }
}
