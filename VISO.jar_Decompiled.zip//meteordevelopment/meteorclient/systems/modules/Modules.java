package meteordevelopment.meteorclient.systems.modules;

import com.google.common.collect.Ordering;
import com.mojang.serialization.Lifecycle;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicReference;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.events.meteor.ActiveModulesChangedEvent;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.meteor.ModuleBindChangedEvent;
import meteordevelopment.meteorclient.events.meteor.MouseButtonEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.systems.modules.combat.AimAssist;
import meteordevelopment.meteorclient.systems.modules.combat.AnchorAura;
import meteordevelopment.meteorclient.systems.modules.combat.AntiAnvil;
import meteordevelopment.meteorclient.systems.modules.combat.AntiBed;
import meteordevelopment.meteorclient.systems.modules.combat.ArrowDodge;
import meteordevelopment.meteorclient.systems.modules.combat.AutoAnvil;
import meteordevelopment.meteorclient.systems.modules.combat.AutoArmor;
import meteordevelopment.meteorclient.systems.modules.combat.AutoCity;
import meteordevelopment.meteorclient.systems.modules.combat.AutoEXP;
import meteordevelopment.meteorclient.systems.modules.combat.AutoTotem;
import meteordevelopment.meteorclient.systems.modules.combat.AutoTrap;
import meteordevelopment.meteorclient.systems.modules.combat.AutoWeapon;
import meteordevelopment.meteorclient.systems.modules.combat.AutoWeb;
import meteordevelopment.meteorclient.systems.modules.combat.BedAura;
import meteordevelopment.meteorclient.systems.modules.combat.BowAimbot;
import meteordevelopment.meteorclient.systems.modules.combat.BowSpam;
import meteordevelopment.meteorclient.systems.modules.combat.Burrow;
import meteordevelopment.meteorclient.systems.modules.combat.Criticals;
import meteordevelopment.meteorclient.systems.modules.combat.CrystalAura;
import meteordevelopment.meteorclient.systems.modules.combat.Hitboxes;
import meteordevelopment.meteorclient.systems.modules.combat.HoleFiller;
import meteordevelopment.meteorclient.systems.modules.combat.KillAura;
import meteordevelopment.meteorclient.systems.modules.combat.Offhand;
import meteordevelopment.meteorclient.systems.modules.combat.Quiver;
import meteordevelopment.meteorclient.systems.modules.combat.SelfAnvil;
import meteordevelopment.meteorclient.systems.modules.combat.SelfTrap;
import meteordevelopment.meteorclient.systems.modules.combat.SelfWeb;
import meteordevelopment.meteorclient.systems.modules.combat.Surround;
import meteordevelopment.meteorclient.systems.modules.misc.Announcer;
import meteordevelopment.meteorclient.systems.modules.misc.AntiPacketKick;
import meteordevelopment.meteorclient.systems.modules.misc.AutoClicker;
import meteordevelopment.meteorclient.systems.modules.misc.AutoLog;
import meteordevelopment.meteorclient.systems.modules.misc.AutoReconnect;
import meteordevelopment.meteorclient.systems.modules.misc.AutoRespawn;
import meteordevelopment.meteorclient.systems.modules.misc.BetterChat;
import meteordevelopment.meteorclient.systems.modules.misc.BetterTab;
import meteordevelopment.meteorclient.systems.modules.misc.BookBot;
import meteordevelopment.meteorclient.systems.modules.misc.DiscordPresence;
import meteordevelopment.meteorclient.systems.modules.misc.InventoryTweaks;
import meteordevelopment.meteorclient.systems.modules.misc.MessageAura;
import meteordevelopment.meteorclient.systems.modules.misc.MiddleClickFriend;
import meteordevelopment.meteorclient.systems.modules.misc.NameProtect;
import meteordevelopment.meteorclient.systems.modules.misc.Notebot;
import meteordevelopment.meteorclient.systems.modules.misc.Notifier;
import meteordevelopment.meteorclient.systems.modules.misc.PacketCanceller;
import meteordevelopment.meteorclient.systems.modules.misc.SoundBlocker;
import meteordevelopment.meteorclient.systems.modules.misc.Spam;
import meteordevelopment.meteorclient.systems.modules.misc.VanillaSpoof;
import meteordevelopment.meteorclient.systems.modules.misc.swarm.Swarm;
import meteordevelopment.meteorclient.systems.modules.movement.AirJump;
import meteordevelopment.meteorclient.systems.modules.movement.Anchor;
import meteordevelopment.meteorclient.systems.modules.movement.AntiAFK;
import meteordevelopment.meteorclient.systems.modules.movement.AntiLevitation;
import meteordevelopment.meteorclient.systems.modules.movement.AntiVoid;
import meteordevelopment.meteorclient.systems.modules.movement.AutoJump;
import meteordevelopment.meteorclient.systems.modules.movement.AutoWalk;
import meteordevelopment.meteorclient.systems.modules.movement.Blink;
import meteordevelopment.meteorclient.systems.modules.movement.BoatFly;
import meteordevelopment.meteorclient.systems.modules.movement.ClickTP;
import meteordevelopment.meteorclient.systems.modules.movement.ElytraBoost;
import meteordevelopment.meteorclient.systems.modules.movement.EntityControl;
import meteordevelopment.meteorclient.systems.modules.movement.EntitySpeed;
import meteordevelopment.meteorclient.systems.modules.movement.FastClimb;
import meteordevelopment.meteorclient.systems.modules.movement.Flight;
import meteordevelopment.meteorclient.systems.modules.movement.GUIMove;
import meteordevelopment.meteorclient.systems.modules.movement.HighJump;
import meteordevelopment.meteorclient.systems.modules.movement.Jesus;
import meteordevelopment.meteorclient.systems.modules.movement.LongJump;
import meteordevelopment.meteorclient.systems.modules.movement.NoFall;
import meteordevelopment.meteorclient.systems.modules.movement.NoSlow;
import meteordevelopment.meteorclient.systems.modules.movement.Parkour;
import meteordevelopment.meteorclient.systems.modules.movement.ReverseStep;
import meteordevelopment.meteorclient.systems.modules.movement.SafeWalk;
import meteordevelopment.meteorclient.systems.modules.movement.Scaffold;
import meteordevelopment.meteorclient.systems.modules.movement.Slippy;
import meteordevelopment.meteorclient.systems.modules.movement.Sneak;
import meteordevelopment.meteorclient.systems.modules.movement.Spider;
import meteordevelopment.meteorclient.systems.modules.movement.Sprint;
import meteordevelopment.meteorclient.systems.modules.movement.Step;
import meteordevelopment.meteorclient.systems.modules.movement.TridentBoost;
import meteordevelopment.meteorclient.systems.modules.movement.Velocity;
import meteordevelopment.meteorclient.systems.modules.movement.elytrafly.ElytraFly;
import meteordevelopment.meteorclient.systems.modules.movement.speed.Speed;
import meteordevelopment.meteorclient.systems.modules.player.AntiHunger;
import meteordevelopment.meteorclient.systems.modules.player.AutoEat;
import meteordevelopment.meteorclient.systems.modules.player.AutoFish;
import meteordevelopment.meteorclient.systems.modules.player.AutoGap;
import meteordevelopment.meteorclient.systems.modules.player.AutoMend;
import meteordevelopment.meteorclient.systems.modules.player.AutoReplenish;
import meteordevelopment.meteorclient.systems.modules.player.AutoTool;
import meteordevelopment.meteorclient.systems.modules.player.ChestSwap;
import meteordevelopment.meteorclient.systems.modules.player.EXPThrower;
import meteordevelopment.meteorclient.systems.modules.player.FakePlayer;
import meteordevelopment.meteorclient.systems.modules.player.FastUse;
import meteordevelopment.meteorclient.systems.modules.player.GhostHand;
import meteordevelopment.meteorclient.systems.modules.player.InstaMine;
import meteordevelopment.meteorclient.systems.modules.player.LiquidInteract;
import meteordevelopment.meteorclient.systems.modules.player.MiddleClickExtra;
import meteordevelopment.meteorclient.systems.modules.player.NoBreakDelay;
import meteordevelopment.meteorclient.systems.modules.player.NoInteract;
import meteordevelopment.meteorclient.systems.modules.player.NoMiningTrace;
import meteordevelopment.meteorclient.systems.modules.player.NoRotate;
import meteordevelopment.meteorclient.systems.modules.player.OffhandCrash;
import meteordevelopment.meteorclient.systems.modules.player.PacketMine;
import meteordevelopment.meteorclient.systems.modules.player.Portals;
import meteordevelopment.meteorclient.systems.modules.player.PotionSaver;
import meteordevelopment.meteorclient.systems.modules.player.PotionSpoof;
import meteordevelopment.meteorclient.systems.modules.player.Reach;
import meteordevelopment.meteorclient.systems.modules.player.Rotation;
import meteordevelopment.meteorclient.systems.modules.player.SpeedMine;
import meteordevelopment.meteorclient.systems.modules.render.BetterTooltips;
import meteordevelopment.meteorclient.systems.modules.render.BlockSelection;
import meteordevelopment.meteorclient.systems.modules.render.Blur;
import meteordevelopment.meteorclient.systems.modules.render.BossStack;
import meteordevelopment.meteorclient.systems.modules.render.Breadcrumbs;
import meteordevelopment.meteorclient.systems.modules.render.BreakIndicators;
import meteordevelopment.meteorclient.systems.modules.render.CameraTweaks;
import meteordevelopment.meteorclient.systems.modules.render.Chams;
import meteordevelopment.meteorclient.systems.modules.render.CityESP;
import meteordevelopment.meteorclient.systems.modules.render.ESP;
import meteordevelopment.meteorclient.systems.modules.render.EntityOwner;
import meteordevelopment.meteorclient.systems.modules.render.FreeLook;
import meteordevelopment.meteorclient.systems.modules.render.Freecam;
import meteordevelopment.meteorclient.systems.modules.render.Fullbright;
import meteordevelopment.meteorclient.systems.modules.render.HandView;
import meteordevelopment.meteorclient.systems.modules.render.HoleESP;
import meteordevelopment.meteorclient.systems.modules.render.ItemHighlight;
import meteordevelopment.meteorclient.systems.modules.render.ItemPhysics;
import meteordevelopment.meteorclient.systems.modules.render.LightOverlay;
import meteordevelopment.meteorclient.systems.modules.render.LogoutSpots;
import meteordevelopment.meteorclient.systems.modules.render.Nametags;
import meteordevelopment.meteorclient.systems.modules.render.NoRender;
import meteordevelopment.meteorclient.systems.modules.render.PopChams;
import meteordevelopment.meteorclient.systems.modules.render.StorageESP;
import meteordevelopment.meteorclient.systems.modules.render.TimeChanger;
import meteordevelopment.meteorclient.systems.modules.render.Tracers;
import meteordevelopment.meteorclient.systems.modules.render.Trail;
import meteordevelopment.meteorclient.systems.modules.render.Trajectories;
import meteordevelopment.meteorclient.systems.modules.render.UnfocusedCPU;
import meteordevelopment.meteorclient.systems.modules.render.VoidESP;
import meteordevelopment.meteorclient.systems.modules.render.WallHack;
import meteordevelopment.meteorclient.systems.modules.render.WaypointsModule;
import meteordevelopment.meteorclient.systems.modules.render.Xray;
import meteordevelopment.meteorclient.systems.modules.render.Zoom;
import meteordevelopment.meteorclient.systems.modules.render.marker.Marker;
import meteordevelopment.meteorclient.systems.modules.render.search.Search;
import meteordevelopment.meteorclient.systems.modules.viso.AnchorPlus;
import meteordevelopment.meteorclient.systems.modules.viso.AntiBedPLUSPLUS;
import meteordevelopment.meteorclient.systems.modules.viso.AutoCityPlus;
import meteordevelopment.meteorclient.systems.modules.viso.AutoCraft;
import meteordevelopment.meteorclient.systems.modules.viso.BurrowESP;
import meteordevelopment.meteorclient.systems.modules.viso.BurrowMiner;
import meteordevelopment.meteorclient.systems.modules.viso.CevBreakerTest;
import meteordevelopment.meteorclient.systems.modules.viso.CityESPPlus;
import meteordevelopment.meteorclient.systems.modules.viso.Criticalsplus;
import meteordevelopment.meteorclient.systems.modules.viso.ExtraNuker;
import meteordevelopment.meteorclient.systems.modules.viso.FastUsePlus;
import meteordevelopment.meteorclient.systems.modules.viso.HoleESPPlus;
import meteordevelopment.meteorclient.systems.modules.viso.ModeAnvil;
import meteordevelopment.meteorclient.systems.modules.viso.ModeBed;
import meteordevelopment.meteorclient.systems.modules.viso.ModeCrystalV2;
import meteordevelopment.meteorclient.systems.modules.viso.ModeFier;
import meteordevelopment.meteorclient.systems.modules.viso.ModeKill;
import meteordevelopment.meteorclient.systems.modules.viso.ModeLever;
import meteordevelopment.meteorclient.systems.modules.viso.ModeTNT;
import meteordevelopment.meteorclient.systems.modules.viso.Modeimpapovskii;
import meteordevelopment.meteorclient.systems.modules.viso.Msponge;
import meteordevelopment.meteorclient.systems.modules.viso.NewAutoEz;
import meteordevelopment.meteorclient.systems.modules.viso.PearlPredict;
import meteordevelopment.meteorclient.systems.modules.viso.PredictChorus;
import meteordevelopment.meteorclient.systems.modules.viso.SPuzzleSurround;
import meteordevelopment.meteorclient.systems.modules.viso.ScaffoldPlus;
import meteordevelopment.meteorclient.systems.modules.viso.SelfProrect;
import meteordevelopment.meteorclient.systems.modules.viso.SelfTrapPlus;
import meteordevelopment.meteorclient.systems.modules.viso.SmartHoleFiller;
import meteordevelopment.meteorclient.systems.modules.viso.StrafePlus;
import meteordevelopment.meteorclient.systems.modules.viso.SurroundPlus;
import meteordevelopment.meteorclient.systems.modules.viso.TunnelESP;
import meteordevelopment.meteorclient.systems.modules.viso.blockrenderer;
import meteordevelopment.meteorclient.systems.modules.world.AirPlace;
import meteordevelopment.meteorclient.systems.modules.world.Ambience;
import meteordevelopment.meteorclient.systems.modules.world.AntiCactus;
import meteordevelopment.meteorclient.systems.modules.world.AutoBreed;
import meteordevelopment.meteorclient.systems.modules.world.AutoBrewer;
import meteordevelopment.meteorclient.systems.modules.world.AutoMount;
import meteordevelopment.meteorclient.systems.modules.world.AutoNametag;
import meteordevelopment.meteorclient.systems.modules.world.AutoShearer;
import meteordevelopment.meteorclient.systems.modules.world.AutoSign;
import meteordevelopment.meteorclient.systems.modules.world.AutoSmelter;
import meteordevelopment.meteorclient.systems.modules.world.BuildHeight;
import meteordevelopment.meteorclient.systems.modules.world.EChestFarmer;
import meteordevelopment.meteorclient.systems.modules.world.EndermanLook;
import meteordevelopment.meteorclient.systems.modules.world.Flamethrower;
import meteordevelopment.meteorclient.systems.modules.world.HighwayBuilder;
import meteordevelopment.meteorclient.systems.modules.world.InfinityMiner;
import meteordevelopment.meteorclient.systems.modules.world.LiquidFiller;
import meteordevelopment.meteorclient.systems.modules.world.MountBypass;
import meteordevelopment.meteorclient.systems.modules.world.Nuker;
import meteordevelopment.meteorclient.systems.modules.world.SpawnProofer;
import meteordevelopment.meteorclient.systems.modules.world.StashFinder;
import meteordevelopment.meteorclient.systems.modules.world.Timer;
import meteordevelopment.meteorclient.systems.modules.world.VeinMiner;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.ValueComparableMap;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import org.jetbrains.annotations.Nullable;

public class Modules extends System<Modules> {
   public static final Modules.ModuleRegistry REGISTRY = new Modules.ModuleRegistry();
   private static final List<Category> CATEGORIES = new ArrayList();
   private final List<Module> modules = new ArrayList();
   private final Map<Class<? extends Module>, Module> moduleInstances = new HashMap();
   private final Map<Category, List<Module>> groups = new HashMap();
   private final List<Module> active = new ArrayList();
   private Module moduleToBind;

   public Modules() {
      super("modules");
   }

   public static Modules get() {
      return (Modules)Systems.get(Modules.class);
   }

   public void init() {
      this.initCombat();
      this.initPlayer();
      this.initMovement();
      this.initRender();
      this.initWorld();
      this.initMisc();
      this.initNewCombat();
   }

   public void load(File folder) {
      Iterator var2 = this.modules.iterator();

      while(var2.hasNext()) {
         Module module = (Module)var2.next();
         Iterator var4 = module.settings.iterator();

         while(var4.hasNext()) {
            SettingGroup group = (SettingGroup)var4.next();
            Iterator var6 = group.iterator();

            while(var6.hasNext()) {
               Setting<?> setting = (Setting)var6.next();
               setting.reset();
            }
         }
      }

      super.load(folder);
   }

   public void sortModules() {
      Iterator var1 = this.groups.values().iterator();

      while(var1.hasNext()) {
         List<Module> modules = (List)var1.next();
         modules.sort(Comparator.comparing((o) -> {
            return o.title;
         }));
      }

      this.modules.sort(Comparator.comparing((o) -> {
         return o.title;
      }));
   }

   public static void registerCategory(Category category) {
      if (!Categories.REGISTERING) {
         throw new RuntimeException("Modules.registerCategory - Cannot register category outside of onRegisterCategories callback.");
      } else {
         CATEGORIES.add(category);
      }
   }

   public static Iterable<Category> loopCategories() {
      return CATEGORIES;
   }

   public static Category getCategoryByHash(int hash) {
      Iterator var1 = CATEGORIES.iterator();

      Category category;
      do {
         if (!var1.hasNext()) {
            return null;
         }

         category = (Category)var1.next();
      } while(category.hashCode() != hash);

      return category;
   }

   public <T extends Module> T get(Class<T> klass) {
      return (Module)this.moduleInstances.get(klass);
   }

   public Module get(String name) {
      Iterator var2 = this.moduleInstances.values().iterator();

      Module module;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         module = (Module)var2.next();
      } while(!module.name.equalsIgnoreCase(name));

      return module;
   }

   public boolean isActive(Class<? extends Module> klass) {
      Module module = this.get(klass);
      return module != null && module.isActive();
   }

   public List<Module> getGroup(Category category) {
      return (List)this.groups.computeIfAbsent(category, (category1) -> {
         return new ArrayList();
      });
   }

   public Collection<Module> getAll() {
      return this.moduleInstances.values();
   }

   public List<Module> getList() {
      return this.modules;
   }

   public int getCount() {
      return this.moduleInstances.values().size();
   }

   public List<Module> getActive() {
      synchronized(this.active) {
         return this.active;
      }
   }

   public Set<Module> searchTitles(String text) {
      Map<Module, Integer> modules = new ValueComparableMap(Ordering.natural().reverse());
      Iterator var3 = this.moduleInstances.values().iterator();

      while(var3.hasNext()) {
         Module module = (Module)var3.next();
         int words = Utils.search(module.title, text);
         if (words > 0) {
            modules.put(module, (Integer)modules.getOrDefault(module, 0) + words);
         }
      }

      return modules.keySet();
   }

   public Set<Module> searchSettingTitles(String text) {
      Map<Module, Integer> modules = new ValueComparableMap(Ordering.natural().reverse());
      Iterator var3 = this.moduleInstances.values().iterator();

      while(var3.hasNext()) {
         Module module = (Module)var3.next();
         Iterator var5 = module.settings.iterator();

         while(var5.hasNext()) {
            SettingGroup sg = (SettingGroup)var5.next();
            Iterator var7 = sg.iterator();

            while(var7.hasNext()) {
               Setting<?> setting = (Setting)var7.next();
               int words = Utils.search(setting.title, text);
               if (words > 0) {
                  modules.put(module, (Integer)modules.getOrDefault(module, 0) + words);
               }
            }
         }
      }

      return modules.keySet();
   }

   void addActive(Module module) {
      synchronized(this.active) {
         if (!this.active.contains(module)) {
            this.active.add(module);
            MeteorClient.EVENT_BUS.post((Object)ActiveModulesChangedEvent.get());
         }

      }
   }

   void removeActive(Module module) {
      synchronized(this.active) {
         if (this.active.remove(module)) {
            MeteorClient.EVENT_BUS.post((Object)ActiveModulesChangedEvent.get());
         }

      }
   }

   public void setModuleToBind(Module moduleToBind) {
      this.moduleToBind = moduleToBind;
   }

   @EventHandler(
      priority = 200
   )
   private void onKeyBinding(KeyEvent event) {
      if (event.action == KeyAction.Press && this.onBinding(true, event.key)) {
         event.cancel();
      }

   }

   @EventHandler(
      priority = 200
   )
   private void onButtonBinding(MouseButtonEvent event) {
      if (event.action == KeyAction.Press && this.onBinding(false, event.button)) {
         event.cancel();
      }

   }

   private boolean onBinding(boolean isKey, int value) {
      if (this.moduleToBind != null && this.moduleToBind.keybind.canBindTo(isKey, value)) {
         this.moduleToBind.keybind.set(isKey, value);
         this.moduleToBind.info("Bound to (highlight)%s(default).", this.moduleToBind.keybind);
         MeteorClient.EVENT_BUS.post((Object)ModuleBindChangedEvent.get(this.moduleToBind));
         this.moduleToBind = null;
         return true;
      } else {
         return false;
      }
   }

   @EventHandler(
      priority = 100
   )
   private void onKey(KeyEvent event) {
      if (event.action != KeyAction.Repeat) {
         this.onAction(true, event.key, event.action == KeyAction.Press);
      }
   }

   @EventHandler(
      priority = 100
   )
   private void onMouseButton(MouseButtonEvent event) {
      if (event.action != KeyAction.Repeat) {
         this.onAction(false, event.button, event.action == KeyAction.Press);
      }
   }

   private void onAction(boolean isKey, int value, boolean isPress) {
      if (MeteorClient.mc.field_1755 == null && !Input.isKeyPressed(292)) {
         Iterator var4 = this.moduleInstances.values().iterator();

         while(true) {
            Module module;
            do {
               do {
                  if (!var4.hasNext()) {
                     return;
                  }

                  module = (Module)var4.next();
               } while(!module.keybind.matches(isKey, value));
            } while(!isPress && !module.toggleOnBindRelease);

            module.toggle();
            module.sendToggledMsg();
         }
      }
   }

   @EventHandler(
      priority = 201
   )
   private void onOpenScreen(OpenScreenEvent event) {
      if (Utils.canUpdate()) {
         Iterator var2 = this.moduleInstances.values().iterator();

         while(var2.hasNext()) {
            Module module = (Module)var2.next();
            if (module.toggleOnBindRelease && module.isActive()) {
               module.toggle();
               module.sendToggledMsg();
            }
         }

      }
   }

   @EventHandler
   private void onGameJoined(GameJoinedEvent event) {
      synchronized(this.active) {
         Iterator var3 = this.modules.iterator();

         while(var3.hasNext()) {
            Module module = (Module)var3.next();
            if (module.isActive() && !module.runInMainMenu) {
               MeteorClient.EVENT_BUS.subscribe((Object)module);
               module.onActivate();
            }
         }

      }
   }

   @EventHandler
   private void onGameLeft(GameLeftEvent event) {
      synchronized(this.active) {
         Iterator var3 = this.modules.iterator();

         while(var3.hasNext()) {
            Module module = (Module)var3.next();
            if (module.isActive() && !module.runInMainMenu) {
               MeteorClient.EVENT_BUS.unsubscribe((Object)module);
               module.onDeactivate();
            }
         }

      }
   }

   public void disableAll() {
      synchronized(this.active) {
         Iterator var2 = this.modules.iterator();

         while(var2.hasNext()) {
            Module module = (Module)var2.next();
            if (module.isActive()) {
               module.toggle();
            }
         }

      }
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      class_2499 modulesTag = new class_2499();
      Iterator var3 = this.getAll().iterator();

      while(var3.hasNext()) {
         Module module = (Module)var3.next();
         class_2487 moduleTag = module.toTag();
         if (moduleTag != null) {
            modulesTag.add(moduleTag);
         }
      }

      tag.method_10566("modules", modulesTag);
      return tag;
   }

   public Modules fromTag(class_2487 tag) {
      this.disableAll();
      class_2499 modulesTag = tag.method_10554("modules", 10);
      Iterator var3 = modulesTag.iterator();

      while(var3.hasNext()) {
         class_2520 moduleTagI = (class_2520)var3.next();
         class_2487 moduleTag = (class_2487)moduleTagI;
         Module module = this.get(moduleTag.method_10558("name"));
         if (module != null) {
            module.fromTag(moduleTag);
         }
      }

      return this;
   }

   public void add(Module module) {
      if (!CATEGORIES.contains(module.category)) {
         throw new RuntimeException("Modules.addModule - Module's category was not registered.");
      } else {
         AtomicReference<Module> removedModule = new AtomicReference();
         if (this.moduleInstances.values().removeIf((module1) -> {
            if (module1.name.equals(module.name)) {
               removedModule.set(module1);
               module1.settings.unregisterColorSettings();
               return true;
            } else {
               return false;
            }
         })) {
            this.getGroup(((Module)removedModule.get()).category).remove(removedModule.get());
         }

         this.moduleInstances.put(module.getClass(), module);
         this.modules.add(module);
         this.getGroup(module.category).add(module);
         module.settings.registerColorSettings(module);
      }
   }

   private void initCombat() {
      this.add(new AimAssist());
      this.add(new AnchorAura());
      this.add(new AntiAnvil());
      this.add(new AntiBed());
      this.add(new ArrowDodge());
      this.add(new AutoAnvil());
      this.add(new AutoArmor());
      this.add(new AutoCity());
      this.add(new AutoEXP());
      this.add(new AutoTotem());
      this.add(new AutoTrap());
      this.add(new AutoWeapon());
      this.add(new AutoWeb());
      this.add(new BedAura());
      this.add(new BowAimbot());
      this.add(new BowSpam());
      this.add(new Burrow());
      this.add(new Criticals());
      this.add(new CrystalAura());
      this.add(new Hitboxes());
      this.add(new HoleFiller());
      this.add(new KillAura());
      this.add(new Offhand());
      this.add(new Quiver());
      this.add(new SelfAnvil());
      this.add(new SelfTrap());
      this.add(new SelfWeb());
      this.add(new Surround());
   }

   private void initPlayer() {
      this.add(new AntiHunger());
      this.add(new AutoEat());
      this.add(new AutoFish());
      this.add(new AutoGap());
      this.add(new AutoMend());
      this.add(new AutoReplenish());
      this.add(new AutoTool());
      this.add(new ChestSwap());
      this.add(new EXPThrower());
      this.add(new FakePlayer());
      this.add(new FastUse());
      this.add(new GhostHand());
      this.add(new InstaMine());
      this.add(new LiquidInteract());
      this.add(new MiddleClickExtra());
      this.add(new NoBreakDelay());
      this.add(new NoInteract());
      this.add(new NoMiningTrace());
      this.add(new NoRotate());
      this.add(new OffhandCrash());
      this.add(new PacketMine());
      this.add(new Portals());
      this.add(new PotionSaver());
      this.add(new PotionSpoof());
      this.add(new Reach());
      this.add(new Rotation());
      this.add(new SpeedMine());
   }

   private void initMovement() {
      this.add(new AirJump());
      this.add(new Anchor());
      this.add(new AntiAFK());
      this.add(new AntiLevitation());
      this.add(new AntiVoid());
      this.add(new AutoJump());
      this.add(new AutoWalk());
      this.add(new Blink());
      this.add(new BoatFly());
      this.add(new ClickTP());
      this.add(new ElytraBoost());
      this.add(new ElytraFly());
      this.add(new EntityControl());
      this.add(new EntitySpeed());
      this.add(new FastClimb());
      this.add(new Flight());
      this.add(new GUIMove());
      this.add(new HighJump());
      this.add(new Jesus());
      this.add(new LongJump());
      this.add(new NoFall());
      this.add(new NoSlow());
      this.add(new Parkour());
      this.add(new ReverseStep());
      this.add(new SafeWalk());
      this.add(new Scaffold());
      this.add(new Slippy());
      this.add(new Sneak());
      this.add(new Speed());
      this.add(new Spider());
      this.add(new Sprint());
      this.add(new Step());
      this.add(new TridentBoost());
      this.add(new Velocity());
   }

   private void initRender() {
      this.add(new BetterTooltips());
      this.add(new BlockSelection());
      this.add(new BossStack());
      this.add(new Breadcrumbs());
      this.add(new BreakIndicators());
      this.add(new CameraTweaks());
      this.add(new Chams());
      this.add(new CityESP());
      this.add(new EntityOwner());
      this.add(new ESP());
      this.add(new Freecam());
      this.add(new FreeLook());
      this.add(new Fullbright());
      this.add(new HandView());
      this.add(new HoleESP());
      this.add(new ItemPhysics());
      this.add(new ItemHighlight());
      this.add(new LightOverlay());
      this.add(new LogoutSpots());
      this.add(new Marker());
      this.add(new Nametags());
      this.add(new NoRender());
      this.add(new Search());
      this.add(new StorageESP());
      this.add(new TimeChanger());
      this.add(new Tracers());
      this.add(new Trail());
      this.add(new Trajectories());
      this.add(new UnfocusedCPU());
      this.add(new VoidESP());
      this.add(new WallHack());
      this.add(new WaypointsModule());
      this.add(new Xray());
      this.add(new Zoom());
      this.add(new Blur());
      this.add(new PopChams());
   }

   private void initWorld() {
      this.add(new AirPlace());
      this.add(new Ambience());
      this.add(new AntiCactus());
      this.add(new AutoBreed());
      this.add(new AutoBrewer());
      this.add(new AutoMount());
      this.add(new AutoNametag());
      this.add(new AutoShearer());
      this.add(new AutoSign());
      this.add(new AutoSmelter());
      this.add(new BuildHeight());
      this.add(new EChestFarmer());
      this.add(new EndermanLook());
      this.add(new Flamethrower());
      this.add(new InfinityMiner());
      this.add(new LiquidFiller());
      this.add(new MountBypass());
      this.add(new Nuker());
      this.add(new StashFinder());
      this.add(new SpawnProofer());
      this.add(new Timer());
      this.add(new VeinMiner());
      this.add(new HighwayBuilder());
   }

   private void initMisc() {
      this.add(new Swarm());
      this.add(new Announcer());
      this.add(new AntiPacketKick());
      this.add(new AutoClicker());
      this.add(new AutoLog());
      this.add(new AutoReconnect());
      this.add(new AutoRespawn());
      this.add(new BetterChat());
      this.add(new BetterTab());
      this.add(new BookBot());
      this.add(new DiscordPresence());
      this.add(new MessageAura());
      this.add(new MiddleClickFriend());
      this.add(new NameProtect());
      this.add(new Notebot());
      this.add(new Notifier());
      this.add(new PacketCanceller());
      this.add(new SoundBlocker());
      this.add(new Spam());
      this.add(new VanillaSpoof());
      this.add(new InventoryTweaks());
   }

   private void initNewCombat() {
      this.add(new NewAutoEz());
      this.add(new AnchorPlus());
      this.add(new AntiBedPLUSPLUS());
      this.add(new BurrowESP());
      this.add(new CityESPPlus());
      this.add(new HoleESPPlus());
      this.add(new FastUsePlus());
      this.add(new AutoCraft());
      this.add(new AutoCityPlus());
      this.add(new Criticalsplus());
      this.add(new SelfProrect());
      this.add(new SelfTrapPlus());
      this.add(new SmartHoleFiller());
      this.add(new ExtraNuker());
      this.add(new ScaffoldPlus());
      this.add(new SPuzzleSurround());
      this.add(new CevBreakerTest());
      this.add(new ModeTNT());
      this.add(new SurroundPlus());
      this.add(new ModeKill());
      this.add(new ModeBed());
      this.add(new PredictChorus());
      this.add(new PearlPredict());
      this.add(new Msponge());
      this.add(new ModeLever());
      this.add(new Modeimpapovskii());
      this.add(new ModeAnvil());
      this.add(new blockrenderer());
      this.add(new ModeFier());
      this.add(new StrafePlus());
      this.add(new TunnelESP());
      this.add(new BurrowMiner());
      this.add(new ModeCrystalV2());
   }

   public static class ModuleRegistry extends class_2378<Module> {
      public ModuleRegistry() {
         super(class_5321.method_29180(new class_2960("meteor-client", "modules")), Lifecycle.stable());
      }

      public int method_10204() {
         return Modules.get().getAll().size();
      }

      public class_2960 getId(Module entry) {
         return null;
      }

      public Optional<class_5321<Module>> getKey(Module entry) {
         return Optional.empty();
      }

      public int getRawId(Module entry) {
         return 0;
      }

      public Module get(class_5321<Module> key) {
         return null;
      }

      public Module get(class_2960 id) {
         return null;
      }

      public Lifecycle getEntryLifecycle(Module object) {
         return null;
      }

      public Lifecycle method_31138() {
         return null;
      }

      public Set<class_2960> method_10235() {
         return null;
      }

      public Set<Entry<class_5321<Module>, Module>> method_29722() {
         return null;
      }

      public boolean method_10250(class_2960 id) {
         return false;
      }

      @Nullable
      public Module get(int index) {
         return null;
      }

      public Iterator<Module> iterator() {
         return new Modules.ModuleRegistry.ModuleIterator();
      }

      @Nullable
      public Module getRandom(Random random) {
         return null;
      }

      public boolean method_35842(class_5321<Module> key) {
         return false;
      }

      private static class ModuleIterator implements Iterator<Module> {
         private final Iterator<Module> iterator = Modules.get().getAll().iterator();

         public boolean hasNext() {
            return this.iterator.hasNext();
         }

         public Module next() {
            return (Module)this.iterator.next();
         }
      }
   }
}
