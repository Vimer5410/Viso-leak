package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;

public class Portals extends Module {
   public Portals() {
      super(Categories.Player, "portals", "Allows you to use GUIs normally while in a Nether Portal.");
   }
}
