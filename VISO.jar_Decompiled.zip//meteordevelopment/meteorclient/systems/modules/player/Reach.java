package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;

public class Reach extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Double> reach;

   public Reach() {
      super(Categories.Player, "reach", "Gives you super long arms.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.reach = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("reach")).description("Your reach modifier.")).defaultValue(5.0D).min(0.0D).sliderMax(6.0D).build());
   }

   public float getReach() {
      if (!this.isActive()) {
         return this.mc.field_1761.method_2920().method_8386() ? 5.0F : 4.5F;
      } else {
         return ((Double)this.reach.get()).floatValue();
      }
   }
}
