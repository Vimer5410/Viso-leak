package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.class_1304;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class ChestSwap extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<ChestSwap.Chestplate> chestplate;
   private final Setting<Boolean> stayOn;

   public ChestSwap() {
      super(Categories.Player, "chest-swap", "Automatically swaps between a chestplate and an elytra.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.chestplate = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("chestplate")).description("Which type of chestplate to swap to.")).defaultValue(ChestSwap.Chestplate.PreferNetherite)).build());
      this.stayOn = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("stay-on")).description("Stays on and activates when you turn it off.")).defaultValue(false)).build());
   }

   public void onActivate() {
      this.swap();
      if (!(Boolean)this.stayOn.get()) {
         this.toggle();
      }

   }

   public void onDeactivate() {
      if ((Boolean)this.stayOn.get()) {
         this.swap();
      }

   }

   public void swap() {
      class_1792 currentItem = this.mc.field_1724.method_6118(class_1304.field_6174).method_7909();
      if (currentItem == class_1802.field_8833) {
         this.equipChestplate();
      } else if (currentItem instanceof class_1738 && ((class_1738)currentItem).method_7685() == class_1304.field_6174) {
         this.equipElytra();
      } else if (!this.equipChestplate()) {
         this.equipElytra();
      }

   }

   private boolean equipChestplate() {
      int bestSlot = -1;
      boolean breakLoop = false;

      for(int i = 0; i < this.mc.field_1724.method_31548().field_7547.size(); ++i) {
         class_1792 item = ((class_1799)this.mc.field_1724.method_31548().field_7547.get(i)).method_7909();
         switch((ChestSwap.Chestplate)this.chestplate.get()) {
         case Diamond:
            if (item == class_1802.field_8058) {
               bestSlot = i;
               breakLoop = true;
            }
            break;
         case Netherite:
            if (item == class_1802.field_22028) {
               bestSlot = i;
               breakLoop = true;
            }
            break;
         case PreferDiamond:
            if (item == class_1802.field_8058) {
               bestSlot = i;
               breakLoop = true;
            } else if (item == class_1802.field_22028) {
               bestSlot = i;
            }
            break;
         case PreferNetherite:
            if (item == class_1802.field_8058) {
               bestSlot = i;
            } else if (item == class_1802.field_22028) {
               bestSlot = i;
               breakLoop = true;
            }
         }

         if (breakLoop) {
            break;
         }
      }

      if (bestSlot != -1) {
         this.equip(bestSlot);
      }

      return bestSlot != -1;
   }

   private void equipElytra() {
      for(int i = 0; i < this.mc.field_1724.method_31548().field_7547.size(); ++i) {
         class_1792 item = ((class_1799)this.mc.field_1724.method_31548().field_7547.get(i)).method_7909();
         if (item == class_1802.field_8833) {
            this.equip(i);
            break;
         }
      }

   }

   private void equip(int slot) {
      InvUtils.move().from(slot).toArmor(2);
   }

   public void sendToggledMsg() {
      if ((Boolean)this.stayOn.get()) {
         super.sendToggledMsg();
      } else if ((Boolean)Config.get().chatFeedback.get()) {
         this.info("Triggered (highlight)%s(default).", new Object[]{this.title});
      }

   }

   public static enum Chestplate {
      Diamond,
      Netherite,
      PreferDiamond,
      PreferNetherite;

      // $FF: synthetic method
      private static ChestSwap.Chestplate[] $values() {
         return new ChestSwap.Chestplate[]{Diamond, Netherite, PreferDiamond, PreferNetherite};
      }
   }
}
