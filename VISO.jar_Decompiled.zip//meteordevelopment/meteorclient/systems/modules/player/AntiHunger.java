package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.PlayerMoveC2SPacketAccessor;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2828.class_5911;
import net.minecraft.class_2848.class_2849;

public class AntiHunger extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> sprint;
   private final Setting<Boolean> onGround;
   private final Setting<Boolean> waterCheck;
   private boolean lastOnGround;
   private boolean sendOnGroundTruePacket;
   private boolean ignorePacket;

   public AntiHunger() {
      super(Categories.Player, "anti-hunger", "Reduces (does NOT remove) hunger consumption.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sprint = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("sprint")).description("Spoofs sprinting packets.")).defaultValue(true)).build());
      this.onGround = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("on-ground")).description("Spoofs the onGround flag.")).defaultValue(true)).build());
      this.waterCheck = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("water-check")).description("Pauses the module if you are in water")).defaultValue(true)).build());
   }

   public void onActivate() {
      this.lastOnGround = this.mc.field_1724.method_24828();
      this.sendOnGroundTruePacket = true;
   }

   @EventHandler
   private void onSendPacket(PacketEvent.Send event) {
      if (!this.ignorePacket) {
         if (event.packet instanceof class_2848 && (Boolean)this.sprint.get()) {
            class_2849 mode = ((class_2848)event.packet).method_12365();
            if (mode == class_2849.field_12981 || mode == class_2849.field_12985) {
               event.cancel();
            }
         }

         if (event.packet instanceof class_2828 && (Boolean)this.onGround.get() && this.mc.field_1724.method_24828() && (double)this.mc.field_1724.field_6017 <= 0.0D && !this.mc.field_1761.method_2923()) {
            ((PlayerMoveC2SPacketAccessor)event.packet).setOnGround(false);
         }

      }
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if ((Boolean)this.waterCheck.get() && this.mc.field_1724.method_5799()) {
         this.ignorePacket = true;
      } else {
         if (this.mc.field_1724.method_24828() && !this.lastOnGround && !this.sendOnGroundTruePacket) {
            this.sendOnGroundTruePacket = true;
         }

         if (this.mc.field_1724.method_24828() && this.sendOnGroundTruePacket && (Boolean)this.onGround.get()) {
            this.ignorePacket = true;
            this.mc.method_1562().method_2883(new class_5911(true));
            this.ignorePacket = false;
            this.sendOnGroundTruePacket = false;
         }

         this.lastOnGround = this.mc.field_1724.method_24828();
      }
   }
}
