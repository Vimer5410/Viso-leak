package meteordevelopment.meteorclient.systems.modules.player;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.StatusEffectInstanceAccessor;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StatusEffectAmplifierMapSetting;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1291;
import net.minecraft.class_1293;

public class PotionSpoof extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Object2IntMap<class_1291>> potions;

   public PotionSpoof() {
      super(Categories.Player, "potion-spoof", "Spoofs specified potion effects for you. SOME effects DO NOT work.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.potions = this.sgGeneral.add(((StatusEffectAmplifierMapSetting.Builder)((StatusEffectAmplifierMapSetting.Builder)((StatusEffectAmplifierMapSetting.Builder)(new StatusEffectAmplifierMapSetting.Builder()).name("potions")).description("Potions to add.")).defaultValue(Utils.createStatusEffectMap())).build());
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      ObjectIterator var2 = ((Object2IntMap)this.potions.get()).keySet().iterator();

      while(var2.hasNext()) {
         class_1291 statusEffect = (class_1291)var2.next();
         int level = ((Object2IntMap)this.potions.get()).getInt(statusEffect);
         if (level > 0) {
            if (this.mc.field_1724.method_6059(statusEffect)) {
               class_1293 instance = this.mc.field_1724.method_6112(statusEffect);
               ((StatusEffectInstanceAccessor)instance).setAmplifier(level - 1);
               if (instance.method_5584() < 20) {
                  ((StatusEffectInstanceAccessor)instance).setDuration(20);
               }
            } else {
               this.mc.field_1724.method_6092(new class_1293(statusEffect, 20, level - 1));
            }
         }
      }

   }
}
