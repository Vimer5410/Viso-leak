package meteordevelopment.meteorclient.systems.modules.player;

import java.util.Objects;
import java.util.function.Predicate;
import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.world.InfinityMiner;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1799;
import net.minecraft.class_1820;
import net.minecraft.class_1831;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2680;

public class AutoTool extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<AutoTool.EnchantPreference> prefer;
   private final Setting<Boolean> silkTouchForEnderChest;
   private final Setting<Boolean> antiBreak;
   private final Setting<Integer> breakDurability;
   private final Setting<Boolean> switchBack;
   private final Setting<Integer> switchDelay;
   private boolean wasPressed;
   private boolean shouldSwitch;
   private int ticks;
   private int bestSlot;

   public AutoTool() {
      super(Categories.Player, "auto-tool", "Automatically switches to the most effective tool when performing an action.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.prefer = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("prefer")).description("Either to prefer Silk Touch, Fortune, or none.")).defaultValue(AutoTool.EnchantPreference.Fortune)).build());
      this.silkTouchForEnderChest = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("silk-touch-for-ender-chest")).description("Mines Ender Chests only with the Silk Touch enchantment.")).defaultValue(true)).build());
      this.antiBreak = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("anti-break")).description("Stops you from breaking your tool.")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      IntSetting.Builder var10002 = ((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("anti-break-percentage")).description("The durability percentage to stop using a tool.")).defaultValue(10)).range(1, 100).sliderRange(1, 100);
      Setting var10003 = this.antiBreak;
      Objects.requireNonNull(var10003);
      this.breakDurability = var10001.add(((IntSetting.Builder)var10002.visible(var10003::get)).build());
      this.switchBack = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("switch-back")).description("Switches your hand to whatever was selected when releasing your attack key.")).defaultValue(false)).build());
      this.switchDelay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("switch-delay")).description("Delay in ticks before switching tools.")).defaultValue(0)).build());
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (!Modules.get().isActive(InfinityMiner.class)) {
         if ((Boolean)this.switchBack.get() && !this.mc.field_1690.field_1886.method_1434() && this.wasPressed && InvUtils.previousSlot != -1) {
            InvUtils.swapBack();
            this.wasPressed = false;
         } else {
            if (this.ticks <= 0 && this.shouldSwitch && this.bestSlot != -1) {
               InvUtils.swap(this.bestSlot, (Boolean)this.switchBack.get());
               this.shouldSwitch = false;
            } else {
               --this.ticks;
            }

            this.wasPressed = this.mc.field_1690.field_1886.method_1434();
         }
      }
   }

   @EventHandler(
      priority = 100
   )
   private void onStartBreakingBlock(StartBreakingBlockEvent event) {
      if (!Modules.get().isActive(InfinityMiner.class)) {
         class_2680 blockState = this.mc.field_1687.method_8320(event.blockPos);
         if (BlockUtils.canBreak(event.blockPos, blockState)) {
            class_1799 currentStack = this.mc.field_1724.method_6047();
            double bestScore = -1.0D;
            this.bestSlot = -1;

            for(int i = 0; i < 9; ++i) {
               double score = getScore(this.mc.field_1724.method_31548().method_5438(i), blockState, (Boolean)this.silkTouchForEnderChest.get(), (AutoTool.EnchantPreference)this.prefer.get(), (itemStack) -> {
                  return !this.shouldStopUsing(itemStack);
               });
               if (!(score < 0.0D) && score > bestScore) {
                  bestScore = score;
                  this.bestSlot = i;
               }
            }

            if (this.bestSlot != -1 && bestScore > getScore(currentStack, blockState, (Boolean)this.silkTouchForEnderChest.get(), (AutoTool.EnchantPreference)this.prefer.get(), (itemStack) -> {
               return !this.shouldStopUsing(itemStack);
            }) || this.shouldStopUsing(currentStack) || !isTool(currentStack)) {
               this.ticks = (Integer)this.switchDelay.get();
               if (this.ticks == 0) {
                  InvUtils.swap(this.bestSlot, true);
               } else {
                  this.shouldSwitch = true;
               }
            }

            currentStack = this.mc.field_1724.method_6047();
            if (this.shouldStopUsing(currentStack) && isTool(currentStack)) {
               this.mc.field_1690.field_1886.method_23481(false);
               event.setCancelled(true);
            }

         }
      }
   }

   private boolean shouldStopUsing(class_1799 itemStack) {
      return (Boolean)this.antiBreak.get() && itemStack.method_7936() - itemStack.method_7919() < itemStack.method_7936() * (Integer)this.breakDurability.get() / 100;
   }

   public static double getScore(class_1799 itemStack, class_2680 state, boolean silkTouchEnderChest, AutoTool.EnchantPreference enchantPreference, Predicate<class_1799> good) {
      if (good.test(itemStack) && isTool(itemStack)) {
         if (silkTouchEnderChest && state.method_26204() == class_2246.field_10443 && class_1890.method_8225(class_1893.field_9099, itemStack) == 0) {
            return -1.0D;
         } else {
            double score = 0.0D;
            score += (double)(itemStack.method_7924(state) * 1000.0F);
            score += (double)class_1890.method_8225(class_1893.field_9119, itemStack);
            score += (double)class_1890.method_8225(class_1893.field_9131, itemStack);
            score += (double)class_1890.method_8225(class_1893.field_9101, itemStack);
            if (enchantPreference == AutoTool.EnchantPreference.Fortune) {
               score += (double)class_1890.method_8225(class_1893.field_9130, itemStack);
            }

            if (enchantPreference == AutoTool.EnchantPreference.SilkTouch) {
               score += (double)class_1890.method_8225(class_1893.field_9099, itemStack);
            }

            return score;
         }
      } else {
         return -1.0D;
      }
   }

   public static boolean isTool(class_1799 itemStack) {
      return itemStack.method_7909() instanceof class_1831 || itemStack.method_7909() instanceof class_1820;
   }

   public static enum EnchantPreference {
      None,
      Fortune,
      SilkTouch;

      // $FF: synthetic method
      private static AutoTool.EnchantPreference[] $values() {
         return new AutoTool.EnchantPreference[]{None, Fortune, SilkTouch};
      }
   }
}
