package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.events.entity.player.FinishUsingItemEvent;
import meteordevelopment.meteorclient.events.entity.player.StoppedUsingItemEvent;
import meteordevelopment.meteorclient.events.meteor.MouseButtonEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1753;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public class MiddleClickExtra extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<MiddleClickExtra.Mode> mode;
   private final Setting<Boolean> notify;
   private boolean isUsing;

   public MiddleClickExtra() {
      super(Categories.Player, "middle-click-extra", "Lets you use items when you middle click.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).description("Which item to use when you middle click.")).defaultValue(MiddleClickExtra.Mode.Pearl)).build());
      this.notify = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("notify")).description("Notifies you when you do not have the specified item in your hotbar.")).defaultValue(true)).build());
   }

   public void onDeactivate() {
      this.stopIfUsing();
   }

   @EventHandler
   private void onMouseButton(MouseButtonEvent event) {
      if (event.action == KeyAction.Press && event.button == 2) {
         FindItemResult result = InvUtils.findInHotbar(((MiddleClickExtra.Mode)this.mode.get()).item);
         if (!result.found()) {
            if ((Boolean)this.notify.get()) {
               this.warning("Unable to find specified item.", new Object[0]);
            }

         } else {
            InvUtils.swap(result.slot(), true);
            switch(((MiddleClickExtra.Mode)this.mode.get()).type) {
            case Immediate:
               this.mc.field_1761.method_2919(this.mc.field_1724, this.mc.field_1687, class_1268.field_5808);
               InvUtils.swapBack();
               break;
            case LongerSingleClick:
               this.mc.field_1761.method_2919(this.mc.field_1724, this.mc.field_1687, class_1268.field_5808);
               break;
            case Longer:
               this.mc.field_1690.field_1904.method_23481(true);
               this.isUsing = true;
            }

         }
      }
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (this.isUsing) {
         boolean pressed = true;
         if (this.mc.field_1724.method_6047().method_7909() instanceof class_1753) {
            pressed = class_1753.method_7722(this.mc.field_1724.method_6048()) < 1.0F;
         }

         this.mc.field_1690.field_1904.method_23481(pressed);
      }

   }

   @EventHandler
   private void onFinishUsingItem(FinishUsingItemEvent event) {
      this.stopIfUsing();
   }

   @EventHandler
   private void onStoppedUsingItem(StoppedUsingItemEvent event) {
      this.stopIfUsing();
   }

   private void stopIfUsing() {
      if (this.isUsing) {
         this.mc.field_1690.field_1904.method_23481(false);
         InvUtils.swapBack();
         this.isUsing = false;
      }

   }

   public static enum Mode {
      Pearl(class_1802.field_8634, MiddleClickExtra.Type.Immediate),
      Rocket(class_1802.field_8639, MiddleClickExtra.Type.Immediate),
      Rod(class_1802.field_8378, MiddleClickExtra.Type.LongerSingleClick),
      Bow(class_1802.field_8102, MiddleClickExtra.Type.Longer),
      Gap(class_1802.field_8463, MiddleClickExtra.Type.Longer),
      EGap(class_1802.field_8367, MiddleClickExtra.Type.Longer),
      Chorus(class_1802.field_8233, MiddleClickExtra.Type.Longer);

      private final class_1792 item;
      private final MiddleClickExtra.Type type;

      private Mode(class_1792 item, MiddleClickExtra.Type type) {
         this.item = item;
         this.type = type;
      }

      // $FF: synthetic method
      private static MiddleClickExtra.Mode[] $values() {
         return new MiddleClickExtra.Mode[]{Pearl, Rocket, Rod, Bow, Gap, EGap, Chorus};
      }
   }

   private static enum Type {
      Immediate,
      LongerSingleClick,
      Longer;

      // $FF: synthetic method
      private static MiddleClickExtra.Type[] $values() {
         return new MiddleClickExtra.Type[]{Immediate, LongerSingleClick, Longer};
      }
   }
}
