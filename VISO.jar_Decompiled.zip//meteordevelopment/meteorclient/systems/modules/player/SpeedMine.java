package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.StatusEffectInstanceAccessor;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

public class SpeedMine extends Module {
   private final SettingGroup sgGeneral;
   public final Setting<SpeedMine.Mode> mode;
   public final Setting<Double> modifier;

   public SpeedMine() {
      super(Categories.Player, "speed-mine", "Allows you to quickly mine blocks.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).defaultValue(SpeedMine.Mode.Normal)).build());
      this.modifier = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("modifier")).description("Mining speed modifier. An additional value of 0.2 is equivalent to one haste level (1.2 = haste 1).")).defaultValue(1.4D).min(0.0D).build());
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (this.mode.get() != SpeedMine.Mode.Normal) {
         int amplifier = this.mode.get() == SpeedMine.Mode.Haste2 ? 1 : 0;
         if (!this.mc.field_1724.method_6059(class_1294.field_5917)) {
            this.mc.field_1724.method_6092(new class_1293(class_1294.field_5917, 255, amplifier, false, false, false));
         }

         class_1293 effect = this.mc.field_1724.method_6112(class_1294.field_5917);
         ((StatusEffectInstanceAccessor)effect).setAmplifier(amplifier);
         if (effect.method_5584() < 20) {
            ((StatusEffectInstanceAccessor)effect).setDuration(20);
         }

      }
   }

   public static enum Mode {
      Normal,
      Haste1,
      Haste2;

      // $FF: synthetic method
      private static SpeedMine.Mode[] $values() {
         return new SpeedMine.Mode[]{Normal, Haste1, Haste2};
      }
   }
}
