package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;

public class LiquidInteract extends Module {
   public LiquidInteract() {
      super(Categories.Player, "liquid-interact", "Allows you to interact with liquids.");
   }
}
