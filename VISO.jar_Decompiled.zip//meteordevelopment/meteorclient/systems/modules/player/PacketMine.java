package meteordevelopment.meteorclient.systems.modules.player;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.BreakIndicators;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1292;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_3486;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2846.class_2847;

public class PacketMine extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgRender;
   private final Setting<Integer> delay;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> autoSwitch;
   private final Setting<Boolean> notOnUse;
   private final Setting<Boolean> render;
   private final Setting<ShapeMode> shapeMode;
   private final Setting<SettingColor> readySideColor;
   private final Setting<SettingColor> readyLineColor;
   private final Setting<SettingColor> sideColor;
   private final Setting<SettingColor> lineColor;
   private final Pool<PacketMine.MyBlock> blockPool;
   public final List<PacketMine.MyBlock> blocks;
   private boolean swapped;
   private boolean shouldUpdateSlot;

   public PacketMine() {
      super(Categories.World, "packet-mine", "Sends packets to mine blocks without the mining animation.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgRender = this.settings.createGroup("Render");
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("Delay between mining blocks in ticks.")).defaultValue(1)).min(0).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Sends rotation packets to the server when mining.")).defaultValue(true)).build());
      this.autoSwitch = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("auto-switch")).description("Automatically switches to the best tool when the block is ready to be mined instantly.")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      BoolSetting.Builder var10002 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("not-on-use")).description("Won't auto switch if you're using an item.")).defaultValue(true);
      Setting var10003 = this.autoSwitch;
      Objects.requireNonNull(var10003);
      this.notOnUse = var10001.add(((BoolSetting.Builder)var10002.visible(var10003::get)).build());
      this.render = this.sgRender.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("render")).description("Whether or not to render the block being mined.")).defaultValue(true)).build());
      this.shapeMode = this.sgRender.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
      this.readySideColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("ready-side-color")).description("The color of the sides of the blocks that can be broken.")).defaultValue(new SettingColor(0, 204, 0, 10))).build());
      this.readyLineColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("ready-line-color")).description("The color of the lines of the blocks that can be broken.")).defaultValue(new SettingColor(0, 204, 0, 255))).build());
      this.sideColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 10))).build());
      this.lineColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 255))).build());
      this.blockPool = new Pool(() -> {
         return new PacketMine.MyBlock();
      });
      this.blocks = new ArrayList();
   }

   public void onActivate() {
      this.swapped = false;
   }

   public void onDeactivate() {
      Iterator var1 = this.blocks.iterator();

      while(var1.hasNext()) {
         PacketMine.MyBlock block = (PacketMine.MyBlock)var1.next();
         this.blockPool.free(block);
      }

      this.blocks.clear();
      if (this.shouldUpdateSlot) {
         this.mc.field_1724.field_3944.method_2883(new class_2868(this.mc.field_1724.method_31548().field_7545));
         this.shouldUpdateSlot = false;
      }

   }

   @EventHandler
   private void onStartBreakingBlock(StartBreakingBlockEvent event) {
      if (BlockUtils.canBreak(event.blockPos)) {
         event.cancel();
         this.swapped = false;
         if (!this.isMiningBlock(event.blockPos)) {
            this.blocks.add(((PacketMine.MyBlock)this.blockPool.get()).set(event));
         }

      }
   }

   public boolean isMiningBlock(class_2338 pos) {
      Iterator var2 = this.blocks.iterator();

      PacketMine.MyBlock block;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         block = (PacketMine.MyBlock)var2.next();
      } while(!block.blockPos.equals(pos));

      return true;
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      this.blocks.removeIf(PacketMine.MyBlock::shouldRemove);
      if (this.shouldUpdateSlot) {
         this.mc.field_1724.field_3944.method_2883(new class_2868(this.mc.field_1724.method_31548().field_7545));
         this.shouldUpdateSlot = false;
      }

      if (!this.blocks.isEmpty()) {
         ((PacketMine.MyBlock)this.blocks.get(0)).mine();
      }

      if (!this.swapped && (Boolean)this.autoSwitch.get() && (!this.mc.field_1724.method_6115() || !(Boolean)this.notOnUse.get())) {
         Iterator var2 = this.blocks.iterator();

         while(var2.hasNext()) {
            PacketMine.MyBlock block = (PacketMine.MyBlock)var2.next();
            if (block.isReady()) {
               FindItemResult slot = InvUtils.findFastestTool(block.blockState);
               if (slot.found() && this.mc.field_1724.method_31548().field_7545 != slot.slot()) {
                  this.mc.field_1724.field_3944.method_2883(new class_2868(slot.slot()));
                  this.swapped = true;
                  this.shouldUpdateSlot = true;
                  break;
               }
            }
         }
      }

   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if ((Boolean)this.render.get()) {
         Iterator var2 = this.blocks.iterator();

         while(true) {
            PacketMine.MyBlock block;
            do {
               if (!var2.hasNext()) {
                  return;
               }

               block = (PacketMine.MyBlock)var2.next();
            } while(((BreakIndicators)Modules.get().get(BreakIndicators.class)).isActive() && (Boolean)((BreakIndicators)Modules.get().get(BreakIndicators.class)).packetMine.get() && block.mining);

            block.render(event);
         }
      }
   }

   private double getBreakDelta(int slot, class_2680 state) {
      float hardness = state.method_26214((class_1922)null, (class_2338)null);
      return hardness == -1.0F ? 0.0D : this.getBlockBreakingSpeed(slot, state) / (double)hardness / (double)(state.method_29291() && !((class_1799)this.mc.field_1724.method_31548().field_7547.get(slot)).method_7951(state) ? 100 : 30);
   }

   private double getBlockBreakingSpeed(int slot, class_2680 block) {
      double speed = (double)((class_1799)this.mc.field_1724.method_31548().field_7547.get(slot)).method_7924(block);
      if (speed > 1.0D) {
         class_1799 tool = this.mc.field_1724.method_31548().method_5438(slot);
         int efficiency = class_1890.method_8225(class_1893.field_9131, tool);
         if (efficiency > 0 && !tool.method_7960()) {
            speed += (double)(efficiency * efficiency + 1);
         }
      }

      if (class_1292.method_5576(this.mc.field_1724)) {
         speed *= (double)(1.0F + (float)(class_1292.method_5575(this.mc.field_1724) + 1) * 0.2F);
      }

      if (this.mc.field_1724.method_6059(class_1294.field_5901)) {
         float var10000;
         switch(this.mc.field_1724.method_6112(class_1294.field_5901).method_5578()) {
         case 0:
            var10000 = 0.3F;
            break;
         case 1:
            var10000 = 0.09F;
            break;
         case 2:
            var10000 = 0.0027F;
            break;
         default:
            var10000 = 8.1E-4F;
         }

         float k = var10000;
         speed *= (double)k;
      }

      if (this.mc.field_1724.method_5777(class_3486.field_15517) && !class_1890.method_8200(this.mc.field_1724)) {
         speed /= 5.0D;
      }

      if (!this.mc.field_1724.method_24828()) {
         speed /= 5.0D;
      }

      return speed;
   }

   public class MyBlock {
      public class_2338 blockPos;
      public class_2680 blockState;
      public class_2248 block;
      public class_2350 direction;
      public int timer;
      public boolean mining;
      public double progress;

      public PacketMine.MyBlock set(StartBreakingBlockEvent event) {
         this.blockPos = event.blockPos;
         this.direction = event.direction;
         this.blockState = PacketMine.this.mc.field_1687.method_8320(this.blockPos);
         this.block = this.blockState.method_26204();
         this.timer = (Integer)PacketMine.this.delay.get();
         this.mining = false;
         this.progress = 0.0D;
         return this;
      }

      public boolean shouldRemove() {
         boolean remove = PacketMine.this.mc.field_1687.method_8320(this.blockPos).method_26204() != this.block || Utils.distance(PacketMine.this.mc.field_1724.method_23317() - 0.5D, PacketMine.this.mc.field_1724.method_23318() + (double)PacketMine.this.mc.field_1724.method_18381(PacketMine.this.mc.field_1724.method_18376()), PacketMine.this.mc.field_1724.method_23321() - 0.5D, (double)(this.blockPos.method_10263() + this.direction.method_10148()), (double)(this.blockPos.method_10264() + this.direction.method_10164()), (double)(this.blockPos.method_10260() + this.direction.method_10165())) > (double)PacketMine.this.mc.field_1761.method_2904();
         if (remove) {
            PacketMine.this.mc.method_1562().method_2883(new class_2846(class_2847.field_12971, this.blockPos, this.direction));
            PacketMine.this.mc.method_1562().method_2883(new class_2879(class_1268.field_5808));
         }

         return remove;
      }

      public boolean isReady() {
         return this.progress >= 1.0D;
      }

      public void mine() {
         if ((Boolean)PacketMine.this.rotate.get()) {
            Rotations.rotate(Rotations.getYaw(this.blockPos), Rotations.getPitch(this.blockPos), 50, this::sendMinePackets);
         } else {
            this.sendMinePackets();
         }

         double bestScore = -1.0D;
         int bestSlot = -1;

         for(int i = 0; i < 9; ++i) {
            double score = (double)PacketMine.this.mc.field_1724.method_31548().method_5438(i).method_7924(this.blockState);
            if (score > bestScore) {
               bestScore = score;
               bestSlot = i;
            }
         }

         this.progress += PacketMine.this.getBreakDelta(bestSlot != -1 ? bestSlot : PacketMine.this.mc.field_1724.method_31548().field_7545, this.blockState);
      }

      private void sendMinePackets() {
         if (this.timer <= 0) {
            if (!this.mining) {
               PacketMine.this.mc.method_1562().method_2883(new class_2846(class_2847.field_12968, this.blockPos, this.direction));
               PacketMine.this.mc.method_1562().method_2883(new class_2846(class_2847.field_12973, this.blockPos, this.direction));
               this.mining = true;
            }
         } else {
            --this.timer;
         }

      }

      public void render(Render3DEvent event) {
         class_265 shape = PacketMine.this.mc.field_1687.method_8320(this.blockPos).method_26218(PacketMine.this.mc.field_1687, this.blockPos);
         double x1 = (double)this.blockPos.method_10263();
         double y1 = (double)this.blockPos.method_10264();
         double z1 = (double)this.blockPos.method_10260();
         double x2 = (double)(this.blockPos.method_10263() + 1);
         double y2 = (double)(this.blockPos.method_10264() + 1);
         double z2 = (double)(this.blockPos.method_10260() + 1);
         if (!shape.method_1110()) {
            x1 = (double)this.blockPos.method_10263() + shape.method_1091(class_2351.field_11048);
            y1 = (double)this.blockPos.method_10264() + shape.method_1091(class_2351.field_11052);
            z1 = (double)this.blockPos.method_10260() + shape.method_1091(class_2351.field_11051);
            x2 = (double)this.blockPos.method_10263() + shape.method_1105(class_2351.field_11048);
            y2 = (double)this.blockPos.method_10264() + shape.method_1105(class_2351.field_11052);
            z2 = (double)this.blockPos.method_10260() + shape.method_1105(class_2351.field_11051);
         }

         if (this.isReady()) {
            event.renderer.box(x1, y1, z1, x2, y2, z2, (Color)PacketMine.this.readySideColor.get(), (Color)PacketMine.this.readyLineColor.get(), (ShapeMode)PacketMine.this.shapeMode.get(), 0);
         } else {
            event.renderer.box(x1, y1, z1, x2, y2, z2, (Color)PacketMine.this.sideColor.get(), (Color)PacketMine.this.lineColor.get(), (ShapeMode)PacketMine.this.shapeMode.get(), 0);
         }

      }
   }
}
