package meteordevelopment.meteorclient.systems.modules.player;

import baritone.api.BaritoneAPI;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.entity.player.ItemUseCrosshairTargetEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.AnchorAura;
import meteordevelopment.meteorclient.systems.modules.combat.BedAura;
import meteordevelopment.meteorclient.systems.modules.combat.CrystalAura;
import meteordevelopment.meteorclient.systems.modules.combat.KillAura;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public class AutoEat extends Module {
   private static final Class<? extends Module>[] AURAS = new Class[]{KillAura.class, CrystalAura.class, AnchorAura.class, BedAura.class};
   private final SettingGroup sgGeneral;
   private final SettingGroup sgHunger;
   private final Setting<List<class_1792>> blacklist;
   private final Setting<Boolean> pauseAuras;
   private final Setting<Boolean> pauseBaritone;
   private final Setting<Integer> hungerThreshold;
   public boolean eating;
   private int slot;
   private int prevSlot;
   private final List<Class<? extends Module>> wasAura;
   private boolean wasBaritone;

   public AutoEat() {
      super(Categories.Player, "auto-eat", "Automatically eats food.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgHunger = this.settings.createGroup("Hunger");
      this.blacklist = this.sgGeneral.add(((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder()).name("blacklist")).description("Which items to not eat.")).defaultValue(class_1802.field_8367, class_1802.field_8463, class_1802.field_8233, class_1802.field_8635, class_1802.field_8323, class_1802.field_8726, class_1802.field_8511, class_1802.field_8680, class_1802.field_8766).filter(class_1792::method_19263).build());
      this.pauseAuras = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("pause-auras")).description("Pauses all auras when eating.")).defaultValue(true)).build());
      this.pauseBaritone = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("pause-baritone")).description("Pause baritone when eating.")).defaultValue(true)).build());
      this.hungerThreshold = this.sgHunger.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("hunger-threshold")).description("The level of hunger you eat at.")).defaultValue(16)).range(1, 19).sliderRange(1, 19).build());
      this.wasAura = new ArrayList();
   }

   public void onDeactivate() {
      if (this.eating) {
         this.stopEating();
      }

   }

   @EventHandler(
      priority = -100
   )
   private void onTick(TickEvent.Pre event) {
      if (!((AutoGap)Modules.get().get(AutoGap.class)).isEating()) {
         if (this.eating) {
            if (this.shouldEat()) {
               if (!this.mc.field_1724.method_31548().method_5438(this.slot).method_19267()) {
                  int slot = this.findSlot();
                  if (slot == -1) {
                     this.stopEating();
                     return;
                  }

                  this.changeSlot(slot);
               }

               this.eat();
            } else {
               this.stopEating();
            }
         } else if (this.shouldEat()) {
            this.slot = this.findSlot();
            if (this.slot != -1) {
               this.startEating();
            }
         }

      }
   }

   @EventHandler
   private void onItemUseCrosshairTarget(ItemUseCrosshairTargetEvent event) {
      if (this.eating) {
         event.target = null;
      }

   }

   private void startEating() {
      this.prevSlot = this.mc.field_1724.method_31548().field_7545;
      this.eat();
      this.wasAura.clear();
      if ((Boolean)this.pauseAuras.get()) {
         Class[] var1 = AURAS;
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            Class<? extends Module> klass = var1[var3];
            Module module = Modules.get().get(klass);
            if (module.isActive()) {
               this.wasAura.add(klass);
               module.toggle();
            }
         }
      }

      this.wasBaritone = false;
      if ((Boolean)this.pauseBaritone.get() && BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().isPathing()) {
         this.wasBaritone = true;
         BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute("pause");
      }

   }

   private void eat() {
      this.changeSlot(this.slot);
      this.setPressed(true);
      if (!this.mc.field_1724.method_6115()) {
         Utils.rightClick();
      }

      this.eating = true;
   }

   private void stopEating() {
      this.changeSlot(this.prevSlot);
      this.setPressed(false);
      this.eating = false;
      if ((Boolean)this.pauseAuras.get()) {
         Class[] var1 = AURAS;
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            Class<? extends Module> klass = var1[var3];
            Module module = Modules.get().get(klass);
            if (this.wasAura.contains(klass) && !module.isActive()) {
               module.toggle();
            }
         }
      }

      if ((Boolean)this.pauseBaritone.get() && this.wasBaritone) {
         BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute("resume");
      }

   }

   private void setPressed(boolean pressed) {
      this.mc.field_1690.field_1904.method_23481(pressed);
   }

   private void changeSlot(int slot) {
      InvUtils.swap(slot, false);
      this.slot = slot;
   }

   private boolean shouldEat() {
      return this.mc.field_1724.method_7344().method_7586() <= (Integer)this.hungerThreshold.get();
   }

   private int findSlot() {
      int slot = -1;
      int bestHunger = -1;

      for(int i = 0; i < 9; ++i) {
         class_1792 item = this.mc.field_1724.method_31548().method_5438(i).method_7909();
         if (item.method_19263()) {
            int hunger = item.method_19264().method_19230();
            if (hunger > bestHunger && !((List)this.blacklist.get()).contains(item)) {
               slot = i;
               bestHunger = hunger;
            }
         }
      }

      return slot;
   }
}
