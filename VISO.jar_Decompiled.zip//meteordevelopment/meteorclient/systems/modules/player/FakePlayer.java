package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.fakeplayer.FakePlayerManager;

public class FakePlayer extends Module {
   private final SettingGroup sgGeneral;
   public final Setting<String> name;
   public final Setting<Boolean> copyInv;
   public final Setting<Integer> health;

   public FakePlayer() {
      super(Categories.Player, "fake-player", "Spawns a client-side fake player for testing usages.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.name = this.sgGeneral.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("name")).description("The name of the fake player.")).defaultValue("seasnail8169")).build());
      this.copyInv = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("copy-inv")).description("Copies your exact inventory to the fake player.")).defaultValue(true)).build());
      this.health = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("health")).description("The fake player's default health.")).defaultValue(20)).min(1).sliderRange(1, 100).build());
   }

   public void onActivate() {
      FakePlayerManager.clear();
   }

   public void onDeactivate() {
      FakePlayerManager.clear();
   }

   public WWidget getWidget(GuiTheme theme) {
      WHorizontalList w = theme.horizontalList();
      WButton spawn = (WButton)w.add(theme.button("Spawn")).widget();
      spawn.action = () -> {
         if (this.isActive()) {
            FakePlayerManager.add((String)this.name.get(), (float)(Integer)this.health.get(), (Boolean)this.copyInv.get());
         }

      };
      WButton clear = (WButton)w.add(theme.button("Clear")).widget();
      clear.action = () -> {
         if (this.isActive()) {
            FakePlayerManager.clear();
         }

      };
      return w;
   }

   public String getInfoString() {
      return FakePlayerManager.getPlayers() != null ? String.valueOf(FakePlayerManager.getPlayers().size()) : null;
   }
}
