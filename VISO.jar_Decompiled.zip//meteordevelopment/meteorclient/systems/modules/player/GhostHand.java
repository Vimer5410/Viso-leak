package meteordevelopment.meteorclient.systems.modules.player;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_3965;

public class GhostHand extends Module {
   private final List<class_2338> posList = new ArrayList();

   public GhostHand() {
      super(Categories.Player, "ghost-hand", "Opens containers through walls.");
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (this.mc.field_1690.field_1904.method_1434() && !this.mc.field_1724.method_5715()) {
         Iterator var2 = Utils.blockEntities().iterator();

         while(var2.hasNext()) {
            class_2586 blockEntity = (class_2586)var2.next();
            if ((new class_2338(this.mc.field_1724.method_5745((double)this.mc.field_1761.method_2904(), this.mc.method_1488(), false).method_17784())).equals(blockEntity.method_11016())) {
               return;
            }
         }

         class_243 nextPos = (new class_243(0.0D, 0.0D, 0.1D)).method_1037(-((float)Math.toRadians((double)this.mc.field_1724.method_36455()))).method_1024(-((float)Math.toRadians((double)this.mc.field_1724.method_36454())));

         for(int i = 1; (float)i < this.mc.field_1761.method_2904() * 10.0F; ++i) {
            class_2338 curPos = new class_2338(this.mc.field_1724.method_5836(this.mc.method_1488()).method_1019(nextPos.method_1021((double)i)));
            if (!this.posList.contains(curPos)) {
               this.posList.add(curPos);
               Iterator var5 = Utils.blockEntities().iterator();

               while(var5.hasNext()) {
                  class_2586 blockEntity = (class_2586)var5.next();
                  if (blockEntity.method_11016().equals(curPos)) {
                     this.mc.field_1761.method_2896(this.mc.field_1724, this.mc.field_1687, class_1268.field_5808, new class_3965(this.mc.field_1724.method_19538(), class_2350.field_11036, curPos, true));
                     return;
                  }
               }
            }
         }

         this.posList.clear();
      }
   }
}
