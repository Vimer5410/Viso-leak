package meteordevelopment.meteorclient.systems.modules.combat;

import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_1297;
import net.minecraft.class_1299;

public class Hitboxes extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Object2BooleanMap<class_1299<?>>> entities;
   private final Setting<Double> value;

   public Hitboxes() {
      super(Categories.Combat, "hitboxes", "Expands an entity's hitboxes.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder()).name("entities")).description("Which entities to target.")).defaultValue(class_1299.field_6097).build());
      this.value = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("expand")).description("How much to expand the hitbox of the entity.")).defaultValue(0.5D).build());
   }

   public double getEntityValue(class_1297 entity) {
      if (!this.isActive()) {
         return 0.0D;
      } else {
         return ((Object2BooleanMap)this.entities.get()).getBoolean(entity.method_5864()) ? (Double)this.value.get() : 0.0D;
      }
   }
}
