package meteordevelopment.meteorclient.systems.modules.combat;

import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.WorldRendererAccessor;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.DamageUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.meteorclient.utils.world.CardinalDirection;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2824;
import net.minecraft.class_2879;
import net.minecraft.class_3191;
import net.minecraft.class_2338.class_2339;

public class Surround extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgRender;
   private final Setting<List<class_2248>> blocks;
   private final Setting<Integer> delay;
   private final Setting<Surround.Center> center;
   private final Setting<Boolean> doubleHeight;
   private final Setting<Boolean> onlyOnGround;
   private final Setting<Boolean> toggleOnYChange;
   private final Setting<Boolean> toggleOnComplete;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> protect;
   private final Setting<Boolean> render;
   private final Setting<Boolean> renderBelow;
   private final Setting<ShapeMode> shapeMode;
   private final Setting<SettingColor> safeColor;
   private final Setting<SettingColor> normalColor;
   private final Setting<SettingColor> unSafeColor;
   private final class_2339 placePos;
   private final class_2339 renderPos;
   private final class_2339 testPos;
   private int ticks;

   public Surround() {
      super(Categories.Combat, "surround", "Surrounds you in blocks to prevent massive crystal damage.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgRender = this.settings.createGroup("Render");
      this.blocks = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("blocks")).description("What blocks to use for surround.")).defaultValue(class_2246.field_10540).filter(this::blockFilter).build());
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("Delay, in ticks, between block placements.")).min(0).defaultValue(0)).build());
      this.center = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("center")).description("Teleports you to the center of the block.")).defaultValue(Surround.Center.Incomplete)).build());
      this.doubleHeight = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("double-height")).description("Places obsidian on top of the original surround blocks to prevent people from face-placing you.")).defaultValue(false)).build());
      this.onlyOnGround = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("only-on-ground")).description("Works only when you are standing on blocks.")).defaultValue(true)).build());
      this.toggleOnYChange = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("toggle-on-y-change")).description("Automatically disables when your y level (step, jumping, atc).")).defaultValue(true)).build());
      this.toggleOnComplete = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("toggle-on-complete")).description("Toggles off when all blocks are placed.")).defaultValue(false)).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Automatically faces towards the obsidian being placed.")).defaultValue(true)).build());
      this.protect = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("protect")).description("Attempts to break crystals around surround positions to prevent surround break.")).defaultValue(true)).build());
      this.render = this.sgRender.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("render")).description("Renders a block overlay where the obsidian will be placed.")).defaultValue(true)).build());
      this.renderBelow = this.sgRender.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("below")).description("Renders the block below you.")).defaultValue(true)).build());
      this.shapeMode = this.sgRender.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Sides)).build());
      this.safeColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("safe-color")).description("The color of safe blocks.")).defaultValue(new SettingColor(13, 255, 0, 80))).build());
      this.normalColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("normal-color")).description("The color of the normal surround blocks.")).defaultValue(new SettingColor(0, 255, 238, 80))).build());
      this.unSafeColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("unsafe-color")).description("The color of unsafe blocks.")).defaultValue(new SettingColor(204, 0, 0, 80))).build());
      this.placePos = new class_2339();
      this.renderPos = new class_2339();
      this.testPos = new class_2339();
   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      if ((Boolean)this.render.get()) {
         if ((Boolean)this.renderBelow.get()) {
            this.draw(event, (CardinalDirection)null, -1, 0);
         }

         CardinalDirection[] var2 = CardinalDirection.values();
         int var3 = var2.length;

         int var4;
         CardinalDirection direction;
         for(var4 = 0; var4 < var3; ++var4) {
            direction = var2[var4];
            this.draw(event, direction, 0, (Boolean)this.doubleHeight.get() ? 2 : 0);
         }

         if ((Boolean)this.doubleHeight.get()) {
            var2 = CardinalDirection.values();
            var3 = var2.length;

            for(var4 = 0; var4 < var3; ++var4) {
               direction = var2[var4];
               this.draw(event, direction, 1, 4);
            }
         }

      }
   }

   private void draw(Render3DEvent event, CardinalDirection direction, int y, int exclude) {
      this.renderPos.method_10101(this.offsetPosFromPlayer(direction, y));
      Color color = this.getBlockColor(this.renderPos);
      event.renderer.box((class_2338)this.renderPos, color, color, (ShapeMode)this.shapeMode.get(), exclude);
   }

   public void onActivate() {
      if (this.center.get() == Surround.Center.OnActivate) {
         PlayerUtils.centerPlayer();
      }

      this.ticks = 0;
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if ((Boolean)this.toggleOnYChange.get() && this.mc.field_1724.field_6036 < this.mc.field_1724.method_23318()) {
         this.toggle();
      } else if (!(Boolean)this.onlyOnGround.get() || this.mc.field_1724.method_24828()) {
         if (this.getInvBlock().found()) {
            if (this.center.get() == Surround.Center.Always) {
               PlayerUtils.centerPlayer();
            }

            if (this.ticks > 0) {
               --this.ticks;
            } else {
               this.ticks = (Integer)this.delay.get();
               int safe = 0;
               CardinalDirection[] var3 = CardinalDirection.values();
               int var4 = var3.length;

               int var5;
               CardinalDirection direction;
               for(var5 = 0; var5 < var4; ++var5) {
                  direction = var3[var5];
                  if (this.place(direction, 0)) {
                     break;
                  }

                  ++safe;
               }

               if ((Boolean)this.doubleHeight.get() && safe == 4) {
                  var3 = CardinalDirection.values();
                  var4 = var3.length;

                  for(var5 = 0; var5 < var4; ++var5) {
                     direction = var3[var5];
                     if (this.place(direction, 1)) {
                        break;
                     }

                     ++safe;
                  }
               }

               boolean complete = safe == ((Boolean)this.doubleHeight.get() ? 8 : 4);
               if (complete && (Boolean)this.toggleOnComplete.get()) {
                  this.toggle();
               } else {
                  if (!complete && this.center.get() == Surround.Center.Incomplete) {
                     PlayerUtils.centerPlayer();
                  }

               }
            }
         }
      }
   }

   private boolean place(CardinalDirection direction, int y) {
      this.placePos.method_10101(this.offsetPosFromPlayer(direction, y));
      boolean placed = BlockUtils.place(this.placePos, this.getInvBlock(), (Boolean)this.rotate.get(), 100, true);
      boolean beingMined = false;
      ObjectIterator var5 = ((WorldRendererAccessor)this.mc.field_1769).getBlockBreakingInfos().values().iterator();

      while(var5.hasNext()) {
         class_3191 value = (class_3191)var5.next();
         if (value.method_13991().equals(this.placePos)) {
            beingMined = true;
            break;
         }
      }

      boolean isThreat = this.mc.field_1687.method_8320(this.placePos).method_26207().method_15800() || beingMined;
      if ((Boolean)this.protect.get() && !placed && isThreat) {
         class_238 box = new class_238((double)(this.placePos.method_10263() - 1), (double)(this.placePos.method_10264() - 1), (double)(this.placePos.method_10260() - 1), (double)(this.placePos.method_10263() + 1), (double)(this.placePos.method_10264() + 1), (double)(this.placePos.method_10260() + 1));
         Predicate<class_1297> entityPredicate = (entity) -> {
            return entity instanceof class_1511 && DamageUtils.crystalDamage(this.mc.field_1724, entity.method_19538()) < PlayerUtils.getTotalHealth();
         };

         for(Iterator var8 = this.mc.field_1687.method_8333((class_1297)null, box, entityPredicate).iterator(); var8.hasNext(); this.mc.method_1562().method_2883(new class_2879(class_1268.field_5808))) {
            class_1297 crystal = (class_1297)var8.next();
            if ((Boolean)this.rotate.get()) {
               Rotations.rotate(Rotations.getPitch(crystal), Rotations.getYaw(crystal), () -> {
                  this.mc.field_1724.field_3944.method_2883(class_2824.method_34206(crystal, this.mc.field_1724.method_5715()));
               });
            } else {
               this.mc.field_1724.field_3944.method_2883(class_2824.method_34206(crystal, this.mc.field_1724.method_5715()));
            }
         }
      }

      return placed;
   }

   private class_2339 offsetPosFromPlayer(CardinalDirection direction, int y) {
      return this.offsetPos(this.mc.field_1724.method_24515(), direction, y);
   }

   private class_2339 offsetPos(class_2338 origin, CardinalDirection direction, int y) {
      return direction == null ? this.testPos.method_10103(origin.method_10263(), origin.method_10264() + y, origin.method_10260()) : this.testPos.method_10103(origin.method_10263() + direction.toDirection().method_10148(), origin.method_10264() + y, origin.method_10260() + direction.toDirection().method_10165());
   }

   private Surround.BlockType getBlockType(class_2338 pos) {
      class_2680 blockState = this.mc.field_1687.method_8320(pos);
      if (blockState.method_26204().method_36555() < 0.0F) {
         return Surround.BlockType.Safe;
      } else {
         return blockState.method_26204().method_9520() >= 600.0F ? Surround.BlockType.Normal : Surround.BlockType.Unsafe;
      }
   }

   private Color getBlockColor(class_2338 pos) {
      SettingColor var10000;
      switch(this.getBlockType(pos)) {
      case Safe:
         var10000 = (SettingColor)this.safeColor.get();
         break;
      case Normal:
         var10000 = (SettingColor)this.normalColor.get();
         break;
      case Unsafe:
         var10000 = (SettingColor)this.unSafeColor.get();
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private FindItemResult getInvBlock() {
      return InvUtils.findInHotbar((itemStack) -> {
         return ((List)this.blocks.get()).contains(class_2248.method_9503(itemStack.method_7909()));
      });
   }

   private boolean blockFilter(class_2248 block) {
      return block == class_2246.field_10540 || block == class_2246.field_22423 || block == class_2246.field_22108 || block == class_2246.field_10443 || block == class_2246.field_23152;
   }

   public static enum Center {
      Never,
      OnActivate,
      Incomplete,
      Always;

      // $FF: synthetic method
      private static Surround.Center[] $values() {
         return new Surround.Center[]{Never, OnActivate, Incomplete, Always};
      }
   }

   public static enum BlockType {
      Safe,
      Normal,
      Unsafe;

      // $FF: synthetic method
      private static Surround.BlockType[] $values() {
         return new Surround.BlockType[]{Safe, Normal, Unsafe};
      }
   }
}
