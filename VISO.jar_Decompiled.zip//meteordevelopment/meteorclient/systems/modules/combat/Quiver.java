package meteordevelopment.meteorclient.systems.modules.combat;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StatusEffectListSetting;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2828.class_2831;

public class Quiver extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<List<class_1291>> effects;
   private final Setting<Boolean> checkEffects;
   private final List<Integer> arrowSlots;

   public Quiver() {
      super(Categories.Combat, "quiver", "Shoots arrows at yourself.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.effects = this.sgGeneral.add(((StatusEffectListSetting.Builder)((StatusEffectListSetting.Builder)(new StatusEffectListSetting.Builder()).name("effects")).description("Which effects to shoot you with.")).defaultValue(class_1294.field_5910).build());
      this.checkEffects = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("check-existing-effects")).description("Won't shoot you with effects you already have.")).defaultValue(true)).build());
      this.arrowSlots = new ArrayList();
   }

   public void onActivate() {
      FindItemResult bow = InvUtils.findInHotbar(class_1802.field_8102);
      if (!bow.isHotbar()) {
         this.error("No bow found... disabling.", new Object[0]);
         this.toggle();
      }

      this.mc.field_1690.field_1904.method_23481(false);
      this.mc.field_1761.method_2897(this.mc.field_1724);
      InvUtils.swap(bow.slot(), true);
      this.arrowSlots.clear();
      List<class_1291> usedEffects = new ArrayList();

      for(int i = this.mc.field_1724.method_31548().method_5439(); i > 0; --i) {
         if (i != this.mc.field_1724.method_31548().field_7545) {
            class_1799 item = this.mc.field_1724.method_31548().method_5438(i);
            if (item.method_7909() == class_1802.field_8087) {
               List<class_1293> effects = class_1844.method_8067(item);
               if (!effects.isEmpty()) {
                  class_1291 effect = ((class_1293)effects.get(0)).method_5579();
                  if (((List)this.effects.get()).contains(effect) && !usedEffects.contains(effect) && (!this.hasEffect(effect) || !(Boolean)this.checkEffects.get())) {
                     usedEffects.add(effect);
                     this.arrowSlots.add(i);
                  }
               }
            }
         }
      }

   }

   private boolean hasEffect(class_1291 effect) {
      Iterator var2 = this.mc.field_1724.method_6026().iterator();

      class_1293 statusEffect;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         statusEffect = (class_1293)var2.next();
      } while(statusEffect.method_5579() != effect);

      return true;
   }

   public void onDeactivate() {
      InvUtils.swapBack();
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (!this.arrowSlots.isEmpty() && InvUtils.findInHotbar(class_1802.field_8102).isMainHand()) {
         boolean charging = this.mc.field_1690.field_1904.method_1434();
         if (!charging) {
            InvUtils.move().from((Integer)this.arrowSlots.get(0)).to(9);
            this.mc.field_1690.field_1904.method_23481(true);
         } else if ((double)class_1753.method_7722(this.mc.field_1724.method_6048()) >= 0.12D) {
            int targetSlot = (Integer)this.arrowSlots.get(0);
            this.arrowSlots.remove(0);
            this.mc.method_1562().method_2883(new class_2831(this.mc.field_1724.method_36454(), -90.0F, this.mc.field_1724.method_24828()));
            this.mc.field_1690.field_1904.method_23481(false);
            this.mc.field_1761.method_2897(this.mc.field_1724);
            if (targetSlot != 9) {
               InvUtils.move().from(9).to(targetSlot);
            }
         }

      } else {
         this.toggle();
      }
   }
}
