package meteordevelopment.meteorclient.systems.modules.combat;

import meteordevelopment.meteorclient.events.meteor.MouseButtonEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;

public class Offhand extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Offhand.Item> item;
   private final Setting<Boolean> hotbar;
   private final Setting<Boolean> rightClick;
   private final Setting<Boolean> swordGap;
   private final Setting<Boolean> crystalCa;
   private final Setting<Boolean> crystalMine;
   private boolean isClicking;
   private boolean sentMessage;
   private Offhand.Item currentItem;

   public Offhand() {
      super(Categories.Combat, "offhand", "Allows you to hold specified items in your offhand.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.item = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("item")).description("Which item to hold in your offhand.")).defaultValue(Offhand.Item.Crystal)).build());
      this.hotbar = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("hotbar")).description("Whether to use items from your hotbar.")).defaultValue(false)).build());
      this.rightClick = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("right-click")).description("Only holds the item in your offhand when you are holding right click.")).defaultValue(false)).build());
      this.swordGap = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("sword-gap")).description("Holds an Enchanted Golden Apple when you are holding a sword.")).defaultValue(true)).build());
      this.crystalCa = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("crystal-on-ca")).description("Holds a crystal when you have Crystal Aura enabled.")).defaultValue(true)).build());
      this.crystalMine = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("crystal-on-mine")).description("Holds a crystal when you are mining.")).defaultValue(false)).build());
   }

   public void onActivate() {
      this.sentMessage = false;
      this.isClicking = false;
      this.currentItem = (Offhand.Item)this.item.get();
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      AutoTotem autoTotem = (AutoTotem)Modules.get().get(AutoTotem.class);
      if ((this.mc.field_1724.method_6047().method_7909() instanceof class_1829 || this.mc.field_1724.method_6047().method_7909() instanceof class_1743) && (Boolean)this.swordGap.get()) {
         this.currentItem = Offhand.Item.EGap;
      } else if ((!Modules.get().isActive(CrystalAura.class) || !(Boolean)this.crystalCa.get()) && (!this.mc.field_1761.method_2923() || !(Boolean)this.crystalMine.get())) {
         this.currentItem = (Offhand.Item)this.item.get();
      } else {
         this.currentItem = Offhand.Item.Crystal;
      }

      FindItemResult totem;
      if (this.mc.field_1724.method_6079().method_7909() != this.currentItem.item) {
         totem = InvUtils.find((itemStack) -> {
            return itemStack.method_7909() == this.currentItem.item;
         }, (Boolean)this.hotbar.get() ? 0 : 9, 35);
         if (!totem.found()) {
            if (!this.sentMessage) {
               this.warning("Chosen item not found.", new Object[0]);
               this.sentMessage = true;
            }
         } else if ((this.isClicking || !(Boolean)this.rightClick.get()) && !autoTotem.isLocked() && !totem.isOffhand()) {
            InvUtils.move().from(totem.slot()).toOffhand();
            this.sentMessage = false;
         }
      } else if (!this.isClicking && (Boolean)this.rightClick.get()) {
         if (autoTotem.isActive()) {
            totem = InvUtils.find((itemStack) -> {
               return itemStack.method_7909() == class_1802.field_8288;
            }, (Boolean)this.hotbar.get() ? 0 : 9, 35);
            if (totem.found() && !totem.isOffhand()) {
               InvUtils.move().from(totem.slot()).toOffhand();
            }
         } else {
            totem = InvUtils.find(class_1799::method_7960, (Boolean)this.hotbar.get() ? 0 : 9, 35);
            if (totem.found()) {
               InvUtils.move().fromOffhand().to(totem.slot());
            }
         }
      }

   }

   @EventHandler
   private void onMouseButton(MouseButtonEvent event) {
      this.isClicking = this.mc.field_1755 == null && !((AutoTotem)Modules.get().get(AutoTotem.class)).isLocked() && !this.usableItem() && !this.mc.field_1724.method_6115() && event.action == KeyAction.Press && event.button == 1;
   }

   private boolean usableItem() {
      return this.mc.field_1724.method_6047().method_7909() == class_1802.field_8102 || this.mc.field_1724.method_6047().method_7909() == class_1802.field_8547 || this.mc.field_1724.method_6047().method_7909() == class_1802.field_8399 || this.mc.field_1724.method_6047().method_7909().method_19263();
   }

   public String getInfoString() {
      return ((Offhand.Item)this.item.get()).name();
   }

   public static enum Item {
      EGap(class_1802.field_8367),
      Gap(class_1802.field_8463),
      Crystal(class_1802.field_8301),
      Totem(class_1802.field_8288),
      Shield(class_1802.field_8255);

      class_1792 item;

      private Item(class_1792 item) {
         this.item = item;
      }

      // $FF: synthetic method
      private static Offhand.Item[] $values() {
         return new Offhand.Item[]{EGap, Gap, Crystal, Totem, Shield};
      }
   }
}
