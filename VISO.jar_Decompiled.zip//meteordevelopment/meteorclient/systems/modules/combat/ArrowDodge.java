package meteordevelopment.meteorclient.systems.modules.combat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.ProjectileInGroundAccessor;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1665;
import net.minecraft.class_1676;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_2828.class_2829;

public class ArrowDodge extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgMovement;
   private final Setting<Integer> arrowLookahead;
   private final Setting<ArrowDodge.MoveType> moveType;
   private final Setting<Double> moveSpeed;
   private final Setting<Boolean> groundCheck;
   private final List<class_243> possibleMoveDirections;

   public ArrowDodge() {
      super(Categories.Combat, "arrow-dodge", "Tries to dodge arrows coming at you.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgMovement = this.settings.createGroup("Movement");
      this.arrowLookahead = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("arrow-lookahead")).description("How many steps into the future should be taken into consideration when deciding the direction")).defaultValue(500)).range(1, 750).build());
      this.moveType = this.sgMovement.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("move-type")).description("The way you are moved by this module")).defaultValue(ArrowDodge.MoveType.Client)).build());
      this.moveSpeed = this.sgMovement.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("move-speed")).description("How fast should you be when dodging arrow")).defaultValue(1.0D).min(0.01D).sliderRange(0.01D, 5.0D).build());
      this.groundCheck = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ground-check")).description("Tries to prevent you from falling to your death.")).defaultValue(true)).build());
      this.possibleMoveDirections = Arrays.asList(new class_243(1.0D, 0.0D, 1.0D), new class_243(0.0D, 0.0D, 1.0D), new class_243(-1.0D, 0.0D, 1.0D), new class_243(1.0D, 0.0D, 0.0D), new class_243(-1.0D, 0.0D, 0.0D), new class_243(1.0D, 0.0D, -1.0D), new class_243(0.0D, 0.0D, -1.0D), new class_243(-1.0D, 0.0D, -1.0D));
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      class_238 playerHitbox = this.mc.field_1724.method_5829();
      playerHitbox = playerHitbox.method_1014(0.6D);
      double speed = (Double)this.moveSpeed.get();
      Iterator var5 = this.mc.field_1687.method_18112().iterator();

      label63:
      while(true) {
         class_1297 e;
         do {
            do {
               if (!var5.hasNext()) {
                  return;
               }

               e = (class_1297)var5.next();
            } while(!(e instanceof class_1676));
         } while(e instanceof class_1665 && ((ProjectileInGroundAccessor)e).getInGround());

         List<class_238> futureArrowHitboxes = new ArrayList();

         for(int i = 0; i < (Integer)this.arrowLookahead.get(); ++i) {
            class_243 nextPos = e.method_19538().method_1019(e.method_18798().method_1021((double)((float)i / 5.0F)));
            futureArrowHitboxes.add(new class_238(nextPos.method_1023(e.method_5829().method_17939() / 2.0D, 0.0D, e.method_5829().method_17941() / 2.0D), nextPos.method_1031(e.method_5829().method_17939() / 2.0D, e.method_5829().method_17940(), e.method_5829().method_17941() / 2.0D)));
         }

         Iterator var15 = futureArrowHitboxes.iterator();

         while(true) {
            class_238 arrowHitbox;
            do {
               if (!var15.hasNext()) {
                  continue label63;
               }

               arrowHitbox = (class_238)var15.next();
            } while(!playerHitbox.method_994(arrowHitbox));

            Collections.shuffle(this.possibleMoveDirections);
            boolean didMove = false;
            Iterator var11 = this.possibleMoveDirections.iterator();

            while(var11.hasNext()) {
               class_243 direction = (class_243)var11.next();
               class_243 velocity = direction.method_1021(speed);
               if (this.isValid(velocity, futureArrowHitboxes, playerHitbox)) {
                  this.move(velocity);
                  didMove = true;
                  break;
               }
            }

            if (!didMove) {
               double yaw = Math.toRadians((double)e.method_36454());
               double pitch = Math.toRadians((double)e.method_36455());
               this.move(Math.sin(yaw) * Math.cos(pitch) * speed, Math.sin(pitch) * speed, -Math.cos(yaw) * Math.cos(pitch) * speed);
            }
         }
      }
   }

   private void move(class_243 vel) {
      this.move(vel.field_1352, vel.field_1351, vel.field_1350);
   }

   private void move(double velX, double velY, double velZ) {
      switch((ArrowDodge.MoveType)this.moveType.get()) {
      case Client:
         this.mc.field_1724.method_18800(velX, velY, velZ);
         break;
      case Packet:
         class_243 newPos = this.mc.field_1724.method_19538().method_1031(velX, velY, velZ);
         this.mc.field_1724.field_3944.method_2883(new class_2829(newPos.field_1352, newPos.field_1351, newPos.field_1350, false));
         this.mc.field_1724.field_3944.method_2883(new class_2829(newPos.field_1352, newPos.field_1351 - 0.01D, newPos.field_1350, true));
      }

   }

   private boolean isValid(class_243 velocity, List<class_238> futureArrowHitboxes, class_238 playerHitbox) {
      class_2338 blockPos = null;
      Iterator var5 = futureArrowHitboxes.iterator();

      do {
         if (!var5.hasNext()) {
            if ((Boolean)this.groundCheck.get() && blockPos != null) {
               return this.mc.field_1687.method_8320(blockPos.method_10074()).method_26220(this.mc.field_1687, blockPos.method_10074()) != class_259.method_1073();
            }

            return true;
         }

         class_238 futureArrowHitbox = (class_238)var5.next();
         class_238 newPlayerPos = playerHitbox.method_997(velocity);
         if (futureArrowHitbox.method_994(newPlayerPos)) {
            return false;
         }

         blockPos = this.mc.field_1724.method_24515().method_10080(velocity.field_1352, velocity.field_1351, velocity.field_1350);
      } while(this.mc.field_1687.method_8320(blockPos).method_26220(this.mc.field_1687, blockPos) == class_259.method_1073());

      return false;
   }

   public static enum MoveType {
      Client,
      Packet;

      // $FF: synthetic method
      private static ArrowDodge.MoveType[] $values() {
         return new ArrowDodge.MoveType[]{Client, Packet};
      }
   }
}
