package meteordevelopment.meteorclient.systems.modules.combat;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1802;

public class AutoWeb extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Double> range;
   private final Setting<SortPriority> priority;
   private final Setting<Boolean> doubles;
   private final Setting<Boolean> rotate;
   private class_1657 target;

   public AutoWeb() {
      super(Categories.Combat, "auto-web", "Automatically places webs on other players.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.range = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("target-range")).description("The maximum distance to target players.")).defaultValue(4.0D).range(0.0D, 5.0D).sliderMax(5.0D).build());
      this.priority = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("target-priority")).description("How to select the player to target.")).defaultValue(SortPriority.LowestDistance)).build());
      this.doubles = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("doubles")).description("Places webs in the target's upper hitbox as well as the lower hitbox.")).defaultValue(false)).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Rotates towards the webs when placing.")).defaultValue(true)).build());
      this.target = null;
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (TargetUtils.isBadTarget(this.target, (Double)this.range.get())) {
         this.target = TargetUtils.getPlayerTarget((Double)this.range.get(), (SortPriority)this.priority.get());
      }

      if (!TargetUtils.isBadTarget(this.target, (Double)this.range.get())) {
         BlockUtils.place(this.target.method_24515(), InvUtils.findInHotbar(class_1802.field_8786), (Boolean)this.rotate.get(), 0, false);
         if ((Boolean)this.doubles.get()) {
            BlockUtils.place(this.target.method_24515().method_10069(0, 1, 0), InvUtils.findInHotbar(class_1802.field_8786), (Boolean)this.rotate.get(), 0, false);
         }

      }
   }
}
