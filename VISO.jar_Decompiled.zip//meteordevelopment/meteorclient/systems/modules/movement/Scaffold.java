package meteordevelopment.meteorclient.systems.modules.movement;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2338.class_2339;

public class Scaffold extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgRender;
   private final Setting<List<class_2248>> blocks;
   private final Setting<Scaffold.ListMode> blocksFilter;
   private final Setting<Boolean> fastTower;
   private final Setting<Boolean> renderSwing;
   private final Setting<Boolean> autoSwitch;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> airPlace;
   private final Setting<Double> placeRange;
   private final Setting<ShapeMode> shapeMode;
   private final Setting<SettingColor> sideColor;
   private final Setting<SettingColor> lineColor;
   private final Pool<Scaffold.RenderBlock> renderBlockPool;
   private final List<Scaffold.RenderBlock> renderBlocks;
   private final class_2339 bp;
   private final class_2339 prevBp;
   private boolean lastWasSneaking;
   private double lastSneakingY;

   public Scaffold() {
      super(Categories.Movement, "scaffold", "Automatically places blocks under you.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgRender = this.settings.createGroup("Render");
      this.blocks = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("blocks")).description("Selected blocks.")).build());
      this.blocksFilter = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("blocks-filter")).description("How to use the block list setting")).defaultValue(Scaffold.ListMode.Blacklist)).build());
      this.fastTower = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("fast-tower")).description("Whether or not to scaffold upwards faster.")).defaultValue(false)).build());
      this.renderSwing = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("swing")).description("Renders your client-side swing.")).defaultValue(false)).build());
      this.autoSwitch = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("auto-switch")).description("Automatically swaps to a block before placing.")).defaultValue(true)).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Rotates towards the blocks being placed.")).defaultValue(true)).build());
      this.airPlace = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("air-place")).description("Allow air place.")).defaultValue(false)).build());
      this.placeRange = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("closest-block-range")).description("How far can scaffold place blocks.")).defaultValue(4.0D).min(0.0D).sliderMax(8.0D).visible(() -> {
         return !(Boolean)this.airPlace.get();
      })).build());
      this.shapeMode = this.sgRender.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
      this.sideColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("side-color")).description("The side color of the target block rendering.")).defaultValue(new SettingColor(197, 137, 232, 10))).build());
      this.lineColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("line-color")).description("The line color of the target block rendering.")).defaultValue(new SettingColor(197, 137, 232))).build());
      this.renderBlockPool = new Pool(Scaffold.RenderBlock::new);
      this.renderBlocks = new ArrayList();
      this.bp = new class_2339();
      this.prevBp = new class_2339();
   }

   public void onActivate() {
      this.lastWasSneaking = this.mc.field_1690.field_1832.method_1434();
      if (this.lastWasSneaking) {
         this.lastSneakingY = this.mc.field_1724.method_23318();
      }

      Iterator var1 = this.renderBlocks.iterator();

      while(var1.hasNext()) {
         Scaffold.RenderBlock renderBlock = (Scaffold.RenderBlock)var1.next();
         this.renderBlockPool.free(renderBlock);
      }

      this.renderBlocks.clear();
   }

   public void onDeactivate() {
      Iterator var1 = this.renderBlocks.iterator();

      while(var1.hasNext()) {
         Scaffold.RenderBlock renderBlock = (Scaffold.RenderBlock)var1.next();
         this.renderBlockPool.free(renderBlock);
      }

      this.renderBlocks.clear();
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      this.renderBlocks.forEach(Scaffold.RenderBlock::tick);
      this.renderBlocks.removeIf((renderBlock) -> {
         return renderBlock.ticks <= 0;
      });
      class_243 pos;
      if ((Boolean)this.airPlace.get()) {
         pos = this.mc.field_1724.method_19538().method_1019(this.mc.field_1724.method_18798()).method_1031(0.0D, -0.5D, 0.0D);
         this.bp.method_10102(pos.method_10216(), pos.method_10214(), pos.method_10215());
      } else if (BlockUtils.getPlaceSide(this.mc.field_1724.method_24515().method_10074()) != null) {
         this.bp.method_10101(this.mc.field_1724.method_24515().method_10074());
      } else {
         pos = this.mc.field_1724.method_19538();
         pos = pos.method_1031(0.0D, -0.9800000190734863D, 0.0D);
         pos.method_1019(this.mc.field_1724.method_18798());
         if (PlayerUtils.distanceTo((class_2338)this.prevBp) > (Double)this.placeRange.get()) {
            List<class_2338> blockPosArray = new ArrayList();
            int x = (int)(this.mc.field_1724.method_23317() - (Double)this.placeRange.get());

            while(true) {
               if (!((double)x < this.mc.field_1724.method_23317() + (Double)this.placeRange.get())) {
                  if (blockPosArray.size() == 0) {
                     return;
                  }

                  blockPosArray.sort(Comparator.comparingDouble(PlayerUtils::distanceTo));
                  this.prevBp.method_10101((class_2382)blockPosArray.get(0));
                  break;
               }

               for(int z = (int)(this.mc.field_1724.method_23321() - (Double)this.placeRange.get()); (double)z < this.mc.field_1724.method_23321() + (Double)this.placeRange.get(); ++z) {
                  for(int y = (int)Math.max((double)this.mc.field_1687.method_31607(), this.mc.field_1724.method_23318() - (Double)this.placeRange.get()); (double)y < Math.min((double)this.mc.field_1687.method_31600(), this.mc.field_1724.method_23318() + (Double)this.placeRange.get()); ++y) {
                     this.bp.method_10103(x, y, z);
                     if (!this.mc.field_1687.method_8320(this.bp).method_26215()) {
                        blockPosArray.add(new class_2338(this.bp));
                     }
                  }
               }

               ++x;
            }
         }

         class_243 vecPrevBP = new class_243((double)this.prevBp.method_10263() + 0.5D, (double)this.prevBp.method_10264() + 0.5D, (double)this.prevBp.method_10260() + 0.5D);
         class_243 sub = pos.method_1020(vecPrevBP);
         class_2350 facing;
         if (sub.method_10214() < -0.5D) {
            facing = class_2350.field_11033;
         } else if (sub.method_10214() > 0.5D) {
            facing = class_2350.field_11036;
         } else {
            facing = class_2350.method_10142(sub.method_10216(), 0.0D, sub.method_10215());
         }

         this.bp.method_10101(this.prevBp.method_10093(facing));
      }

      FindItemResult item = InvUtils.findInHotbar((itemStack) -> {
         return this.validItem(itemStack, this.bp);
      });
      if (item.found()) {
         if (item.getHand() != null || (Boolean)this.autoSwitch.get()) {
            if (this.mc.field_1690.field_1832.method_1434() && !this.mc.field_1690.field_1903.method_1434()) {
               if (this.lastSneakingY - this.mc.field_1724.method_23318() < 0.1D) {
                  this.lastWasSneaking = false;
                  return;
               }
            } else {
               this.lastWasSneaking = false;
            }

            if (!this.lastWasSneaking) {
               this.lastSneakingY = this.mc.field_1724.method_23318();
            }

            if (this.mc.field_1690.field_1903.method_1434() && !this.mc.field_1690.field_1832.method_1434() && (Boolean)this.fastTower.get()) {
               this.mc.field_1724.method_18800(0.0D, 0.41999998688697815D, 0.0D);
            }

            if (BlockUtils.place(this.bp, item, (Boolean)this.rotate.get(), 50, (Boolean)this.renderSwing.get(), true)) {
               this.renderBlocks.add(((Scaffold.RenderBlock)this.renderBlockPool.get()).set(this.bp));
               if (this.mc.field_1690.field_1903.method_1434() && !this.mc.field_1690.field_1832.method_1434() && !this.mc.field_1724.method_24828() && !this.mc.field_1687.method_8320(this.bp).method_26215() && (Boolean)this.fastTower.get()) {
                  this.mc.field_1724.method_18800(0.0D, -0.2800000011920929D, 0.0D);
               }
            }

            if (!this.mc.field_1687.method_8320(this.bp).method_26215()) {
               this.prevBp.method_10101(this.bp);
            }

         }
      }
   }

   private boolean validItem(class_1799 itemStack, class_2338 pos) {
      if (!(itemStack.method_7909() instanceof class_1747)) {
         return false;
      } else {
         class_2248 block = ((class_1747)itemStack.method_7909()).method_7711();
         if (this.blocksFilter.get() == Scaffold.ListMode.Blacklist && ((List)this.blocks.get()).contains(block)) {
            return false;
         } else if (this.blocksFilter.get() == Scaffold.ListMode.Whitelist && !((List)this.blocks.get()).contains(block)) {
            return false;
         } else if (!class_2248.method_9614(block.method_9564().method_26220(this.mc.field_1687, pos))) {
            return false;
         } else {
            return !(block instanceof class_2346) || !class_2346.method_10128(this.mc.field_1687.method_8320(pos));
         }
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      this.renderBlocks.sort(Comparator.comparingInt((o) -> {
         return -o.ticks;
      }));
      this.renderBlocks.forEach((renderBlock) -> {
         renderBlock.render(event, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get());
      });
   }

   public static enum ListMode {
      Whitelist,
      Blacklist;

      // $FF: synthetic method
      private static Scaffold.ListMode[] $values() {
         return new Scaffold.ListMode[]{Whitelist, Blacklist};
      }
   }

   public static class RenderBlock {
      public class_2339 pos = new class_2339();
      public int ticks;

      public Scaffold.RenderBlock set(class_2338 blockPos) {
         this.pos.method_10101(blockPos);
         this.ticks = 8;
         return this;
      }

      public void tick() {
         --this.ticks;
      }

      public void render(Render3DEvent event, Color sides, Color lines, ShapeMode shapeMode) {
         int preSideA = sides.a;
         int preLineA = lines.a;
         sides.a = (int)((double)sides.a * ((double)this.ticks / 8.0D));
         lines.a = (int)((double)lines.a * ((double)this.ticks / 8.0D));
         event.renderer.box((class_2338)this.pos, sides, lines, shapeMode, 0);
         sides.a = preSideA;
         lines.a = preLineA;
      }
   }
}
