package meteordevelopment.meteorclient.systems.modules.movement;

import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2828;

public class Blink extends Module {
   private final List<class_2828> packets = new ArrayList();
   private int timer = 0;

   public Blink() {
      super(Categories.Movement, "blink", "Allows you to essentially teleport while suspending motion updates.");
   }

   public void onDeactivate() {
      synchronized(this.packets) {
         this.packets.forEach((p) -> {
            this.mc.field_1724.field_3944.method_2883(p);
         });
         this.packets.clear();
         this.timer = 0;
      }
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      ++this.timer;
   }

   @EventHandler
   private void onSendPacket(PacketEvent.Send event) {
      if (event.packet instanceof class_2828) {
         event.cancel();
         synchronized(this.packets) {
            class_2828 p = (class_2828)event.packet;
            class_2828 prev = this.packets.size() == 0 ? null : (class_2828)this.packets.get(this.packets.size() - 1);
            if (prev == null || p.method_12273() != prev.method_12273() || p.method_12271(-1.0F) != prev.method_12271(-1.0F) || p.method_12270(-1.0F) != prev.method_12270(-1.0F) || p.method_12269(-1.0D) != prev.method_12269(-1.0D) || p.method_12268(-1.0D) != prev.method_12268(-1.0D) || p.method_12274(-1.0D) != prev.method_12274(-1.0D)) {
               this.packets.add(p);
            }
         }
      }
   }

   public String getInfoString() {
      return String.format("%.1f", (float)this.timer / 20.0F);
   }
}
