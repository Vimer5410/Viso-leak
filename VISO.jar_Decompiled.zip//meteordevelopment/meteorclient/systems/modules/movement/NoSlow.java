package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.entity.player.CobwebEntityCollisionEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.world.Timer;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;

public class NoSlow extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> items;
   public final Setting<NoSlow.WebMode> web;
   public final Setting<Integer> webTimer;
   private final Setting<Boolean> soulSand;
   private final Setting<Boolean> slimeBlock;
   private final Setting<Boolean> airStrict;
   private final Setting<Boolean> sneaking;
   private boolean resetTimer;

   public NoSlow() {
      super(Categories.Movement, "no-slow", "Allows you to move normally when using objects that will slow you.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.items = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("items")).description("Whether or not using items will slow you.")).defaultValue(true)).build());
      this.web = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("web")).description("Whether or not cobwebs will not slow you down.")).defaultValue(NoSlow.WebMode.Vanilla)).build());
      this.webTimer = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("web-timer")).description("The timer value for WebMode Timer.")).defaultValue(10)).min(1).sliderMin(1).visible(() -> {
         return this.web.get() == NoSlow.WebMode.Timer;
      })).build());
      this.soulSand = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("soul-sand")).description("Whether or not Soul Sand will not slow you down.")).defaultValue(true)).build());
      this.slimeBlock = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("slime-block")).description("Whether or not slime blocks will not slow you down.")).defaultValue(true)).build());
      this.airStrict = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("air-strict")).description("Will attempt to bypass anti-cheats like 2b2t's. Only works while in air.")).defaultValue(false)).build());
      this.sneaking = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("sneaking")).description("Whether or not sneaking will not slow you down.")).defaultValue(false)).build());
   }

   public void onActivate() {
      this.resetTimer = false;
   }

   public boolean airStrict() {
      return this.isActive() && (Boolean)this.airStrict.get() && this.mc.field_1724.method_6115();
   }

   public boolean items() {
      return this.isActive() && (Boolean)this.items.get();
   }

   public boolean soulSand() {
      return this.isActive() && (Boolean)this.soulSand.get();
   }

   public boolean slimeBlock() {
      return this.isActive() && (Boolean)this.slimeBlock.get();
   }

   public boolean sneaking() {
      return this.isActive() && (Boolean)this.sneaking.get();
   }

   @EventHandler
   private void onWebEntityCollision(CobwebEntityCollisionEvent event) {
      if (this.web.get() == NoSlow.WebMode.Vanilla) {
         event.cancel();
      }

   }

   @EventHandler
   private void onPreTick(TickEvent.Pre event) {
      if (this.web.get() == NoSlow.WebMode.Timer) {
         if (this.mc.field_1687.method_8320(this.mc.field_1724.method_24515()).method_26204() == class_2246.field_10343 && !this.mc.field_1724.method_24828()) {
            this.resetTimer = false;
            ((Timer)Modules.get().get(Timer.class)).setOverride((double)(Integer)this.webTimer.get());
         } else if (!this.resetTimer) {
            ((Timer)Modules.get().get(Timer.class)).setOverride(1.0D);
            this.resetTimer = true;
         }
      }

   }

   public static enum WebMode {
      Vanilla,
      Timer,
      None;

      // $FF: synthetic method
      private static NoSlow.WebMode[] $values() {
         return new NoSlow.WebMode[]{Vanilla, Timer, None};
      }
   }
}
