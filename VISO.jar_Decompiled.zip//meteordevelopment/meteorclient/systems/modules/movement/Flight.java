package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.PlayerMoveC2SPacketAccessor;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2828;

public class Flight extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgAntiKick;
   private final Setting<Flight.Mode> mode;
   private final Setting<Double> speed;
   private final Setting<Boolean> verticalSpeedMatch;
   private final Setting<Flight.AntiKickMode> antiKickMode;
   private final Setting<Integer> delay;
   private final Setting<Integer> offTime;
   private int delayLeft;
   private int offLeft;
   private boolean flip;
   private float lastYaw;
   private long lastModifiedTime;
   private double lastY;

   public Flight() {
      super(Categories.Movement, "flight", "FLYYYY! No Fall is recommended with this module.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgAntiKick = this.settings.createGroup("Anti Kick");
      this.mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).description("The mode for Flight.")).defaultValue(Flight.Mode.Abilities)).build());
      this.speed = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("speed")).description("Your speed when flying.")).defaultValue(0.1D).min(0.0D).build());
      this.verticalSpeedMatch = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("vertical-speed-match")).description("Matches your vertical speed to your horizontal speed, otherwise uses vanilla ratio.")).defaultValue(false)).build());
      this.antiKickMode = this.sgAntiKick.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).description("The mode for anti kick.")).defaultValue(Flight.AntiKickMode.Packet)).build());
      this.delay = this.sgAntiKick.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("The amount of delay, in ticks, between toggles in normal mode.")).defaultValue(80)).range(1, 5000).sliderMax(200).visible(() -> {
         return this.antiKickMode.get() == Flight.AntiKickMode.Normal;
      })).build());
      this.offTime = this.sgAntiKick.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("off-time")).description("The amount of delay, in ticks, that Flight is toggled off for in normal mode.")).defaultValue(5)).range(1, 20).visible(() -> {
         return this.antiKickMode.get() == Flight.AntiKickMode.Normal;
      })).build());
      this.delayLeft = (Integer)this.delay.get();
      this.offLeft = (Integer)this.offTime.get();
      this.lastModifiedTime = 0L;
      this.lastY = Double.MAX_VALUE;
   }

   public void onActivate() {
      if (this.mode.get() == Flight.Mode.Abilities && !this.mc.field_1724.method_7325()) {
         this.mc.field_1724.method_31549().field_7479 = true;
         if (this.mc.field_1724.method_31549().field_7477) {
            return;
         }

         this.mc.field_1724.method_31549().field_7478 = true;
      }

   }

   public void onDeactivate() {
      if (this.mode.get() == Flight.Mode.Abilities && !this.mc.field_1724.method_7325()) {
         this.mc.field_1724.method_31549().field_7479 = false;
         this.mc.field_1724.method_31549().method_7248(0.05F);
         if (this.mc.field_1724.method_31549().field_7477) {
            return;
         }

         this.mc.field_1724.method_31549().field_7478 = false;
      }

   }

   @EventHandler
   private void onPreTick(TickEvent.Pre event) {
      float currentYaw = this.mc.field_1724.method_36454();
      if (this.mc.field_1724.field_6017 >= 3.0F && currentYaw == this.lastYaw && this.mc.field_1724.method_18798().method_1033() < 0.003D) {
         this.mc.field_1724.method_36456(currentYaw + (float)(this.flip ? 1 : -1));
         this.flip = !this.flip;
      }

      this.lastYaw = currentYaw;
   }

   @EventHandler
   private void onPostTick(TickEvent.Post event) {
      if (this.antiKickMode.get() == Flight.AntiKickMode.Normal && this.delayLeft > 0) {
         --this.delayLeft;
      } else {
         if (this.antiKickMode.get() == Flight.AntiKickMode.Normal && this.delayLeft <= 0 && this.offLeft > 0) {
            --this.offLeft;
            if (this.mode.get() == Flight.Mode.Abilities) {
               this.mc.field_1724.method_31549().field_7479 = false;
               this.mc.field_1724.method_31549().method_7248(0.05F);
               if (this.mc.field_1724.method_31549().field_7477) {
                  return;
               }

               this.mc.field_1724.method_31549().field_7478 = false;
            }

            return;
         }

         if (this.antiKickMode.get() == Flight.AntiKickMode.Normal && this.delayLeft <= 0 && this.offLeft <= 0) {
            this.delayLeft = (Integer)this.delay.get();
            this.offLeft = (Integer)this.offTime.get();
         }
      }

      if (this.mc.field_1724.method_36454() != this.lastYaw) {
         this.mc.field_1724.method_36456(this.lastYaw);
      }

      switch((Flight.Mode)this.mode.get()) {
      case Velocity:
         this.mc.field_1724.method_31549().field_7479 = false;
         this.mc.field_1724.field_6281 = ((Double)this.speed.get()).floatValue() * (this.mc.field_1724.method_5624() ? 15.0F : 10.0F);
         this.mc.field_1724.method_18800(0.0D, 0.0D, 0.0D);
         class_243 initialVelocity = this.mc.field_1724.method_18798();
         if (this.mc.field_1690.field_1903.method_1434()) {
            this.mc.field_1724.method_18799(initialVelocity.method_1031(0.0D, (Double)this.speed.get() * (double)((Boolean)this.verticalSpeedMatch.get() ? 10.0F : 5.0F), 0.0D));
         }

         if (this.mc.field_1690.field_1832.method_1434()) {
            this.mc.field_1724.method_18799(initialVelocity.method_1023(0.0D, (Double)this.speed.get() * (double)((Boolean)this.verticalSpeedMatch.get() ? 10.0F : 5.0F), 0.0D));
         }
         break;
      case Abilities:
         if (this.mc.field_1724.method_7325()) {
            return;
         }

         this.mc.field_1724.method_31549().method_7248(((Double)this.speed.get()).floatValue());
         this.mc.field_1724.method_31549().field_7479 = true;
         if (this.mc.field_1724.method_31549().field_7477) {
            return;
         }

         this.mc.field_1724.method_31549().field_7478 = true;
      }

   }

   @EventHandler
   private void onSendPacket(PacketEvent.Send event) {
      if (event.packet instanceof class_2828 && this.antiKickMode.get() == Flight.AntiKickMode.Packet) {
         class_2828 packet = (class_2828)event.packet;
         long currentTime = System.currentTimeMillis();
         double currentY = packet.method_12268(Double.MAX_VALUE);
         if (currentY != Double.MAX_VALUE) {
            if (currentTime - this.lastModifiedTime > 1000L && this.lastY != Double.MAX_VALUE && this.mc.field_1687.method_8320(this.mc.field_1724.method_24515().method_10074()).method_26215()) {
               ((PlayerMoveC2SPacketAccessor)packet).setY(this.lastY - 0.0313D);
               this.lastModifiedTime = currentTime;
            } else {
               this.lastY = currentY;
            }
         }

      }
   }

   public static enum Mode {
      Abilities,
      Velocity;

      // $FF: synthetic method
      private static Flight.Mode[] $values() {
         return new Flight.Mode[]{Abilities, Velocity};
      }
   }

   public static enum AntiKickMode {
      Normal,
      Packet,
      None;

      // $FF: synthetic method
      private static Flight.AntiKickMode[] $values() {
         return new Flight.AntiKickMode[]{Normal, Packet, None};
      }
   }
}
