package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;

public class Sprint extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> whenStationary;

   public Sprint() {
      super(Categories.Movement, "sprint", "Automatically sprints.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.whenStationary = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("when-stationary")).description("Continues sprinting even if you do not move.")).defaultValue(true)).build());
   }

   public void onDeactivate() {
      this.mc.field_1724.method_5728(false);
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (this.mc.field_1724.field_6250 > 0.0F && !(Boolean)this.whenStationary.get()) {
         this.mc.field_1724.method_5728(true);
      } else if ((Boolean)this.whenStationary.get()) {
         this.mc.field_1724.method_5728(true);
      }

   }
}
