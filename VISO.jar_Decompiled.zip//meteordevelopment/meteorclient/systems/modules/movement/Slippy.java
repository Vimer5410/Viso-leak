package meteordevelopment.meteorclient.systems.modules.movement;

import java.util.List;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_2248;

public class Slippy extends Module {
   private final SettingGroup sgGeneral;
   public final Setting<Double> slippness;
   public final Setting<List<class_2248>> blocks;

   public Slippy() {
      super(Categories.Movement, "slippy", "Makes blocks slippery like ice.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.slippness = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("slippness")).description("Decide how slippery blocks should be")).min(0.0D).max(1.1D).sliderMax(1.1D).defaultValue(1.02D).build());
      this.blocks = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("ignored blocks")).description("Decide which blocks not to slip on")).defaultValue().build());
   }
}
