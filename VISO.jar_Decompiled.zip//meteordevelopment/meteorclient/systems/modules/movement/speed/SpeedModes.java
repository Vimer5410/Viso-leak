package meteordevelopment.meteorclient.systems.modules.movement.speed;

public enum SpeedModes {
   Strafe,
   Vanilla;

   // $FF: synthetic method
   private static SpeedModes[] $values() {
      return new SpeedModes[]{Strafe, Vanilla};
   }
}
