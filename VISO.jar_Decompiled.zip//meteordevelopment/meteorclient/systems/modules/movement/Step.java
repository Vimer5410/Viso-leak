package meteordevelopment.meteorclient.systems.modules.movement;

import baritone.api.BaritoneAPI;
import com.google.common.collect.Streams;
import java.util.Comparator;
import java.util.Objects;
import java.util.Optional;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.DamageUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1511;

public class Step extends Module {
   private final SettingGroup sgGeneral;
   public final Setting<Double> height;
   private final Setting<Step.ActiveWhen> activeWhen;
   private final Setting<Boolean> safeStep;
   private final Setting<Integer> stepHealth;
   private float prevStepHeight;
   private boolean prevBaritoneAssumeStep;

   public Step() {
      super(Categories.Movement, "step", "Allows you to walk up full blocks instantly.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.height = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("height")).description("Step height.")).defaultValue(1.0D).min(0.0D).build());
      this.activeWhen = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("active-when")).description("Step is active when you meet these requirements.")).defaultValue(Step.ActiveWhen.Always)).build());
      this.safeStep = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("safe-step")).description("Doesn't let you step out of a hole if you are low on health or there is a crystal nearby.")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      IntSetting.Builder var10002 = ((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("step-health")).description("The health you stop being able to step at.")).defaultValue(5)).range(1, 36).sliderRange(1, 36);
      Setting var10003 = this.safeStep;
      Objects.requireNonNull(var10003);
      this.stepHealth = var10001.add(((IntSetting.Builder)var10002.visible(var10003::get)).build());
   }

   public void onActivate() {
      this.prevStepHeight = this.mc.field_1724.field_6013;
      this.prevBaritoneAssumeStep = (Boolean)BaritoneAPI.getSettings().assumeStep.value;
      BaritoneAPI.getSettings().assumeStep.value = true;
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      boolean work = this.activeWhen.get() == Step.ActiveWhen.Always || this.activeWhen.get() == Step.ActiveWhen.Sneaking && this.mc.field_1724.method_5715() || this.activeWhen.get() == Step.ActiveWhen.NotSneaking && !this.mc.field_1724.method_5715();
      this.mc.field_1724.method_5857(this.mc.field_1724.method_5829().method_989(0.0D, 1.0D, 0.0D));
      if (!work || (Boolean)this.safeStep.get() && (!(this.getHealth() > (float)(Integer)this.stepHealth.get()) || !((double)this.getHealth() - this.getExplosionDamage() > (double)(Integer)this.stepHealth.get()))) {
         this.mc.field_1724.field_6013 = this.prevStepHeight;
      } else {
         this.mc.field_1724.field_6013 = ((Double)this.height.get()).floatValue();
      }

      this.mc.field_1724.method_5857(this.mc.field_1724.method_5829().method_989(0.0D, -1.0D, 0.0D));
   }

   public void onDeactivate() {
      this.mc.field_1724.field_6013 = this.prevStepHeight;
      BaritoneAPI.getSettings().assumeStep.value = this.prevBaritoneAssumeStep;
   }

   private float getHealth() {
      return this.mc.field_1724.method_6032() + this.mc.field_1724.method_6067();
   }

   private double getExplosionDamage() {
      Optional<class_1511> crystal = Streams.stream(this.mc.field_1687.method_18112()).filter((entity) -> {
         return entity instanceof class_1511;
      }).filter(class_1297::method_5805).max(Comparator.comparingDouble((o) -> {
         return DamageUtils.crystalDamage(this.mc.field_1724, o.method_19538());
      })).map((entity) -> {
         return (class_1511)entity;
      });
      return (Double)crystal.map((endCrystalEntity) -> {
         return DamageUtils.crystalDamage(this.mc.field_1724, endCrystalEntity.method_19538());
      }).orElse(0.0D);
   }

   public static enum ActiveWhen {
      Always,
      Sneaking,
      NotSneaking;

      // $FF: synthetic method
      private static Step.ActiveWhen[] $values() {
         return new Step.ActiveWhen[]{Always, Sneaking, NotSneaking};
      }
   }
}
