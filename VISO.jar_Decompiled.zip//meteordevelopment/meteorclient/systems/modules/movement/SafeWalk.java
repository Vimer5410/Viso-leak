package meteordevelopment.meteorclient.systems.modules.movement;

import java.util.List;
import meteordevelopment.meteorclient.events.entity.player.ClipAtLedgeEvent;
import meteordevelopment.meteorclient.events.world.CollisionShapeEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2231;
import net.minecraft.class_2241;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2266;
import net.minecraft.class_2275;
import net.minecraft.class_2533;
import net.minecraft.class_2537;
import net.minecraft.class_2538;
import net.minecraft.class_2560;
import net.minecraft.class_259;
import net.minecraft.class_3830;
import net.minecraft.class_3922;
import net.minecraft.class_4770;
import net.minecraft.class_5635;

public class SafeWalk extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> ledge;
   private final Setting<List<class_2248>> blocks;
   private final Setting<Boolean> magma;

   public SafeWalk() {
      super(Categories.Movement, "safe-walk", "Prevents you from walking off blocks or on blocks that you dont want.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.ledge = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ledge")).description("Prevents you from walking of blocks, like pressing shift.")).defaultValue(true)).build());
      this.blocks = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("blocks")).description("Which blocks to prevent on walking")).filter(this::blockFilter).build());
      this.magma = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("magma")).description("Prevents you from walking over magma blocks.")).defaultValue(false)).build());
   }

   @EventHandler
   private void onClipAtLedge(ClipAtLedgeEvent event) {
      if (!this.mc.field_1724.method_5715()) {
         event.setClip((Boolean)this.ledge.get());
      }

   }

   @EventHandler
   private void onCollisionShape(CollisionShapeEvent event) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         if (event.type == CollisionShapeEvent.CollisionType.BLOCK) {
            if (((List)this.blocks.get()).contains(event.state.method_26204())) {
               event.shape = class_259.method_1077();
            } else if ((Boolean)this.magma.get() && !this.mc.field_1724.method_5715() && event.state.method_26215() && this.mc.field_1687.method_8320(event.pos.method_10074()).method_26204() == class_2246.field_10092) {
               event.shape = class_259.method_1077();
            }

         }
      }
   }

   private boolean blockFilter(class_2248 block) {
      if (block instanceof class_4770) {
         return true;
      } else if (block instanceof class_2231) {
         return true;
      } else if (block instanceof class_2538) {
         return true;
      } else if (block instanceof class_2537) {
         return true;
      } else if (block instanceof class_2560) {
         return true;
      } else if (block instanceof class_3922) {
         return true;
      } else if (block instanceof class_3830) {
         return true;
      } else if (block instanceof class_2266) {
         return true;
      } else if (block instanceof class_2241) {
         return true;
      } else if (block instanceof class_2533) {
         return true;
      } else if (block instanceof class_5635) {
         return true;
      } else {
         return block instanceof class_2275;
      }
   }
}
