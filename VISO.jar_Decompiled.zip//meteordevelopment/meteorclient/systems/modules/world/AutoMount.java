package meteordevelopment.meteorclient.systems.modules.world;

import java.util.Iterator;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1452;
import net.minecraft.class_1495;
import net.minecraft.class_1498;
import net.minecraft.class_1500;
import net.minecraft.class_1501;
import net.minecraft.class_1506;
import net.minecraft.class_1690;
import net.minecraft.class_1695;
import net.minecraft.class_1826;

public class AutoMount extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgMount;
   private final Setting<Boolean> checkSaddle;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> horses;
   private final Setting<Boolean> donkeys;
   private final Setting<Boolean> mules;
   private final Setting<Boolean> skeletonHorse;
   private final Setting<Boolean> llamas;
   private final Setting<Boolean> pigs;
   private final Setting<Boolean> boats;
   private final Setting<Boolean> minecarts;

   public AutoMount() {
      super(Categories.World, "auto-mount", "Automatically mounts entities.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgMount = this.settings.createGroup("Mount");
      this.checkSaddle = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("check-saddle")).description("Checks if the entity contains a saddle before mounting.")).defaultValue(false)).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Faces the entity you mount.")).defaultValue(true)).build());
      this.horses = this.sgMount.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("horse")).description("Horse")).defaultValue(false)).build());
      this.donkeys = this.sgMount.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("donkey")).description("Donkey")).defaultValue(false)).build());
      this.mules = this.sgMount.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("mule")).description("Mule")).defaultValue(false)).build());
      this.skeletonHorse = this.sgMount.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("skeleton-horse")).description("Skeleton Horse")).defaultValue(false)).build());
      this.llamas = this.sgMount.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("llama")).description("Llama")).defaultValue(false)).build());
      this.pigs = this.sgMount.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("pig")).description("Pig")).defaultValue(false)).build());
      this.boats = this.sgMount.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("boat")).description("Boat")).defaultValue(false)).build());
      this.minecarts = this.sgMount.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("minecart")).description("Minecart")).defaultValue(false)).build());
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (!this.mc.field_1724.method_5765()) {
         Iterator var2 = this.mc.field_1687.method_18112().iterator();

         while(true) {
            while(true) {
               class_1297 entity;
               do {
                  if (!var2.hasNext()) {
                     return;
                  }

                  entity = (class_1297)var2.next();
               } while(this.mc.field_1724.method_5739(entity) > 4.0F);

               if (this.mc.field_1724.method_6047().method_7909() instanceof class_1826) {
                  return;
               }

               if ((Boolean)this.donkeys.get() && entity instanceof class_1495 && (!(Boolean)this.checkSaddle.get() || ((class_1495)entity).method_6725())) {
                  this.interact(entity);
               } else if ((Boolean)this.llamas.get() && entity instanceof class_1501) {
                  this.interact(entity);
               } else if ((Boolean)this.boats.get() && entity instanceof class_1690) {
                  this.interact(entity);
               } else if ((Boolean)this.minecarts.get() && entity instanceof class_1695) {
                  this.interact(entity);
               } else if ((Boolean)this.horses.get() && entity instanceof class_1498 && (!(Boolean)this.checkSaddle.get() || ((class_1498)entity).method_6725())) {
                  this.interact(entity);
               } else if ((Boolean)this.pigs.get() && entity instanceof class_1452 && ((class_1452)entity).method_6725()) {
                  this.interact(entity);
               } else if (!(Boolean)this.mules.get() || !(entity instanceof class_1500) || (Boolean)this.checkSaddle.get() && !((class_1500)entity).method_6725()) {
                  if ((Boolean)this.skeletonHorse.get() && entity instanceof class_1506 && (!(Boolean)this.checkSaddle.get() || ((class_1506)entity).method_6725())) {
                     this.interact(entity);
                  }
               } else {
                  this.interact(entity);
               }
            }
         }
      }
   }

   private void interact(class_1297 entity) {
      if ((Boolean)this.rotate.get()) {
         Rotations.rotate(Rotations.getYaw(entity), Rotations.getPitch(entity), -100, () -> {
            this.mc.field_1761.method_2905(this.mc.field_1724, entity, class_1268.field_5808);
         });
      } else {
         this.mc.field_1761.method_2905(this.mc.field_1724, entity, class_1268.field_5808);
      }

   }
}
