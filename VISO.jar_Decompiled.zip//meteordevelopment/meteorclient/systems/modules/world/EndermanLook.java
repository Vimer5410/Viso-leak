package meteordevelopment.meteorclient.systems.modules.world;

import java.util.Iterator;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.Target;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1560;
import net.minecraft.class_243;

public class EndermanLook extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<EndermanLook.Mode> lookMode;

   public EndermanLook() {
      super(Categories.World, "enderman-look", "Either looks at all Endermen or prevents you from looking at Endermen.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.lookMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("look-mode")).description("How this module behaves.")).defaultValue(EndermanLook.Mode.Away)).build());
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (this.lookMode.get() == EndermanLook.Mode.Away) {
         if (this.mc.field_1724.method_31549().field_7477 || !this.shouldLook()) {
            return;
         }

         Rotations.rotate((double)this.mc.field_1724.method_36454(), 90.0D, -75, (Runnable)null);
      } else {
         Iterator var2 = this.mc.field_1687.method_18112().iterator();

         while(var2.hasNext()) {
            class_1297 entity = (class_1297)var2.next();
            if (entity instanceof class_1560) {
               class_1560 enderman = (class_1560)entity;
               if (!enderman.method_7028() && enderman.method_5805() && this.mc.field_1724.method_6057(enderman)) {
                  Rotations.rotate(Rotations.getYaw((class_1297)enderman), Rotations.getPitch(enderman, Target.Head), -75, (Runnable)null);
                  break;
               }
            }
         }
      }

   }

   private boolean shouldLook() {
      Iterator var1 = this.mc.field_1687.method_18112().iterator();

      class_1297 entity;
      do {
         if (!var1.hasNext()) {
            return false;
         }

         entity = (class_1297)var1.next();
      } while(!(entity instanceof class_1560) || !entity.method_5805() || !this.angleCheck(entity));

      return true;
   }

   private boolean angleCheck(class_1297 entity) {
      class_243 vec3d = this.mc.field_1724.method_5828(1.0F).method_1029();
      class_243 vec3d2 = new class_243(entity.method_23317() - this.mc.field_1724.method_23317(), entity.method_23320() - this.mc.field_1724.method_23320(), entity.method_23321() - this.mc.field_1724.method_23321());
      double d = vec3d2.method_1033();
      vec3d2 = vec3d2.method_1029();
      double e = vec3d.method_1026(vec3d2);
      return e > 1.0D - 0.025D / d && this.mc.field_1724.method_6057(entity);
   }

   public static enum Mode {
      At,
      Away;

      // $FF: synthetic method
      private static EndermanLook.Mode[] $values() {
         return new EndermanLook.Mode[]{At, Away};
      }
   }
}
