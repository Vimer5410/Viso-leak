package meteordevelopment.meteorclient.systems.modules.world;

import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1747;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

public class LiquidFiller extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<LiquidFiller.PlaceIn> placeInLiquids;
   private final Setting<Integer> horizontalRadius;
   private final Setting<Integer> verticalRadius;
   private final Setting<Integer> delay;
   private final Setting<List<class_2248>> whitelist;
   private final Setting<Boolean> rotate;
   private int timer;

   public LiquidFiller() {
      super(Categories.World, "liquid-filler", "Places blocks inside of liquid source blocks within range of you.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.placeInLiquids = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("place-in")).description("What type of liquids to place in.")).defaultValue(LiquidFiller.PlaceIn.Lava)).build());
      this.horizontalRadius = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("horizontal-radius")).description("Horizontal radius in which to search for liquids.")).defaultValue(4)).min(0).sliderMax(6).build());
      this.verticalRadius = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("vertical-radius")).description("Vertical radius in which to search for liquids.")).defaultValue(4)).min(0).sliderMax(6).build());
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("Delay between actions in ticks.")).defaultValue(1)).min(0).build());
      this.whitelist = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("block-whitelist")).description("The allowed blocks that it will use to fill up the liquid.")).defaultValue(class_2246.field_10566, class_2246.field_10445, class_2246.field_10340, class_2246.field_10515, class_2246.field_10508, class_2246.field_10474, class_2246.field_10115).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Automatically rotates towards the space targeted for filling.")).defaultValue(true)).build());
   }

   public void onActivate() {
      this.timer = 0;
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (this.timer < (Integer)this.delay.get()) {
         ++this.timer;
      } else {
         this.timer = 0;
         FindItemResult item = InvUtils.findInHotbar((itemStack) -> {
            return itemStack.method_7909() instanceof class_1747 && ((List)this.whitelist.get()).contains(class_2248.method_9503(itemStack.method_7909()));
         });
         if (item.found()) {
            BlockIterator.register((Integer)this.horizontalRadius.get(), (Integer)this.verticalRadius.get(), (blockPos, blockState) -> {
               if (this.isSource(blockState)) {
                  class_2248 liquid = blockState.method_26204();
                  LiquidFiller.PlaceIn placeIn = (LiquidFiller.PlaceIn)this.placeInLiquids.get();
                  if ((placeIn == LiquidFiller.PlaceIn.Both || placeIn == LiquidFiller.PlaceIn.Lava && liquid == class_2246.field_10164 || placeIn == LiquidFiller.PlaceIn.Water && liquid == class_2246.field_10382) && BlockUtils.place(blockPos, item, (Boolean)this.rotate.get(), 0, true)) {
                     BlockIterator.disableCurrent();
                  }
               }

            });
         }
      }
   }

   private boolean isSource(class_2680 blockState) {
      return blockState.method_26227().method_15761() == 8 && blockState.method_26227().method_15771();
   }

   public static enum PlaceIn {
      Lava,
      Water,
      Both;

      // $FF: synthetic method
      private static LiquidFiller.PlaceIn[] $values() {
         return new LiquidFiller.PlaceIn[]{Lava, Water, Both};
      }
   }
}
