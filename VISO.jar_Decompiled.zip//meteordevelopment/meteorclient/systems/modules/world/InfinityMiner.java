package meteordevelopment.meteorclient.systems.modules.world;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.Settings;
import baritone.api.pathing.goals.GoalBlock;
import java.util.List;
import java.util.function.Predicate;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2585;
import net.minecraft.class_2661;
import net.minecraft.class_2338.class_2339;

public class InfinityMiner extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgExtras;
   public final Setting<List<class_2248>> targetBlocks;
   public final Setting<List<class_2248>> repairBlocks;
   public final Setting<Double> durabilityThreshold;
   private final Setting<InfinityMiner.WhenFull> whenFull;
   public final Setting<Boolean> autoWalkHome;
   public final Setting<Boolean> autoLogOut;
   private final IBaritone baritone;
   private final Settings baritoneSettings;
   private final class_2339 homePos;
   private boolean repairing;

   public InfinityMiner() {
      super(Categories.World, "infinity-miner", "Allows you to essentially mine forever by mining repair blocks when the durability gets low. Needs a mending pickaxe.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgExtras = this.settings.createGroup("Extras");
      this.targetBlocks = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("target-blocks")).description("The target blocks to mine.")).defaultValue(class_2246.field_10442, class_2246.field_29029).filter(this::filter).build());
      this.repairBlocks = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("repair-blocks")).description("The repair blocks to mine.")).defaultValue(class_2246.field_10418, class_2246.field_10080, class_2246.field_10213).filter(this::filter).build());
      this.durabilityThreshold = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("durability-threshold")).description("The durability percentage at which to start repairing the tool.")).defaultValue(10.0D).range(1.0D, 99.0D).sliderRange(1.0D, 99.0D).build());
      this.whenFull = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("when-full")).description("The action to take when your inventory is full.")).defaultValue(InfinityMiner.WhenFull.Disconnect)).build());
      this.autoWalkHome = this.sgExtras.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("walk-home")).description("Will walk 'home' when your inventory is full.")).defaultValue(false)).build());
      this.autoLogOut = this.sgExtras.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("log-out")).description("Logs out when your inventory is full. Will walk home FIRST if walk home is enabled.")).defaultValue(false)).build());
      this.baritone = BaritoneAPI.getProvider().getPrimaryBaritone();
      this.baritoneSettings = BaritoneAPI.getSettings();
      this.homePos = new class_2339();
   }

   public void onActivate() {
      this.homePos.method_10101(this.mc.field_1724.method_24515());
   }

   public void onDeactivate() {
      this.baritone.getPathingBehavior().cancelEverything();
      this.baritoneSettings.mineScanDroppedItems.value = true;
   }

   @EventHandler
   private void onGameDisconnect(GameLeftEvent event) {
      this.baritone.getPathingBehavior().cancelEverything();
      this.toggle();
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (this.mc.field_1724.method_31548().method_7376() != -1) {
         if (!this.findBestPick()) {
            this.error("Could not find a usable mending pickaxe.", new Object[0]);
            this.toggle();
         } else {
            if (this.repairing) {
               if (!this.needsRepair()) {
                  this.warning("Finished repairing, going back to mining.", new Object[0]);
                  this.repairing = false;
                  this.baritone.getPathingBehavior().cancelEverything();
                  this.baritone.getMineProcess().mine(this.getTargetBlocks());
                  return;
               }

               if ((Boolean)this.baritoneSettings.mineScanDroppedItems.value) {
                  this.baritoneSettings.mineScanDroppedItems.value = false;
               }

               this.baritone.getMineProcess().mine(this.getRepairBlocks());
            } else {
               if (this.needsRepair()) {
                  this.warning("Pickaxe needs repair, beginning repair process", new Object[0]);
                  this.repairing = true;
                  this.baritone.getPathingBehavior().cancelEverything();
                  this.baritone.getMineProcess().mine(this.getRepairBlocks());
                  return;
               }

               if (!(Boolean)this.baritoneSettings.mineScanDroppedItems.value) {
                  this.baritoneSettings.mineScanDroppedItems.value = true;
               }

               this.baritone.getMineProcess().mine(this.getTargetBlocks());
            }

         }
      } else {
         switch((InfinityMiner.WhenFull)this.whenFull.get()) {
         case Disconnect:
            this.mc.field_1724.field_3944.method_2883(new class_2661(new class_2585("[Infinity Miner] Inventory is full.")));
            break;
         case Home:
            if (this.baritone.getPathingBehavior().isPathing() && this.baritone.getPathingBehavior().getGoal().isInGoal(this.homePos)) {
               if (this.mc.field_1724.method_24515().equals(this.homePos)) {
                  this.mc.field_1724.field_3944.method_2883(new class_2661(new class_2585("[Infinity Miner] Inventory is full.")));
               }
            } else {
               this.info("Walking home.", new Object[0]);
               this.baritone.getCustomGoalProcess().setGoalAndPath(new GoalBlock(this.homePos));
            }
         }

      }
   }

   private boolean findBestPick() {
      Predicate<class_1799> pickaxePredicate = (stack) -> {
         return stack.method_7909() instanceof class_1810 && Utils.hasEnchantments(stack, class_1893.field_9101) && !Utils.hasEnchantments(stack, class_1893.field_9099);
      };
      FindItemResult bestPick = InvUtils.findInHotbar(pickaxePredicate);
      if (bestPick.isOffhand()) {
         InvUtils.quickMove().fromOffhand().toHotbar(this.mc.field_1724.method_31548().field_7545);
      } else if (bestPick.isHotbar()) {
         InvUtils.swap(bestPick.slot(), false);
      }

      return InvUtils.findInHotbar(pickaxePredicate).isMainHand();
   }

   private class_2248[] getTargetBlocks() {
      class_2248[] array = new class_2248[((List)this.targetBlocks.get()).size()];
      return (class_2248[])((List)this.targetBlocks.get()).toArray(array);
   }

   private class_2248[] getRepairBlocks() {
      class_2248[] array = new class_2248[((List)this.repairBlocks.get()).size()];
      return (class_2248[])((List)this.repairBlocks.get()).toArray(array);
   }

   private boolean needsRepair() {
      class_1799 itemStack = this.mc.field_1724.method_6047();
      return (double)((float)(itemStack.method_7936() - itemStack.method_7919()) * 100.0F / (float)itemStack.method_7936()) <= (Double)this.durabilityThreshold.get();
   }

   private boolean filter(class_2248 block) {
      return block != class_2246.field_10124 && block.method_9564().method_26214(this.mc.field_1687, (class_2338)null) != -1.0F && !(block instanceof class_2404);
   }

   public static enum WhenFull {
      Home,
      Disconnect;

      // $FF: synthetic method
      private static InfinityMiner.WhenFull[] $values() {
         return new InfinityMiner.WhenFull[]{Home, Disconnect};
      }
   }

   public static enum Mode {
      Target,
      Repair;

      // $FF: synthetic method
      private static InfinityMiner.Mode[] $values() {
         return new InfinityMiner.Mode[]{Target, Repair};
      }
   }
}
