package meteordevelopment.meteorclient.systems.modules.world;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.mixin.BlockHitResultAccessor;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2350;
import net.minecraft.class_2885;

public class BuildHeight extends Module {
   public BuildHeight() {
      super(Categories.World, "build-height", "Allows you to interact with objects at the build limit.");
   }

   @EventHandler
   private void onSendPacket(PacketEvent.Send event) {
      if (event.packet instanceof class_2885) {
         class_2885 p = (class_2885)event.packet;
         if (p.method_12543().method_17784().field_1351 >= 255.0D && p.method_12543().method_17780() == class_2350.field_11036) {
            ((BlockHitResultAccessor)p.method_12543()).setSide(class_2350.field_11033);
         }

      }
   }
}
