package meteordevelopment.meteorclient.systems.modules.world;

import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;

public class AntiCactus extends Module {
   public AntiCactus() {
      super(Categories.World, "anti-cactus", "Prevents you from taking damage from cacti.");
   }
}
