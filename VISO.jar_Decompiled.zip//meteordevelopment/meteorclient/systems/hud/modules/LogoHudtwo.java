package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.renderer.GL;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.Utils;
import net.minecraft.class_2960;
import net.minecraft.class_4587;

public class LogoHudtwo extends HudElement {
   private final SettingGroup sgGeneral;
   private final Setting<Double> scale;
   private final class_2960 TEXTURE;

   public LogoHudtwo(HUD hud) {
      super(hud, "logotwo", "Shows the viso logo in the HUD.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale of the logo.")).defaultValue(3.0D).min(0.1D).sliderRange(0.1D, 10.0D).build());
      this.TEXTURE = new class_2960("meteor-client", "textures/viso.png");
   }

   public void update(HudRenderer renderer) {
      this.box.setSize(64.0D * (Double)this.scale.get(), 64.0D * (Double)this.scale.get());
   }

   public void render(HudRenderer renderer) {
      GL.bindTexture(this.TEXTURE);
      Renderer2D.TEXTURE.begin();
      Renderer2D.TEXTURE.texQuad(this.box.getX(), this.box.getY(), this.box.width, this.box.height, Utils.WHITE);
      Renderer2D.TEXTURE.render((class_4587)null);
   }
}
