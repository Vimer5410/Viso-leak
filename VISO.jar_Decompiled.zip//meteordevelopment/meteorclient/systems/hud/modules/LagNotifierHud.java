package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.world.TickRate;

public class LagNotifierHud extends DoubleTextHudElement {
   private static final Color RED = new Color(225, 45, 45);
   private static final Color AMBER = new Color(235, 158, 52);
   private static final Color YELLOW = new Color(255, 255, 5);

   public LagNotifierHud(HUD hud) {
      super(hud, "lag-notifier", "Displays if the server is lagging in ticks.", "Time since last tick ");
   }

   protected String getRight() {
      if (this.isInEditor()) {
         this.rightColor = RED;
         this.visible = true;
         return "4.3";
      } else {
         float timeSinceLastTick = TickRate.INSTANCE.getTimeSinceLastTick();
         if (timeSinceLastTick > 10.0F) {
            this.rightColor = RED;
         } else if (timeSinceLastTick > 3.0F) {
            this.rightColor = AMBER;
         } else {
            this.rightColor = YELLOW;
         }

         this.visible = timeSinceLastTick >= 1.0F;
         return String.format("%.1f", timeSinceLastTick);
      }
   }
}
