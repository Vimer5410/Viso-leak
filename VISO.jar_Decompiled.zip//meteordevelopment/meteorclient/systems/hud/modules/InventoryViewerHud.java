package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.renderer.GL;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_4587;

public class InventoryViewerHud extends HudElement {
   private static final class_2960 TEXTURE = new class_2960("meteor-client", "textures/container.png");
   private static final class_2960 TEXTURE_TRANSPARENT = new class_2960("meteor-client", "textures/container-transparent.png");
   private final SettingGroup sgGeneral;
   private final Setting<Double> scale;
   private final Setting<InventoryViewerHud.Background> background;
   private final Setting<SettingColor> color;
   private final class_1799[] editorInv;

   public InventoryViewerHud(HUD hud) {
      super(hud, "inventory-viewer", "Displays your inventory.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale.")).defaultValue(2.0D).min(1.0D).sliderRange(1.0D, 5.0D).build());
      this.background = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("background")).description("Background of inventory viewer.")).defaultValue(InventoryViewerHud.Background.Texture)).build());
      this.color = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("background-color")).description("Color of the background.")).defaultValue(new SettingColor(255, 255, 255))).visible(() -> {
         return this.background.get() != InventoryViewerHud.Background.None;
      })).build());
      this.editorInv = new class_1799[27];
      this.editorInv[0] = class_1802.field_8288.method_7854();
      this.editorInv[5] = new class_1799(class_1802.field_8367, 6);
      this.editorInv[19] = new class_1799(class_1802.field_8281, 64);
      this.editorInv[this.editorInv.length - 1] = class_1802.field_22025.method_7854();
   }

   public void update(HudRenderer renderer) {
      this.box.setSize((double)((InventoryViewerHud.Background)this.background.get()).width * (Double)this.scale.get(), (double)((InventoryViewerHud.Background)this.background.get()).height * (Double)this.scale.get());
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      if (this.background.get() != InventoryViewerHud.Background.None) {
         this.drawBackground((int)x, (int)y);
      }

      for(int row = 0; row < 3; ++row) {
         for(int i = 0; i < 9; ++i) {
            class_1799 stack = this.getStack(9 + row * 9 + i);
            if (stack != null) {
               int itemX = this.background.get() == InventoryViewerHud.Background.Texture ? (int)(x + (double)(8 + i * 18) * (Double)this.scale.get()) : (int)(x + (double)(1 + i * 18) * (Double)this.scale.get());
               int itemY = this.background.get() == InventoryViewerHud.Background.Texture ? (int)(y + (double)(7 + row * 18) * (Double)this.scale.get()) : (int)(y + (double)(1 + row * 18) * (Double)this.scale.get());
               RenderUtils.drawItem(stack, itemX, itemY, (Double)this.scale.get(), true);
            }
         }
      }

   }

   private class_1799 getStack(int i) {
      return this.isInEditor() ? this.editorInv[i - 9] : this.mc.field_1724.method_31548().method_5438(i);
   }

   private void drawBackground(int x, int y) {
      int w = (int)this.box.width;
      int h = (int)this.box.height;
      switch((InventoryViewerHud.Background)this.background.get()) {
      case Texture:
      case Outline:
         GL.bindTexture(this.background.get() == InventoryViewerHud.Background.Texture ? TEXTURE : TEXTURE_TRANSPARENT);
         Renderer2D.TEXTURE.begin();
         Renderer2D.TEXTURE.texQuad((double)x, (double)y, (double)w, (double)h, (Color)this.color.get());
         Renderer2D.TEXTURE.render((class_4587)null);
         break;
      case Flat:
         Renderer2D.COLOR.begin();
         Renderer2D.COLOR.quad((double)x, (double)y, (double)w, (double)h, (Color)this.color.get());
         Renderer2D.COLOR.render((class_4587)null);
      }

   }

   public static enum Background {
      None(162, 54),
      Texture(176, 67),
      Outline(162, 54),
      Flat(162, 54);

      private int width;
      private int height;

      private Background(int width, int height) {
         this.width = width;
         this.height = height;
      }

      // $FF: synthetic method
      private static InventoryViewerHud.Background[] $values() {
         return new InventoryViewerHud.Background[]{None, Texture, Outline, Flat};
      }
   }
}
