package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.utils.misc.HorizontalDirection;

public class RotationHud extends DoubleTextHudElement {
   public RotationHud(HUD hud) {
      super(hud, "rotation", "Displays your rotation.", "");
   }

   protected String getRight() {
      float yaw = this.mc.field_1773.method_19418().method_19330() % 360.0F;
      if (yaw < 0.0F) {
         yaw += 360.0F;
      }

      if (yaw > 180.0F) {
         yaw -= 360.0F;
      }

      float pitch = this.mc.field_1773.method_19418().method_19329() % 360.0F;
      if (pitch < 0.0F) {
         pitch += 360.0F;
      }

      if (pitch > 180.0F) {
         pitch -= 360.0F;
      }

      HorizontalDirection dir = HorizontalDirection.get(this.mc.field_1773.method_19418().method_19330());
      this.setLeft(String.format("%s %s ", dir.name, dir.axis));
      return String.format("(%.1f, %.1f)", yaw, pitch);
   }
}
