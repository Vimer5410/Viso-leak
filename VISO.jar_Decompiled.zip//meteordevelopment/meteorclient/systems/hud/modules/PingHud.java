package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.systems.hud.HUD;
import net.minecraft.class_640;

public class PingHud extends DoubleTextHudElement {
   public PingHud(HUD hud) {
      super(hud, "ping", "Displays your ping.", "Ping: ");
   }

   protected String getRight() {
      if (this.isInEditor()) {
         return "0";
      } else {
         class_640 playerListEntry = this.mc.method_1562().method_2871(this.mc.field_1724.method_5667());
         return playerListEntry != null ? Integer.toString(playerListEntry.method_2959()) : "0";
      }
   }
}
