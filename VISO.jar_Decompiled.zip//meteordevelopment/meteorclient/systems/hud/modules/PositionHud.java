package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.Freecam;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;

public class PositionHud extends HudElement {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> accurate;
   private final Setting<Boolean> oppositeDim;
   private final String left1;
   private double left1Width;
   private String right1;
   private String left2;
   private double left2Width;
   private String right2;

   public PositionHud(HUD hud) {
      super(hud, "coords", "Displays your coordinates in the world.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.accurate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("accurate")).description("Shows position with decimal points.")).defaultValue(false)).build());
      this.oppositeDim = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("opposite-dimension")).description("Displays the coords of the opposite dimension (Nether or Overworld).")).defaultValue(false)).build());
      this.left1 = "Pos: ";
   }

   public void update(HudRenderer renderer) {
      this.left1Width = renderer.textWidth("Pos: ");
      this.left2 = null;
      this.right2 = null;
      double height = renderer.textHeight();
      if ((Boolean)this.oppositeDim.get()) {
         height = height * 2.0D + 2.0D;
      }

      if (this.isInEditor()) {
         this.right1 = "0, 0, 0";
         this.box.setSize(this.left1Width + renderer.textWidth(this.right1), height);
      } else {
         Freecam freecam = (Freecam)Modules.get().get(Freecam.class);
         double x;
         double y;
         double z;
         if ((Boolean)this.accurate.get()) {
            x = freecam.isActive() ? this.mc.field_1773.method_19418().method_19326().field_1352 : this.mc.field_1724.method_23317();
            y = freecam.isActive() ? this.mc.field_1773.method_19418().method_19326().field_1351 - (double)this.mc.field_1724.method_18381(this.mc.field_1724.method_18376()) : this.mc.field_1724.method_23318();
            z = freecam.isActive() ? this.mc.field_1773.method_19418().method_19326().field_1350 : this.mc.field_1724.method_23321();
            this.right1 = String.format("%.1f %.1f %.1f", x, y, z);
         } else {
            x = freecam.isActive() ? (double)this.mc.field_1773.method_19418().method_19328().method_10263() : (double)this.mc.field_1724.method_31477();
            y = freecam.isActive() ? (double)this.mc.field_1773.method_19418().method_19328().method_10264() : (double)this.mc.field_1724.method_31478();
            z = freecam.isActive() ? (double)this.mc.field_1773.method_19418().method_19328().method_10260() : (double)this.mc.field_1724.method_31479();
            this.right1 = String.format("%d %d %d", (int)x, (int)y, (int)z);
         }

         if ((Boolean)this.oppositeDim.get()) {
            switch(PlayerUtils.getDimension()) {
            case Overworld:
               this.left2 = "Nether Pos: ";
               this.right2 = (Boolean)this.accurate.get() ? String.format("%.1f %.1f %.1f", x / 8.0D, y, z / 8.0D) : String.format("%d %d %d", (int)x / 8, (int)y, (int)z / 8);
               break;
            case Nether:
               this.left2 = "Overworld Pos: ";
               this.right2 = (Boolean)this.accurate.get() ? String.format("%.1f %.1f %.1f", x * 8.0D, y, z * 8.0D) : String.format("%d %d %d", (int)x * 8, (int)y, (int)z * 8);
            }
         }

         double width = this.left1Width + renderer.textWidth(this.right1);
         if (this.left2 != null) {
            this.left2Width = renderer.textWidth(this.left2);
            width = Math.max(width, this.left2Width + renderer.textWidth(this.right2));
         }

         this.box.setSize(width, height);
      }
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      double xOffset = this.box.alignX(this.left1Width + renderer.textWidth(this.right1));
      double yOffset = 0.0D;
      if (this.left2 != null) {
         renderer.text(this.left2, x, y, (Color)this.hud.primaryColor.get());
         renderer.text(this.right2, x + this.left2Width, y, (Color)this.hud.secondaryColor.get());
         yOffset = renderer.textHeight() + 2.0D;
      }

      renderer.text("Pos: ", x + xOffset, y + yOffset, (Color)this.hud.primaryColor.get());
      renderer.text(this.right1, x + xOffset + this.left1Width, y + yOffset, (Color)this.hud.secondaryColor.get());
   }
}
