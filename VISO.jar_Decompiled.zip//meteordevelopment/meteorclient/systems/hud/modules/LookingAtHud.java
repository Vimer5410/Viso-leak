package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.utils.misc.Names;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_3486;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_239.class_240;

public class LookingAtHud extends DoubleTextHudElement {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> position;
   private final Setting<Boolean> waterLogged;

   public LookingAtHud(HUD hud) {
      super(hud, "looking-at", "Displays what entity or block you are looking at.", "Looking At: ");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.position = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("position")).description("Displays crosshair target's position.")).defaultValue(true)).build());
      this.waterLogged = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("waterlogged-status")).description("Displays if a block is waterlogged or not")).defaultValue(true)).build());
   }

   protected String getRight() {
      if (this.isInEditor()) {
         return (Boolean)this.position.get() ? "Obsidian (0, 0, 0)" : "Obsidian";
      } else {
         String result;
         if (this.mc.field_1765.method_17783() == class_240.field_1332) {
            class_2338 pos = ((class_3965)this.mc.field_1765).method_17777();
            result = Names.get(this.mc.field_1687.method_8320(pos).method_26204());
            if ((Boolean)this.position.get()) {
               result = result + String.format(" (%d, %d, %d)", pos.method_10263(), pos.method_10264(), pos.method_10260());
            }

            if ((Boolean)this.waterLogged.get() && this.mc.field_1687.method_8316(pos).method_15767(class_3486.field_15517)) {
               result = result + " (water logged)";
            }

            return result;
         } else if (this.mc.field_1765.method_17783() == class_240.field_1331) {
            class_1297 target = ((class_3966)this.mc.field_1765).method_17782();
            if (target instanceof class_1657) {
               result = ((class_1657)target).method_7334().getName();
            } else {
               result = target.method_5477().getString();
            }

            if ((Boolean)this.position.get()) {
               result = result + String.format(" (%d, %d, %d)", target.method_31477(), target.method_31478(), target.method_31479());
            }

            if ((Boolean)this.waterLogged.get() && target.method_5799()) {
               result = result + " (in water)";
            }

            return result;
         } else {
            return "";
         }
      }
   }
}
