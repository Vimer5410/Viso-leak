package meteordevelopment.meteorclient.systems.hud.modules;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.utils.Utils;

public class TimeHud extends DoubleTextHudElement {
   private final SettingGroup sgGeneral;
   private final Setting<TimeHud.Type> timeType;

   public TimeHud(HUD hud) {
      super(hud, "time", "Displays the world time.", "Time: ");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.timeType = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("type")).description("Which time to use.")).defaultValue(TimeHud.Type.Game)).build());
   }

   protected String getRight() {
      String var10000;
      switch((TimeHud.Type)this.timeType.get()) {
      case Game:
         var10000 = this.isInEditor() ? "00:00" : Utils.getWorldTime();
         break;
      case Local:
         var10000 = LocalTime.now().format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT));
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   public static enum Type {
      Local,
      Game;

      // $FF: synthetic method
      private static TimeHud.Type[] $values() {
         return new TimeHud.Type[]{Local, Game};
      }
   }
}
