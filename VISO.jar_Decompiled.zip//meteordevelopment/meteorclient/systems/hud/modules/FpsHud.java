package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.mixin.MinecraftClientAccessor;
import meteordevelopment.meteorclient.systems.hud.HUD;

public class FpsHud extends DoubleTextHudElement {
   public FpsHud(HUD hud) {
      super(hud, "fps", "Displays your FPS.", "FPS: ");
   }

   protected String getRight() {
      return Integer.toString(MinecraftClientAccessor.getFps());
   }
}
