package meteordevelopment.meteorclient.systems.hud.modules;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_1657;
import net.minecraft.class_742;

public class TextRadarHud extends HudElement {
   private final SettingGroup sgGeneral;
   private final Setting<Integer> limit;
   private final Setting<Boolean> distance;
   private final Setting<Boolean> friends;
   private final List<class_742> players;

   public TextRadarHud(HUD hud) {
      super(hud, "player-info", "Displays players in your visual range.", false);
      this.sgGeneral = this.settings.getDefaultGroup();
      this.limit = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("limit")).description("The max number of players to show.")).defaultValue(10)).min(1).sliderRange(1, 20).build());
      this.distance = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("distance")).description("Shows the distance to the player next to their name.")).defaultValue(false)).build());
      this.friends = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("display-friends")).description("Whether to show friends or not.")).defaultValue(true)).build());
      this.players = new ArrayList();
   }

   public void update(HudRenderer renderer) {
      double width = renderer.textWidth("Players:");
      double height = renderer.textHeight();
      if (this.mc.field_1687 == null) {
         this.box.setSize(width, height);
      } else {
         Iterator var6 = this.getPlayers().iterator();

         while(true) {
            class_1657 entity;
            do {
               do {
                  if (!var6.hasNext()) {
                     this.box.setSize(width, height);
                     return;
                  }

                  entity = (class_1657)var6.next();
               } while(entity.equals(this.mc.field_1724));
            } while(!(Boolean)this.friends.get() && Friends.get().isFriend(entity));

            String text = entity.method_5820();
            if ((Boolean)this.distance.get()) {
               text = text + String.format("(%sm)", Math.round(this.mc.method_1560().method_5739(entity)));
            }

            width = Math.max(width, renderer.textWidth(text));
            height += renderer.textHeight() + 2.0D;
         }
      }
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      renderer.text("Players:", x, y, (Color)this.hud.secondaryColor.get());
      if (this.mc.field_1687 != null) {
         Iterator var6 = this.getPlayers().iterator();

         while(true) {
            class_1657 entity;
            do {
               do {
                  if (!var6.hasNext()) {
                     return;
                  }

                  entity = (class_1657)var6.next();
               } while(entity.equals(this.mc.field_1724));
            } while(!(Boolean)this.friends.get() && Friends.get().isFriend(entity));

            x = this.box.getX();
            y += renderer.textHeight() + 2.0D;
            String text = entity.method_5820();
            Color color = PlayerUtils.getPlayerColor(entity, (Color)this.hud.primaryColor.get());
            renderer.text(text, x, y, color);
            if ((Boolean)this.distance.get()) {
               x += renderer.textWidth(text + " ");
               text = String.format("(%sm)", Math.round(this.mc.method_1560().method_5739(entity)));
               color = (Color)this.hud.secondaryColor.get();
               renderer.text(text, x, y, color);
            }
         }
      }
   }

   private List<class_742> getPlayers() {
      this.players.clear();
      this.players.addAll(this.mc.field_1687.method_18456());
      if (this.players.size() > (Integer)this.limit.get()) {
         this.players.subList((Integer)this.limit.get() - 1, this.players.size() - 1).clear();
      }

      this.players.sort(Comparator.comparingDouble((e) -> {
         return (double)e.method_5739(this.mc.method_1560());
      }));
      return this.players;
   }
}
