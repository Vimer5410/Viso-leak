package meteordevelopment.meteorclient.systems.hud.modules;

import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.ModuleListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.AnchorAura;
import meteordevelopment.meteorclient.systems.modules.combat.BedAura;
import meteordevelopment.meteorclient.systems.modules.combat.CrystalAura;
import meteordevelopment.meteorclient.systems.modules.combat.KillAura;
import meteordevelopment.meteorclient.systems.modules.combat.Surround;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

public class ModuleInfoHud extends HudElement {
   private final SettingGroup sgGeneral;
   private final Setting<List<Module>> modules;
   private final Setting<Boolean> info;
   private final Setting<SettingColor> onColor;
   private final Setting<SettingColor> offColor;

   public ModuleInfoHud(HUD hud) {
      super(hud, "module-info", "Displays if selected modules are enabled or disabled.", false);
      this.sgGeneral = this.settings.getDefaultGroup();
      this.modules = this.sgGeneral.add(((ModuleListSetting.Builder)((ModuleListSetting.Builder)(new ModuleListSetting.Builder()).name("modules")).description("Which modules to display")).defaultValue(KillAura.class, CrystalAura.class, AnchorAura.class, BedAura.class, Surround.class).build());
      this.info = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("additional-info")).description("Shows additional info from the module next to the name in the module info list.")).defaultValue(true)).build());
      this.onColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("on-color")).description("Color when module is on.")).defaultValue(new SettingColor(25, 225, 25))).build());
      this.offColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("off-color")).description("Color when module is off.")).defaultValue(new SettingColor(225, 25, 25))).build());
   }

   public void update(HudRenderer renderer) {
      if (Modules.get() != null && !((List)this.modules.get()).isEmpty()) {
         double width = 0.0D;
         double height = 0.0D;
         int i = 0;

         for(Iterator var7 = ((List)this.modules.get()).iterator(); var7.hasNext(); ++i) {
            Module module = (Module)var7.next();
            width = Math.max(width, this.getModuleWidth(renderer, module));
            height += renderer.textHeight();
            if (i > 0) {
               height += 2.0D;
            }
         }

         this.box.setSize(width, height);
      } else {
         this.box.setSize(renderer.textWidth("Module Info"), renderer.textHeight());
      }
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      if (Modules.get() != null && !((List)this.modules.get()).isEmpty()) {
         for(Iterator var6 = ((List)this.modules.get()).iterator(); var6.hasNext(); y += 2.0D + renderer.textHeight()) {
            Module module = (Module)var6.next();
            this.renderModule(renderer, module, x + this.box.alignX(this.getModuleWidth(renderer, module)), y);
         }

      } else {
         renderer.text("Module Info", x, y, (Color)this.hud.primaryColor.get());
      }
   }

   private void renderModule(HudRenderer renderer, Module module, double x, double y) {
      renderer.text(module.title, x, y, (Color)this.hud.primaryColor.get());
      String info = this.getModuleInfo(module);
      renderer.text(info, x + renderer.textWidth(module.title) + renderer.textWidth(" "), y, module.isActive() ? (Color)this.onColor.get() : (Color)this.offColor.get());
   }

   private double getModuleWidth(HudRenderer renderer, Module module) {
      double width = renderer.textWidth(module.title);
      if ((Boolean)this.info.get()) {
         width += renderer.textWidth(" ") + renderer.textWidth(this.getModuleInfo(module));
      }

      return width;
   }

   private String getModuleInfo(Module module) {
      if (module.getInfoString() != null && module.isActive() && (Boolean)this.info.get()) {
         return module.getInfoString();
      } else {
         return module.isActive() ? "ON" : "OFF";
      }
   }
}
