package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.render.color.Color;

public abstract class DoubleTextHudElement extends HudElement {
   protected Color rightColor;
   protected boolean visible = true;
   private String left;
   private String right;
   private double leftWidth;

   public DoubleTextHudElement(HUD hud, String name, String description, String left, boolean defaultActive) {
      super(hud, name, description, defaultActive);
      this.rightColor = (Color)hud.secondaryColor.get();
      this.left = left;
   }

   public DoubleTextHudElement(HUD hud, String name, String description, String left) {
      super(hud, name, description, true);
      this.rightColor = (Color)hud.secondaryColor.get();
      this.left = left;
   }

   public void update(HudRenderer renderer) {
      this.right = this.getRight();
      this.leftWidth = renderer.textWidth(this.left);
      this.box.setSize(this.leftWidth + renderer.textWidth(this.right), renderer.textHeight());
   }

   public void render(HudRenderer renderer) {
      if (this.visible) {
         double x = this.box.getX();
         double y = this.box.getY();
         renderer.text(this.left, x, y, (Color)this.hud.primaryColor.get());
         renderer.text(this.right, x + this.leftWidth, y, this.rightColor);
      }
   }

   protected void setLeft(String left) {
      this.left = left;
      this.leftWidth = 0.0D;
   }

   protected abstract String getRight();
}
