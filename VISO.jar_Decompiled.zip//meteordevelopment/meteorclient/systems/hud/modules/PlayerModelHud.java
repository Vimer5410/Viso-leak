package meteordevelopment.meteorclient.systems.hud.modules;

import java.util.Objects;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.misc.FakeClientPlayer;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_490;

public class PlayerModelHud extends HudElement {
   private final SettingGroup sgGeneral;
   private final Setting<Double> scale;
   private final Setting<Boolean> copyYaw;
   private final Setting<Boolean> copyPitch;
   private final Setting<Integer> customYaw;
   private final Setting<Integer> customPitch;
   private final Setting<Boolean> background;
   private final Setting<SettingColor> backgroundColor;

   public PlayerModelHud(HUD hud) {
      super(hud, "player-model", "Displays a model of your player.", false);
      this.sgGeneral = this.settings.getDefaultGroup();
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale.")).defaultValue(2.0D).min(1.0D).sliderRange(1.0D, 5.0D).build());
      this.copyYaw = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("copy-yaw")).description("Makes the player model's yaw equal to yours.")).defaultValue(true)).build());
      this.copyPitch = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("copy-pitch")).description("Makes the player model's pitch equal to yours.")).defaultValue(true)).build());
      this.customYaw = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("custom-yaw")).description("Custom yaw for when copy yaw is off.")).defaultValue(0)).range(-180, 180).sliderRange(-180, 180).visible(() -> {
         return !(Boolean)this.copyYaw.get();
      })).build());
      this.customPitch = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("custom-pitch")).description("Custom pitch for when copy pitch is off.")).defaultValue(0)).range(-90, 90).sliderRange(-90, 90).visible(() -> {
         return !(Boolean)this.copyPitch.get();
      })).build());
      this.background = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("background")).description("Displays a background behind the player model.")).defaultValue(true)).build());
      SettingGroup var10001 = this.sgGeneral;
      ColorSetting.Builder var10002 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("background-color")).description("Color of background.")).defaultValue(new SettingColor(0, 0, 0, 64));
      Setting var10003 = this.background;
      Objects.requireNonNull(var10003);
      this.backgroundColor = var10001.add(((ColorSetting.Builder)var10002.visible(var10003::get)).build());
   }

   public void update(HudRenderer renderer) {
      this.box.setSize(50.0D * (Double)this.scale.get(), 75.0D * (Double)this.scale.get());
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      if ((Boolean)this.background.get()) {
         Renderer2D.COLOR.begin();
         Renderer2D.COLOR.quad(x, y, this.box.width, this.box.height, (Color)this.backgroundColor.get());
         Renderer2D.COLOR.render((class_4587)null);
      }

      class_1657 player = this.mc.field_1724;
      if (this.isInEditor()) {
         player = FakeClientPlayer.getPlayer();
      }

      float yaw = (Boolean)this.copyYaw.get() ? class_3532.method_15393(((class_1657)player).field_5982 + (((class_1657)player).method_36454() - ((class_1657)player).field_5982) * this.mc.method_1488()) : (float)(Integer)this.customYaw.get();
      float pitch = (Boolean)this.copyPitch.get() ? ((class_1657)player).method_36455() : (float)(Integer)this.customPitch.get();
      class_490.method_2486((int)(x + 25.0D * (Double)this.scale.get()), (int)(y + 66.0D * (Double)this.scale.get()), (int)(30.0D * (Double)this.scale.get()), -yaw, -pitch, (class_1309)player);
   }
}
