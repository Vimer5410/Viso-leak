package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.NameProtect;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

public class WelcomeHud extends DoubleTextHudElement {
   private final SettingGroup sgGeneral;
   private final Setting<SettingColor> color;

   public WelcomeHud(HUD hud) {
      super(hud, "welcome", "Displays a welcome message.", "hello sweet, ");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.color = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("color")).description("Color of welcome text.")).defaultValue(new SettingColor(120, 43, 153))).build());
      this.rightColor = (Color)this.color.get();
   }

   protected String getRight() {
      return ((NameProtect)Modules.get().get(NameProtect.class)).getName(this.mc.method_1548().method_1676()) + "!";
   }
}
