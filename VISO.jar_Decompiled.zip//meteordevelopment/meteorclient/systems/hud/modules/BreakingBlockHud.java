package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.mixin.ClientPlayerInteractionManagerAccessor;
import meteordevelopment.meteorclient.systems.hud.HUD;

public class BreakingBlockHud extends DoubleTextHudElement {
   public BreakingBlockHud(HUD hud) {
      super(hud, "breaking-block", "Displays percentage of the block you are breaking.", "Breaking Block: ");
   }

   protected String getRight() {
      return this.isInEditor() ? "0%" : String.format("%.0f%%", ((ClientPlayerInteractionManagerAccessor)this.mc.field_1761).getBreakingProgress() * 100.0F);
   }
}
