package meteordevelopment.meteorclient.systems.hud.modules;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnchantmentListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.misc.FakeClientPlayer;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_1657;
import net.minecraft.class_1748;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2378;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_490;

public class CombatHud extends HudElement {
   private static final Color GREEN = new Color(15, 255, 15);
   private static final Color RED = new Color(255, 15, 15);
   private static final Color BLACK = new Color(0, 0, 0, 255);
   private final SettingGroup sgGeneral;
   private final Setting<Double> scale;
   private final Setting<Double> range;
   private final Setting<Boolean> displayPing;
   private final Setting<Boolean> displayDistance;
   private final Setting<List<class_1887>> displayedEnchantments;
   private final Setting<SettingColor> backgroundColor;
   private final Setting<SettingColor> enchantmentTextColor;
   private final Setting<SettingColor> pingColor1;
   private final Setting<SettingColor> pingColor2;
   private final Setting<SettingColor> pingColor3;
   private final Setting<SettingColor> distColor1;
   private final Setting<SettingColor> distColor2;
   private final Setting<SettingColor> distColor3;
   private final Setting<SettingColor> healthColor1;
   private final Setting<SettingColor> healthColor2;
   private final Setting<SettingColor> healthColor3;
   private class_1657 playerEntity;

   public CombatHud(HUD hud) {
      super(hud, "combat-info", "Displays information about your combat target.", false);
      this.sgGeneral = this.settings.getDefaultGroup();
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale.")).defaultValue(2.0D).min(1.0D).sliderRange(1.0D, 5.0D).build());
      this.range = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("range")).description("The range to target players.")).defaultValue(100.0D).min(1.0D).sliderMax(200.0D).build());
      this.displayPing = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ping")).description("Shows the player's ping.")).defaultValue(true)).build());
      this.displayDistance = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("distance")).description("Shows the distance between you and the player.")).defaultValue(true)).build());
      this.displayedEnchantments = this.sgGeneral.add(((EnchantmentListSetting.Builder)((EnchantmentListSetting.Builder)((EnchantmentListSetting.Builder)(new EnchantmentListSetting.Builder()).name("displayed-enchantments")).description("The enchantments that are shown on nametags.")).defaultValue(getDefaultEnchantments())).build());
      this.backgroundColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("background-color")).description("Color of background.")).defaultValue(new SettingColor(0, 0, 0, 64))).build());
      this.enchantmentTextColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("enchantment-color")).description("Color of enchantment text.")).defaultValue(new SettingColor(255, 255, 255))).build());
      SettingGroup var10001 = this.sgGeneral;
      ColorSetting.Builder var10002 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("ping-stage-1")).description("Color of ping text when under 75.")).defaultValue(new SettingColor(15, 255, 15));
      Setting var10003 = this.displayPing;
      Objects.requireNonNull(var10003);
      this.pingColor1 = var10001.add(((ColorSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgGeneral;
      var10002 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("ping-stage-2")).description("Color of ping text when between 75 and 200.")).defaultValue(new SettingColor(255, 150, 15));
      var10003 = this.displayPing;
      Objects.requireNonNull(var10003);
      this.pingColor2 = var10001.add(((ColorSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgGeneral;
      var10002 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("ping-stage-3")).description("Color of ping text when over 200.")).defaultValue(new SettingColor(255, 15, 15));
      var10003 = this.displayPing;
      Objects.requireNonNull(var10003);
      this.pingColor3 = var10001.add(((ColorSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgGeneral;
      var10002 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("distance-stage-1")).description("The color when a player is within 10 blocks of you.")).defaultValue(new SettingColor(255, 15, 15));
      var10003 = this.displayDistance;
      Objects.requireNonNull(var10003);
      this.distColor1 = var10001.add(((ColorSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgGeneral;
      var10002 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("distance-stage-2")).description("The color when a player is within 50 blocks of you.")).defaultValue(new SettingColor(255, 150, 15));
      var10003 = this.displayDistance;
      Objects.requireNonNull(var10003);
      this.distColor2 = var10001.add(((ColorSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgGeneral;
      var10002 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("distance-stage-3")).description("The color when a player is greater then 50 blocks away from you.")).defaultValue(new SettingColor(15, 255, 15));
      var10003 = this.displayDistance;
      Objects.requireNonNull(var10003);
      this.distColor3 = var10001.add(((ColorSetting.Builder)var10002.visible(var10003::get)).build());
      this.healthColor1 = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("health-stage-1")).description("The color on the left of the health gradient.")).defaultValue(new SettingColor(255, 15, 15))).build());
      this.healthColor2 = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("health-stage-2")).description("The color in the middle of the health gradient.")).defaultValue(new SettingColor(255, 150, 15))).build());
      this.healthColor3 = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("health-stage-3")).description("The color on the right of the health gradient.")).defaultValue(new SettingColor(15, 255, 15))).build());
   }

   public void update(HudRenderer renderer) {
      this.box.setSize(175.0D * (Double)this.scale.get(), 95.0D * (Double)this.scale.get());
   }

   public void render(HudRenderer renderer) {
      renderer.addPostTask(() -> {
         double x = this.box.getX();
         double y = this.box.getY();
         if (this.isInEditor()) {
            this.playerEntity = FakeClientPlayer.getPlayer();
         } else {
            this.playerEntity = TargetUtils.getPlayerTarget((Double)this.range.get(), SortPriority.LowestDistance);
         }

         if (this.playerEntity != null) {
            Renderer2D.COLOR.begin();
            Renderer2D.COLOR.quad(x, y, this.box.width, this.box.height, (Color)this.backgroundColor.get());
            Renderer2D.COLOR.render((class_4587)null);
            class_490.method_2486((int)(x + 25.0D * (Double)this.scale.get()), (int)(y + 66.0D * (Double)this.scale.get()), (int)(30.0D * (Double)this.scale.get()), -class_3532.method_15393(this.playerEntity.field_5982 + (this.playerEntity.method_36454() - this.playerEntity.field_5982) * this.mc.method_1488()), -this.playerEntity.method_36455(), this.playerEntity);
            x += 50.0D * (Double)this.scale.get();
            y += 5.0D * (Double)this.scale.get();
            String breakText = " | ";
            String nameText = this.playerEntity.method_5820();
            Color nameColor = PlayerUtils.getPlayerColor(this.playerEntity, (Color)this.hud.primaryColor.get());
            int ping = EntityUtils.getPing(this.playerEntity);
            String pingText = ping + "ms";
            Color pingColor;
            if (ping <= 75) {
               pingColor = (Color)this.pingColor1.get();
            } else if (ping <= 200) {
               pingColor = (Color)this.pingColor2.get();
            } else {
               pingColor = (Color)this.pingColor3.get();
            }

            double dist = 0.0D;
            if (!this.isInEditor()) {
               dist = (double)Math.round((double)this.mc.field_1724.method_5739(this.playerEntity) * 100.0D) / 100.0D;
            }

            String distText = dist + "m";
            Color distColor;
            if (dist <= 10.0D) {
               distColor = (Color)this.distColor1.get();
            } else if (dist <= 50.0D) {
               distColor = (Color)this.distColor2.get();
            } else {
               distColor = (Color)this.distColor3.get();
            }

            String friendText = "Unknown";
            Color friendColor = (Color)this.hud.primaryColor.get();
            if (Friends.get().isFriend(this.playerEntity)) {
               friendText = "Friend";
               friendColor = Friends.get().color;
            } else {
               boolean naked = true;

               for(int positionxx = 3; positionxx >= 0; --positionxx) {
                  class_1799 itemStackx = this.getItem(positionxx);
                  if (!itemStackx.method_7960()) {
                     naked = false;
                  }
               }

               if (naked) {
                  friendText = "Naked";
                  friendColor = GREEN;
               } else {
                  boolean threat = false;

                  for(int position = 5; position >= 0; --position) {
                     class_1799 itemStackxx = this.getItem(position);
                     if (itemStackxx.method_7909() instanceof class_1829 || itemStackxx.method_7909() == class_1802.field_8301 || itemStackxx.method_7909() == class_1802.field_23141 || itemStackxx.method_7909() instanceof class_1748) {
                        threat = true;
                     }
                  }

                  if (threat) {
                     friendText = "Threat";
                     friendColor = RED;
                  }
               }
            }

            TextRenderer.get().begin(0.45D * (Double)this.scale.get(), false, true);
            double breakWidth = TextRenderer.get().getWidth(breakText);
            double pingWidth = TextRenderer.get().getWidth(pingText);
            double friendWidth = TextRenderer.get().getWidth(friendText);
            TextRenderer.get().render(nameText, x, y, nameColor != null ? nameColor : (Color)this.hud.primaryColor.get());
            y += TextRenderer.get().getHeight();
            TextRenderer.get().render(friendText, x, y, (Color)friendColor);
            if ((Boolean)this.displayPing.get()) {
               TextRenderer.get().render(breakText, x + friendWidth, y, (Color)this.hud.secondaryColor.get());
               TextRenderer.get().render(pingText, x + friendWidth + breakWidth, y, pingColor);
               if ((Boolean)this.displayDistance.get()) {
                  TextRenderer.get().render(breakText, x + friendWidth + breakWidth + pingWidth, y, (Color)this.hud.secondaryColor.get());
                  TextRenderer.get().render(distText, x + friendWidth + breakWidth + pingWidth + breakWidth, y, distColor);
               }
            } else if ((Boolean)this.displayDistance.get()) {
               TextRenderer.get().render(breakText, x + friendWidth, y, (Color)this.hud.secondaryColor.get());
               TextRenderer.get().render(distText, x + friendWidth + breakWidth, y, distColor);
            }

            TextRenderer.get().end();
            y += 10.0D * (Double)this.scale.get();
            int slot = 5;
            class_4587 matrices = RenderSystem.getModelViewStack();
            matrices.method_22903();
            matrices.method_22905(((Double)this.scale.get()).floatValue(), ((Double)this.scale.get()).floatValue(), 1.0F);
            x /= (Double)this.scale.get();
            y /= (Double)this.scale.get();
            TextRenderer.get().begin(0.35D, false, true);

            double enchX;
            for(int positionx = 0; positionx < 6; ++positionx) {
               double armorX = x + (double)(positionx * 20);
               class_1799 itemStack = this.getItem(slot);
               RenderUtils.drawItem(itemStack, (int)armorX, (int)y, true);
               double armorY = y + 18.0D;
               Map<class_1887, Integer> enchantments = class_1890.method_8222(itemStack);
               Map<class_1887, Integer> enchantmentsToShow = new HashMap();
               Iterator var33 = ((List)this.displayedEnchantments.get()).iterator();

               class_1887 enchantment;
               while(var33.hasNext()) {
                  enchantment = (class_1887)var33.next();
                  if (enchantments.containsKey(enchantment)) {
                     enchantmentsToShow.put(enchantment, (Integer)enchantments.get(enchantment));
                  }
               }

               for(var33 = enchantmentsToShow.keySet().iterator(); var33.hasNext(); armorY += TextRenderer.get().getHeight()) {
                  enchantment = (class_1887)var33.next();
                  String var10000 = Utils.getEnchantSimpleName(enchantment, 3);
                  String enchantName = var10000 + " " + enchantmentsToShow.get(enchantment);
                  enchX = armorX + 8.0D - TextRenderer.get().getWidth(enchantName) / 2.0D;
                  TextRenderer.get().render(enchantName, enchX, armorY, enchantment.method_8195() ? RED : (Color)this.enchantmentTextColor.get());
               }

               --slot;
            }

            TextRenderer.get().end();
            y = (double)((int)(this.box.getY() + 75.0D * (Double)this.scale.get()));
            x = this.box.getX();
            x /= (Double)this.scale.get();
            y /= (Double)this.scale.get();
            x += 5.0D;
            y += 5.0D;
            Renderer2D.COLOR.begin();
            Renderer2D.COLOR.boxLines(x, y, 165.0D, 11.0D, BLACK);
            Renderer2D.COLOR.render((class_4587)null);
            x += 2.0D;
            y += 2.0D;
            float maxHealth = this.playerEntity.method_6063();
            int maxAbsorb = 16;
            int maxTotal = (int)(maxHealth + (float)maxAbsorb);
            int totalHealthWidth = (int)(161.0F * maxHealth / (float)maxTotal);
            int totalAbsorbWidth = 161 * maxAbsorb / maxTotal;
            float health = this.playerEntity.method_6032();
            float absorb = this.playerEntity.method_6067();
            enchX = (double)(health / maxHealth);
            double absorbPercent = (double)(absorb / (float)maxAbsorb);
            int healthWidth = (int)((double)totalHealthWidth * enchX);
            int absorbWidth = (int)((double)totalAbsorbWidth * absorbPercent);
            Renderer2D.COLOR.begin();
            Renderer2D.COLOR.quad(x, y, (double)healthWidth, 7.0D, (Color)this.healthColor1.get(), (Color)this.healthColor2.get(), (Color)this.healthColor2.get(), (Color)this.healthColor1.get());
            Renderer2D.COLOR.quad(x + (double)healthWidth, y, (double)absorbWidth, 7.0D, (Color)this.healthColor2.get(), (Color)this.healthColor3.get(), (Color)this.healthColor3.get(), (Color)this.healthColor2.get());
            Renderer2D.COLOR.render((class_4587)null);
            matrices.method_22909();
         }
      });
   }

   private class_1799 getItem(int i) {
      class_1799 var10000;
      if (this.isInEditor()) {
         switch(i) {
         case 0:
            var10000 = class_1802.field_8301.method_7854();
            break;
         case 1:
            var10000 = class_1802.field_22030.method_7854();
            break;
         case 2:
            var10000 = class_1802.field_22029.method_7854();
            break;
         case 3:
            var10000 = class_1802.field_22028.method_7854();
            break;
         case 4:
            var10000 = class_1802.field_22027.method_7854();
            break;
         case 5:
            var10000 = class_1802.field_8288.method_7854();
            break;
         default:
            var10000 = class_1799.field_8037;
         }

         return var10000;
      } else if (this.playerEntity == null) {
         return class_1799.field_8037;
      } else {
         switch(i) {
         case 4:
            var10000 = this.playerEntity.method_6079();
            break;
         case 5:
            var10000 = this.playerEntity.method_6047();
            break;
         default:
            var10000 = this.playerEntity.method_31548().method_7372(i);
         }

         return var10000;
      }
   }

   public static List<class_1887> getDefaultEnchantments() {
      List<class_1887> enchantments = new ArrayList();
      Iterator var1 = class_2378.field_11160.iterator();

      while(var1.hasNext()) {
         class_1887 enchantment = (class_1887)var1.next();
         enchantments.add(enchantment);
      }

      return enchantments;
   }
}
