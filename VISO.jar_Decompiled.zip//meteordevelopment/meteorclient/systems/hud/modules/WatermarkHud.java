package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.hud.HUD;

public class WatermarkHud extends DoubleTextHudElement {
   public WatermarkHud(HUD hud) {
      super(hud, "watermark", "Displays a Meteor Client watermark.", "Meteor Client ");
   }

   protected String getRight() {
      return MeteorClient.DEV_BUILD.isEmpty() ? MeteorClient.VERSION.toString() : MeteorClient.VERSION + " " + MeteorClient.DEV_BUILD;
   }
}
