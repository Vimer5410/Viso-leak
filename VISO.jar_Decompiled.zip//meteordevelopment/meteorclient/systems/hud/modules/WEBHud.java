package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class WEBHud extends HudElement {
   private final SettingGroup sgGeneral;
   private final Setting<Double> scale;

   public WEBHud(HUD hud) {
      super(hud, "web", "Displays the amount of web in your inventory.", false);
      this.sgGeneral = this.settings.getDefaultGroup();
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale.")).defaultValue(2.0D).min(1.0D).sliderRange(1.0D, 5.0D).build());
   }

   public void update(HudRenderer renderer) {
      this.box.setSize(16.0D * (Double)this.scale.get(), 16.0D * (Double)this.scale.get());
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      if (this.isInEditor()) {
         RenderUtils.drawItem(class_1802.field_8786.method_7854(), (int)x, (int)y, (Double)this.scale.get(), true);
      } else if (InvUtils.find(class_1802.field_8786).count() > 0) {
         RenderUtils.drawItem(new class_1799(class_1802.field_8786, InvUtils.find(class_1802.field_8786).count()), (int)x, (int)y, (Double)this.scale.get(), true);
      }

   }
}
