package meteordevelopment.meteorclient.systems.hud.modules;

import com.mojang.blaze3d.systems.RenderSystem;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_4587;

public class ArmorHud extends HudElement {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> flipOrder;
   private final Setting<ArmorHud.Orientation> orientation;
   private final Setting<ArmorHud.Durability> durability;
   private final Setting<Double> scale;

   public ArmorHud(HUD hud) {
      super(hud, "armor", "Displays information about your armor.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.flipOrder = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("flip-order")).description("Flips the order of armor items.")).defaultValue(true)).build());
      this.orientation = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("orientation")).description("How to display armor.")).defaultValue(ArmorHud.Orientation.Horizontal)).build());
      this.durability = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("durability")).description("How to display armor durability.")).defaultValue(ArmorHud.Durability.Bar)).build());
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale.")).defaultValue(2.0D).min(1.0D).sliderRange(1.0D, 5.0D).build());
   }

   public void update(HudRenderer renderer) {
      switch((ArmorHud.Orientation)this.orientation.get()) {
      case Horizontal:
         this.box.setSize(16.0D * (Double)this.scale.get() * 4.0D + 8.0D, 16.0D * (Double)this.scale.get());
         break;
      case Vertical:
         this.box.setSize(16.0D * (Double)this.scale.get(), 16.0D * (Double)this.scale.get() * 4.0D + 8.0D);
      }

   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      class_4587 matrices = RenderSystem.getModelViewStack();
      matrices.method_22903();
      matrices.method_22905(((Double)this.scale.get()).floatValue(), ((Double)this.scale.get()).floatValue(), 1.0F);
      int slot = (Boolean)this.flipOrder.get() ? 3 : 0;

      for(int position = 0; position < 4; ++position) {
         class_1799 itemStack = this.getItem(slot);
         double armorX;
         double armorY;
         if (this.orientation.get() == ArmorHud.Orientation.Vertical) {
            armorX = x / (Double)this.scale.get();
            armorY = y / (Double)this.scale.get() + (double)(position * 18);
         } else {
            armorX = x / (Double)this.scale.get() + (double)(position * 18);
            armorY = y / (Double)this.scale.get();
         }

         RenderUtils.drawItem(itemStack, (int)armorX, (int)armorY, itemStack.method_7963() && this.durability.get() == ArmorHud.Durability.Bar);
         if (itemStack.method_7963() && !this.isInEditor() && this.durability.get() != ArmorHud.Durability.Bar && this.durability.get() != ArmorHud.Durability.None) {
            String var10000;
            switch((ArmorHud.Durability)this.durability.get()) {
            case Total:
               var10000 = Integer.toString(itemStack.method_7936() - itemStack.method_7919());
               break;
            case Percentage:
               var10000 = Integer.toString(Math.round((float)(itemStack.method_7936() - itemStack.method_7919()) * 100.0F / (float)itemStack.method_7936()));
               break;
            default:
               var10000 = "err";
            }

            String message = var10000;
            double messageWidth = renderer.textWidth(message);
            if (this.orientation.get() == ArmorHud.Orientation.Vertical) {
               armorX = x + 8.0D * (Double)this.scale.get() - messageWidth / 2.0D;
               armorY = y + (double)(18 * position) * (Double)this.scale.get() + (18.0D * (Double)this.scale.get() - renderer.textHeight());
            } else {
               armorX = x + (double)(18 * position) * (Double)this.scale.get() + 8.0D * (Double)this.scale.get() - messageWidth / 2.0D;
               armorY = y + (this.box.height - renderer.textHeight());
            }

            renderer.text(message, armorX, armorY, (Color)this.hud.primaryColor.get());
         }

         if ((Boolean)this.flipOrder.get()) {
            --slot;
         } else {
            ++slot;
         }
      }

      matrices.method_22909();
   }

   private class_1799 getItem(int i) {
      if (this.isInEditor()) {
         class_1799 var10000;
         switch(i) {
         case 1:
            var10000 = class_1802.field_22029.method_7854();
            break;
         default:
            var10000 = class_1802.field_22030.method_7854();
         }

         return var10000;
      } else {
         return this.mc.field_1724.method_31548().method_7372(i);
      }
   }

   public static enum Orientation {
      Horizontal,
      Vertical;

      // $FF: synthetic method
      private static ArmorHud.Orientation[] $values() {
         return new ArmorHud.Orientation[]{Horizontal, Vertical};
      }
   }

   public static enum Durability {
      None,
      Bar,
      Total,
      Percentage;

      // $FF: synthetic method
      private static ArmorHud.Durability[] $values() {
         return new ArmorHud.Durability[]{None, Bar, Total, Percentage};
      }
   }
}
