package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.systems.hud.HUD;

public class DurabilityHud extends DoubleTextHudElement {
   public DurabilityHud(HUD hud) {
      super(hud, "durability", "Displays durability of the item you are holding.", "Durability: ");
   }

   protected String getRight() {
      if (this.isInEditor()) {
         return "159";
      } else {
         return !this.mc.field_1724.method_6047().method_7960() && this.mc.field_1724.method_6047().method_7963() ? String.valueOf(this.mc.field_1724.method_6047().method_7936() - this.mc.field_1724.method_6047().method_7919()) : "";
      }
   }
}
