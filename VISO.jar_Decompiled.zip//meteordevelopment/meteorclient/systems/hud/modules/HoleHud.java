package meteordevelopment.meteorclient.systems.hud.modules;

import java.util.List;
import meteordevelopment.meteorclient.mixin.WorldRendererAccessor;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class HoleHud extends HudElement {
   private final SettingGroup sgGeneral;
   public final Setting<List<class_2248>> safe;
   private final Setting<Double> scale;
   private final Color BG_COLOR;
   private final Color OL_COLOR;

   public HoleHud(HUD hud) {
      super(hud, "hole", "Displays information about the hole you are standing in.", false);
      this.sgGeneral = this.settings.getDefaultGroup();
      this.safe = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("safe-blocks")).description("Which blocks to consider safe.")).defaultValue(class_2246.field_10540, class_2246.field_9987, class_2246.field_22423, class_2246.field_22108).build());
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale.")).defaultValue(2.0D).min(1.0D).sliderRange(1.0D, 5.0D).build());
      this.BG_COLOR = new Color(255, 25, 25, 100);
      this.OL_COLOR = new Color(255, 25, 25, 255);
   }

   public void update(HudRenderer renderer) {
      this.box.setSize(48.0D * (Double)this.scale.get(), 48.0D * (Double)this.scale.get());
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      Renderer2D.COLOR.begin();
      this.drawBlock(this.get(HoleHud.Facing.Left), x, y + 16.0D * (Double)this.scale.get());
      this.drawBlock(this.get(HoleHud.Facing.Front), x + 16.0D * (Double)this.scale.get(), y);
      this.drawBlock(this.get(HoleHud.Facing.Right), x + 32.0D * (Double)this.scale.get(), y + 16.0D * (Double)this.scale.get());
      this.drawBlock(this.get(HoleHud.Facing.Back), x + 16.0D * (Double)this.scale.get(), y + 32.0D * (Double)this.scale.get());
      Renderer2D.COLOR.render((class_4587)null);
   }

   private class_2350 get(HoleHud.Facing dir) {
      return Utils.canUpdate() && !this.isInEditor() ? class_2350.method_10150((double)class_3532.method_15393(this.mc.field_1724.method_36454() + (float)dir.offset)) : class_2350.field_11033;
   }

   private void drawBlock(class_2350 dir, double x, double y) {
      class_2248 block = dir == class_2350.field_11033 ? class_2246.field_10540 : this.mc.field_1687.method_8320(this.mc.field_1724.method_24515().method_10093(dir)).method_26204();
      if (((List)this.safe.get()).contains(block)) {
         RenderUtils.drawItem(block.method_8389().method_7854(), (int)x, (int)y, (Double)this.scale.get(), false);
         if (dir != class_2350.field_11033) {
            ((WorldRendererAccessor)this.mc.field_1769).getBlockBreakingInfos().values().forEach((info) -> {
               if (info.method_13991().equals(this.mc.field_1724.method_24515().method_10093(dir))) {
                  this.renderBreaking(x, y, (double)((float)info.method_13988() / 9.0F));
               }

            });
         }
      }
   }

   private void renderBreaking(double x, double y, double percent) {
      Renderer2D.COLOR.quad(x, y, 16.0D * percent * (Double)this.scale.get(), 16.0D * (Double)this.scale.get(), this.BG_COLOR);
      Renderer2D.COLOR.quad(x, y, 16.0D * (Double)this.scale.get(), 1.0D * (Double)this.scale.get(), this.OL_COLOR);
      Renderer2D.COLOR.quad(x, y + 15.0D * (Double)this.scale.get(), 16.0D * (Double)this.scale.get(), 1.0D * (Double)this.scale.get(), this.OL_COLOR);
      Renderer2D.COLOR.quad(x, y, 1.0D * (Double)this.scale.get(), 16.0D * (Double)this.scale.get(), this.OL_COLOR);
      Renderer2D.COLOR.quad(x + 15.0D * (Double)this.scale.get(), y, 1.0D * (Double)this.scale.get(), 16.0D * (Double)this.scale.get(), this.OL_COLOR);
   }

   private static enum Facing {
      Left(-90),
      Right(90),
      Front(0),
      Back(180);

      int offset;

      private Facing(int offset) {
         this.offset = offset;
      }

      // $FF: synthetic method
      private static HoleHud.Facing[] $values() {
         return new HoleHud.Facing[]{Left, Right, Front, Back};
      }
   }
}
