package meteordevelopment.meteorclient.systems.hud.modules;

import java.util.Arrays;
import java.util.stream.Collectors;
import meteordevelopment.meteorclient.systems.hud.HUD;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_2338.class_2339;
import org.apache.commons.lang3.StringUtils;

public class BiomeHud extends DoubleTextHudElement {
   private final class_2339 blockPos = new class_2339();

   public BiomeHud(HUD hud) {
      super(hud, "biome", "Displays the biome you are in.", "Biome: ");
   }

   protected String getRight() {
      if (this.isInEditor()) {
         return "Plains";
      } else {
         this.blockPos.method_10102(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321());
         class_2960 id = this.mc.field_1687.method_30349().method_30530(class_2378.field_25114).method_10221(this.mc.field_1687.method_23753(this.blockPos));
         return id == null ? "Unknown" : (String)Arrays.stream(id.method_12832().split("_")).map(StringUtils::capitalize).collect(Collectors.joining(" "));
      }
   }
}
