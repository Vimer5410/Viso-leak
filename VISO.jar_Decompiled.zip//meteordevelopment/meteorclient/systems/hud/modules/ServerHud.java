package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.utils.Utils;

public class ServerHud extends DoubleTextHudElement {
   public ServerHud(HUD hud) {
      super(hud, "server", "Displays the server you're currently in.", "Server: ");
   }

   protected String getRight() {
      return !Utils.canUpdate() ? "None" : Utils.getWorldName();
   }
}
