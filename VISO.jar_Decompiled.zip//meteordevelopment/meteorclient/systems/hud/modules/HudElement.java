package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.settings.Settings;
import meteordevelopment.meteorclient.systems.hud.BoundingBox;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public abstract class HudElement implements ISerializable<HudElement> {
   public final String name;
   public final String title;
   public final String description;
   public boolean active;
   public final boolean defaultActive;
   protected final HUD hud;
   public final Settings settings = new Settings();
   public final BoundingBox box = new BoundingBox();
   protected final class_310 mc;

   public HudElement(HUD hud, String name, String description, boolean defaultActive) {
      this.hud = hud;
      this.name = name;
      this.title = Utils.nameToTitle(name);
      this.description = description;
      this.defaultActive = defaultActive;
      this.mc = class_310.method_1551();
   }

   public HudElement(HUD hud, String name, String description) {
      this.hud = hud;
      this.name = name;
      this.title = Utils.nameToTitle(name);
      this.description = description;
      this.defaultActive = true;
      this.mc = class_310.method_1551();
   }

   public void toggle() {
      this.active = !this.active;
   }

   public abstract void update(HudRenderer var1);

   public abstract void render(HudRenderer var1);

   protected boolean isInEditor() {
      return HUD.isEditorScreen() || !Utils.canUpdate();
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10582("name", this.name);
      tag.method_10556("active", this.active);
      tag.method_10566("settings", this.settings.toTag());
      tag.method_10566("box", this.box.toTag());
      return tag;
   }

   public HudElement fromTag(class_2487 tag) {
      this.active = tag.method_10545("active") ? tag.method_10577("active") : this.defaultActive;
      if (tag.method_10545("settings")) {
         this.settings.fromTag(tag.method_10562("settings"));
      }

      if (tag.method_10545("box")) {
         this.box.fromTag(tag.method_10562("box"));
      }

      return this;
   }
}
