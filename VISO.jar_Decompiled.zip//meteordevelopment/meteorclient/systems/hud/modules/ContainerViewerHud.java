package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.renderer.GL;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_4587;

public class ContainerViewerHud extends HudElement {
   private static final class_2960 TEXTURE = new class_2960("meteor-client", "textures/container.png");
   private final SettingGroup sgGeneral;
   private final Setting<Double> scale;
   private final Setting<Boolean> echestNoItem;
   private final class_1799[] inventory;

   public ContainerViewerHud(HUD hud) {
      super(hud, "container-viewer", "Displays held containers.", false);
      this.sgGeneral = this.settings.getDefaultGroup();
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale.")).defaultValue(2.0D).min(1.0D).sliderRange(1.0D, 5.0D).build());
      this.echestNoItem = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("echest-when-empty")).description("Display contents of ender chest if not holding any other container.")).defaultValue(false)).build());
      this.inventory = new class_1799[27];
   }

   public void update(HudRenderer renderer) {
      this.box.setSize(176.0D * (Double)this.scale.get(), 67.0D * (Double)this.scale.get());
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      class_1799 container = this.getContainer();
      if (container != null) {
         this.drawBackground((int)x, (int)y, container);
         Utils.getItemsInContainerItem(container, this.inventory);

         for(int row = 0; row < 3; ++row) {
            for(int i = 0; i < 9; ++i) {
               class_1799 stack = this.inventory[row * 9 + i];
               if (stack != null && !stack.method_7960()) {
                  RenderUtils.drawItem(stack, (int)(x + (double)(8 + i * 18) * (Double)this.scale.get()), (int)(y + (double)(7 + row * 18) * (Double)this.scale.get()), (Double)this.scale.get(), true);
               }
            }
         }

      }
   }

   private class_1799 getContainer() {
      if (this.isInEditor()) {
         return class_1802.field_8466.method_7854();
      } else {
         class_1799 stack = this.mc.field_1724.method_6079();
         if (Utils.hasItems(stack)) {
            return stack;
         } else {
            stack = this.mc.field_1724.method_6047();
            if (Utils.hasItems(stack)) {
               return stack;
            } else {
               return (Boolean)this.echestNoItem.get() ? class_1802.field_8466.method_7854() : null;
            }
         }
      }
   }

   private void drawBackground(int x, int y, class_1799 container) {
      GL.bindTexture(TEXTURE);
      Renderer2D.TEXTURE.begin();
      Renderer2D.TEXTURE.texQuad((double)x, (double)y, this.box.width, this.box.height, Utils.getShulkerColor(container));
      Renderer2D.TEXTURE.render((class_4587)null);
   }
}
