package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_3532;

public class CompassHud extends HudElement {
   private static final Color RED = new Color(225, 45, 45);
   private final SettingGroup sgGeneral;
   private final Setting<CompassHud.Mode> mode;
   private final Setting<Double> scale;

   public CompassHud(HUD hud) {
      super(hud, "compass", "Displays a compass.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("type")).description("Which type of direction information to show.")).defaultValue(CompassHud.Mode.Axis)).build());
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale.")).defaultValue(1.0D).min(1.0D).sliderRange(1.0D, 5.0D).build());
   }

   public void update(HudRenderer renderer) {
      this.box.setSize(100.0D * (Double)this.scale.get(), 100.0D * (Double)this.scale.get());
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX() + this.box.width / 2.0D;
      double y = this.box.getY() + this.box.height / 2.0D;
      double pitch = this.isInEditor() ? 120.0D : (double)class_3532.method_15363(this.mc.field_1724.method_36455() + 30.0F, -90.0F, 90.0F);
      pitch = Math.toRadians(pitch);
      double yaw = this.isInEditor() ? 180.0D : (double)class_3532.method_15393(this.mc.field_1724.method_36454());
      yaw = Math.toRadians(yaw);
      CompassHud.Direction[] var10 = CompassHud.Direction.values();
      int var11 = var10.length;

      for(int var12 = 0; var12 < var11; ++var12) {
         CompassHud.Direction direction = var10[var12];
         String axis = this.mode.get() == CompassHud.Mode.Axis ? direction.getAxis() : direction.name();
         renderer.text(axis, x + this.getX(direction, yaw) - renderer.textWidth(axis) / 2.0D, y + this.getY(direction, yaw, pitch) - renderer.textHeight() / 2.0D, direction == CompassHud.Direction.N ? RED : (Color)this.hud.primaryColor.get());
      }

   }

   private double getX(CompassHud.Direction direction, double yaw) {
      return Math.sin(this.getPos(direction, yaw)) * (Double)this.scale.get() * 40.0D;
   }

   private double getY(CompassHud.Direction direction, double yaw, double pitch) {
      return Math.cos(this.getPos(direction, yaw)) * Math.sin(pitch) * (Double)this.scale.get() * 40.0D;
   }

   private double getPos(CompassHud.Direction direction, double yaw) {
      return yaw + (double)direction.ordinal() * 3.141592653589793D / 2.0D;
   }

   public static enum Mode {
      Direction,
      Axis;

      // $FF: synthetic method
      private static CompassHud.Mode[] $values() {
         return new CompassHud.Mode[]{Direction, Axis};
      }
   }

   private static enum Direction {
      N("Z-"),
      W("X-"),
      S("Z+"),
      E("X+");

      private final String axis;

      private Direction(String axis) {
         this.axis = axis;
      }

      public String getAxis() {
         return this.axis;
      }

      // $FF: synthetic method
      private static CompassHud.Direction[] $values() {
         return new CompassHud.Direction[]{N, W, S, E};
      }
   }
}
