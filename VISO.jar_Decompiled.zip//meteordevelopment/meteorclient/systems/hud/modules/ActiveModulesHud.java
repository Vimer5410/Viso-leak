package meteordevelopment.meteorclient.systems.hud.modules;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ModuleListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_4587;

public class ActiveModulesHud extends HudElement {
   private final SettingGroup sgGeneral;
   private final Setting<List<Module>> hiddenModules;
   private final Setting<ActiveModulesHud.Sort> sort;
   private final Setting<Boolean> activeInfo;
   private final Setting<ActiveModulesHud.ColorMode> colorMode;
   private final Setting<SettingColor> flatColor;
   private final Setting<Boolean> outlines;
   private final Setting<Integer> outlineWidth;
   private final Setting<Double> rainbowSpeed;
   private final Setting<Double> rainbowSpread;
   private final List<Module> modules;
   private final Color rainbow;
   private double rainbowHue1;
   private double rainbowHue2;
   private double prevX;
   private double prevY;
   private double prevTextLength;
   private Color prevColor;

   public ActiveModulesHud(HUD hud) {
      super(hud, "active-modules", "Displays your active modules.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.hiddenModules = this.sgGeneral.add(((ModuleListSetting.Builder)((ModuleListSetting.Builder)(new ModuleListSetting.Builder()).name("hidden-modules")).description("Which modules not to show in the list.")).build());
      this.sort = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("sort")).description("How to sort active modules.")).defaultValue(ActiveModulesHud.Sort.Biggest)).build());
      this.activeInfo = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("additional-info")).description("Shows additional info from the module next to the name in the active modules list.")).defaultValue(true)).build());
      this.colorMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("color-mode")).description("What color to use for active modules.")).defaultValue(ActiveModulesHud.ColorMode.Rainbow)).build());
      this.flatColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("flat-color")).description("Color for flat color mode.")).defaultValue(new SettingColor(225, 25, 25))).visible(() -> {
         return this.colorMode.get() == ActiveModulesHud.ColorMode.Flat;
      })).build());
      this.outlines = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("outlines")).description("Whether or not to render outlines")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      IntSetting.Builder var10002 = ((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("outline-width")).description("Outline width")).defaultValue(4)).min(1).sliderMin(1);
      Setting var10003 = this.outlines;
      Objects.requireNonNull(var10003);
      this.outlineWidth = var10001.add(((IntSetting.Builder)var10002.visible(var10003::get)).build());
      this.rainbowSpeed = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("rainbow-speed")).description("Rainbow speed of rainbow color mode.")).defaultValue(0.05D).sliderMin(0.01D).sliderMax(0.2D).decimalPlaces(4).visible(() -> {
         return this.colorMode.get() == ActiveModulesHud.ColorMode.Rainbow;
      })).build());
      this.rainbowSpread = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("rainbow-spread")).description("Rainbow spread of rainbow color mode.")).defaultValue(0.01D).sliderMin(0.001D).sliderMax(0.05D).decimalPlaces(4).visible(() -> {
         return this.colorMode.get() == ActiveModulesHud.ColorMode.Rainbow;
      })).build());
      this.modules = new ArrayList();
      this.rainbow = new Color(255, 255, 255);
      this.prevColor = new Color();
   }

   public void update(HudRenderer renderer) {
      if (Modules.get() == null) {
         this.box.setSize(renderer.textWidth("Active Modules"), renderer.textHeight());
      } else {
         this.modules.clear();
         Iterator var2 = Modules.get().getActive().iterator();

         while(var2.hasNext()) {
            Module module = (Module)var2.next();
            if (!((List)this.hiddenModules.get()).contains(module)) {
               this.modules.add(module);
            }
         }

         this.modules.sort((o1, o2) -> {
            double _1 = this.getModuleWidth(renderer, o1);
            double _2 = this.getModuleWidth(renderer, o2);
            if (this.sort.get() == ActiveModulesHud.Sort.Smallest) {
               double temp = _1;
               _1 = _2;
               _2 = temp;
            }

            int a = Double.compare(_1, _2);
            if (a == 0) {
               return 0;
            } else {
               return a < 0 ? 1 : -1;
            }
         });
         double width = 0.0D;
         double height = 0.0D;

         for(int i = 0; i < this.modules.size(); ++i) {
            Module module = (Module)this.modules.get(i);
            width = Math.max(width, this.getModuleWidth(renderer, module));
            height += renderer.textHeight();
            if (i > 0) {
               height += 2.0D;
            }
         }

         this.box.setSize(width, height);
      }
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      if (Modules.get() == null) {
         renderer.text("Active Modules", x, y, (Color)this.hud.primaryColor.get());
      } else {
         this.rainbowHue1 += (Double)this.rainbowSpeed.get() * renderer.delta;
         if (this.rainbowHue1 > 1.0D) {
            --this.rainbowHue1;
         } else if (this.rainbowHue1 < -1.0D) {
            ++this.rainbowHue1;
         }

         this.rainbowHue2 = this.rainbowHue1;
         this.prevX = x;
         this.prevY = y;
         Renderer2D.COLOR.begin();

         for(int i = 0; i < this.modules.size(); ++i) {
            this.renderModule(renderer, this.modules, i, x + this.box.alignX(this.getModuleWidth(renderer, (Module)this.modules.get(i))), y);
            this.prevX = x + this.box.alignX(this.getModuleWidth(renderer, (Module)this.modules.get(i)));
            this.prevY = y;
            y += 2.0D + renderer.textHeight();
         }

         Renderer2D.COLOR.render((class_4587)null);
      }
   }

   private void renderModule(HudRenderer renderer, List<Module> modules, int index, double x, double y) {
      Module module = (Module)modules.get(index);
      Color color = (Color)this.flatColor.get();
      ActiveModulesHud.ColorMode colorMode = (ActiveModulesHud.ColorMode)this.colorMode.get();
      if (colorMode == ActiveModulesHud.ColorMode.Random) {
         color = module.color;
      } else if (colorMode == ActiveModulesHud.ColorMode.Rainbow) {
         this.rainbowHue2 += (Double)this.rainbowSpread.get();
         int c = java.awt.Color.HSBtoRGB((float)this.rainbowHue2, 1.0F, 1.0F);
         this.rainbow.r = Color.toRGBAR(c);
         this.rainbow.g = Color.toRGBAG(c);
         this.rainbow.b = Color.toRGBAB(c);
         color = this.rainbow;
      }

      renderer.text(module.title, x, y, color);
      double textLength = renderer.textWidth(module.title);
      if ((Boolean)this.activeInfo.get()) {
         String info = module.getInfoString();
         if (info != null) {
            renderer.text(info, x + renderer.textWidth(module.title) + renderer.textWidth(" "), y, (Color)this.hud.secondaryColor.get());
            textLength += renderer.textWidth(" ") + renderer.textWidth(info);
         }
      }

      if ((Boolean)this.outlines.get()) {
         if (index == 0) {
            Renderer2D.COLOR.quad(x - 2.0D - (double)(Integer)this.outlineWidth.get(), y - 2.0D, (double)(Integer)this.outlineWidth.get(), renderer.textHeight() + 4.0D, this.prevColor, this.prevColor, color, color);
            Renderer2D.COLOR.quad(x + textLength + 2.0D, y - 2.0D, (double)(Integer)this.outlineWidth.get(), renderer.textHeight() + 4.0D, this.prevColor, this.prevColor, color, color);
            Renderer2D.COLOR.quad(x - 2.0D - (double)(Integer)this.outlineWidth.get(), y - 2.0D - (double)(Integer)this.outlineWidth.get(), textLength + 4.0D + (double)((Integer)this.outlineWidth.get() * 2), (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
         } else if (index == modules.size() - 1) {
            Renderer2D.COLOR.quad(x - 2.0D - (double)(Integer)this.outlineWidth.get(), y, (double)(Integer)this.outlineWidth.get(), renderer.textHeight() + 2.0D + (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
            Renderer2D.COLOR.quad(x + textLength + 2.0D, y, (double)(Integer)this.outlineWidth.get(), renderer.textHeight() + 2.0D + (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
            Renderer2D.COLOR.quad(x - 2.0D - (double)(Integer)this.outlineWidth.get(), y + renderer.textHeight() + 2.0D, textLength + 4.0D + (double)((Integer)this.outlineWidth.get() * 2), (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
         }

         if (index > 0) {
            if (index < modules.size() - 1) {
               Renderer2D.COLOR.quad(x - 2.0D - (double)(Integer)this.outlineWidth.get(), y, (double)(Integer)this.outlineWidth.get(), renderer.textHeight() + 2.0D, this.prevColor, this.prevColor, color, color);
               Renderer2D.COLOR.quad(x + textLength + 2.0D, y, (double)(Integer)this.outlineWidth.get(), renderer.textHeight() + 2.0D, this.prevColor, this.prevColor, color, color);
            }

            Renderer2D.COLOR.quad(Math.min(this.prevX, x) - 2.0D - (double)(Integer)this.outlineWidth.get(), Math.max(this.prevX, x) == x ? y : y - (double)(Integer)this.outlineWidth.get(), Math.max(this.prevX, x) - 2.0D - (Math.min(this.prevX, x) - 2.0D - (double)(Integer)this.outlineWidth.get()), (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
            Renderer2D.COLOR.quad(Math.min(this.prevX + this.prevTextLength, x + textLength) + 2.0D, Math.min(this.prevX + this.prevTextLength, x + textLength) == x + textLength ? y : y - (double)(Integer)this.outlineWidth.get(), Math.max(this.prevX + this.prevTextLength, x + textLength) + 2.0D + (double)(Integer)this.outlineWidth.get() - (Math.min(this.prevX + this.prevTextLength, x + textLength) + 2.0D), (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
         }
      }

      this.prevTextLength = textLength;
      this.prevColor = color;
   }

   private double getModuleWidth(HudRenderer renderer, Module module) {
      double width = renderer.textWidth(module.title);
      if ((Boolean)this.activeInfo.get()) {
         String info = module.getInfoString();
         if (info != null) {
            width += renderer.textWidth(" ") + renderer.textWidth(info);
         }
      }

      return width;
   }

   public static enum Sort {
      Biggest,
      Smallest;

      // $FF: synthetic method
      private static ActiveModulesHud.Sort[] $values() {
         return new ActiveModulesHud.Sort[]{Biggest, Smallest};
      }
   }

   public static enum ColorMode {
      Flat,
      Random,
      Rainbow;

      // $FF: synthetic method
      private static ActiveModulesHud.ColorMode[] $values() {
         return new ActiveModulesHud.ColorMode[]{Flat, Random, Rainbow};
      }
   }
}
