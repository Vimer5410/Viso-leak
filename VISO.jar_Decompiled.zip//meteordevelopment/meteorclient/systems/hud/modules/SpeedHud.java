package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.utils.Utils;

public class SpeedHud extends DoubleTextHudElement {
   public SpeedHud(HUD hud) {
      super(hud, "speed", "Displays your horizontal speed.", "Speed: ");
   }

   protected String getRight() {
      return this.isInEditor() ? "0" : String.format("%.1f", Utils.getPlayerSpeed());
   }
}
