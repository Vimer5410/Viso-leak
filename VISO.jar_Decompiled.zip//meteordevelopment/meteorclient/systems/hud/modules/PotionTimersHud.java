package meteordevelopment.meteorclient.systems.hud.modules;

import java.util.Iterator;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.misc.Names;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1293;

public class PotionTimersHud extends HudElement {
   private final Color color = new Color();

   public PotionTimersHud(HUD hud) {
      super(hud, "potion-timers", "Displays active potion effects with timers.");
   }

   public void update(HudRenderer renderer) {
      if (this.isInEditor()) {
         this.box.setSize(renderer.textWidth("Potion Timers 0:00"), renderer.textHeight());
      } else {
         double width = 0.0D;
         double height = 0.0D;
         int i = 0;

         for(Iterator var7 = this.mc.field_1724.method_6026().iterator(); var7.hasNext(); ++i) {
            class_1293 statusEffectInstance = (class_1293)var7.next();
            width = Math.max(width, renderer.textWidth(this.getString(statusEffectInstance)));
            height += renderer.textHeight();
            if (i > 0) {
               height += 2.0D;
            }
         }

         this.box.setSize(width, height);
      }
   }

   public void render(HudRenderer renderer) {
      double x = this.box.getX();
      double y = this.box.getY();
      if (this.isInEditor()) {
         renderer.text("Potion Timers 0:00", x, y, this.color);
      } else {
         int i = 0;

         for(Iterator var7 = this.mc.field_1724.method_6026().iterator(); var7.hasNext(); ++i) {
            class_1293 statusEffectInstance = (class_1293)var7.next();
            class_1291 statusEffect = statusEffectInstance.method_5579();
            int c = statusEffect.method_5556();
            this.color.r = Color.toRGBAR(c);
            this.color.g = Color.toRGBAG(c);
            this.color.b = Color.toRGBAB(c);
            String text = this.getString(statusEffectInstance);
            renderer.text(text, x + this.box.alignX(renderer.textWidth(text)), y, this.color);
            this.color.r = this.color.g = this.color.b = 255;
            y += renderer.textHeight();
            if (i > 0) {
               y += 2.0D;
            }
         }

      }
   }

   private String getString(class_1293 statusEffectInstance) {
      return String.format("%s %d (%s)", Names.get(statusEffectInstance.method_5579()), statusEffectInstance.method_5578() + 1, class_1292.method_5577(statusEffectInstance, 1.0F));
   }
}
