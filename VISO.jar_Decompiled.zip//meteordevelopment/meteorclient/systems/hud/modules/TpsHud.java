package meteordevelopment.meteorclient.systems.hud.modules;

import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.utils.world.TickRate;

public class TpsHud extends DoubleTextHudElement {
   public TpsHud(HUD hud) {
      super(hud, "tps", "Displays the server's TPS.", "TPS: ");
   }

   protected String getRight() {
      return String.format("%.1f", TickRate.INSTANCE.getTickRate());
   }
}
