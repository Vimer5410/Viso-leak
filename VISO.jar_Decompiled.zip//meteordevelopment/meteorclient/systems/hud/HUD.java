package meteordevelopment.meteorclient.systems.hud;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.gui.screens.HudEditorScreen;
import meteordevelopment.meteorclient.gui.screens.HudElementScreen;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.Settings;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.systems.hud.modules.ActiveModulesHud;
import meteordevelopment.meteorclient.systems.hud.modules.ArmorHud;
import meteordevelopment.meteorclient.systems.hud.modules.ArmorHudTwo;
import meteordevelopment.meteorclient.systems.hud.modules.BiomeHud;
import meteordevelopment.meteorclient.systems.hud.modules.BreakingBlockHud;
import meteordevelopment.meteorclient.systems.hud.modules.CombatHud;
import meteordevelopment.meteorclient.systems.hud.modules.CompassHud;
import meteordevelopment.meteorclient.systems.hud.modules.ContainerViewerHud;
import meteordevelopment.meteorclient.systems.hud.modules.CrystalHud;
import meteordevelopment.meteorclient.systems.hud.modules.DurabilityHud;
import meteordevelopment.meteorclient.systems.hud.modules.EXPHud;
import meteordevelopment.meteorclient.systems.hud.modules.FierHud;
import meteordevelopment.meteorclient.systems.hud.modules.FpsHud;
import meteordevelopment.meteorclient.systems.hud.modules.HoleHud;
import meteordevelopment.meteorclient.systems.hud.modules.HudElement;
import meteordevelopment.meteorclient.systems.hud.modules.InventoryViewerHud;
import meteordevelopment.meteorclient.systems.hud.modules.LagNotifierHud;
import meteordevelopment.meteorclient.systems.hud.modules.LeverHud;
import meteordevelopment.meteorclient.systems.hud.modules.LogoHud;
import meteordevelopment.meteorclient.systems.hud.modules.LogoHudtwo;
import meteordevelopment.meteorclient.systems.hud.modules.LookingAtHud;
import meteordevelopment.meteorclient.systems.hud.modules.ModuleInfoHud;
import meteordevelopment.meteorclient.systems.hud.modules.PingHud;
import meteordevelopment.meteorclient.systems.hud.modules.PlayerModelHud;
import meteordevelopment.meteorclient.systems.hud.modules.PositionHud;
import meteordevelopment.meteorclient.systems.hud.modules.PotionTimersHud;
import meteordevelopment.meteorclient.systems.hud.modules.RotationHud;
import meteordevelopment.meteorclient.systems.hud.modules.ServerHud;
import meteordevelopment.meteorclient.systems.hud.modules.SpeedHud;
import meteordevelopment.meteorclient.systems.hud.modules.TNTHud;
import meteordevelopment.meteorclient.systems.hud.modules.TextRadarHud;
import meteordevelopment.meteorclient.systems.hud.modules.TimeHud;
import meteordevelopment.meteorclient.systems.hud.modules.TotemHud;
import meteordevelopment.meteorclient.systems.hud.modules.TpsHud;
import meteordevelopment.meteorclient.systems.hud.modules.WEBHud;
import meteordevelopment.meteorclient.systems.hud.modules.WatermarkHud;
import meteordevelopment.meteorclient.systems.hud.modules.WelcomeHud;
import meteordevelopment.meteorclient.systems.hud.modules.obsidianHud;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import meteordevelopment.meteorclient.utils.render.AlignmentX;
import meteordevelopment.meteorclient.utils.render.AlignmentY;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

public class HUD extends System<HUD> {
   public final Settings settings = new Settings();
   private final SettingGroup sgGeneral;
   private final SettingGroup sgEditor;
   public boolean active;
   public final Setting<Double> scale;
   public final Setting<SettingColor> primaryColor;
   public final Setting<SettingColor> secondaryColor;
   private final Setting<Keybind> toggleKeybind;
   public final Setting<Integer> snappingRange;
   private final HudRenderer RENDERER;
   public final List<HudElement> elements;
   public final HudElementLayer topLeft;
   public final HudElementLayer topCenter;
   public final HudElementLayer topRight;
   public final HudElementLayer bottomLeft;
   public final HudElementLayer bottomCenter;
   public final HudElementLayer bottomRight;
   public final Runnable reset;

   public HUD() {
      super("hud");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgEditor = this.settings.createGroup("Editor");
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("Scale of the HUD.")).defaultValue(1.0D).min(0.75D).sliderRange(0.75D, 4.0D).build());
      this.primaryColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("primary-color")).description("Primary color of text.")).defaultValue(new SettingColor(255, 255, 255))).build());
      this.secondaryColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("secondary-color")).description("Secondary color of text.")).defaultValue(new SettingColor(175, 175, 175))).build());
      this.toggleKeybind = this.sgGeneral.add(((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder()).name("toggle-keybind")).description("Keybind used to toggle HUD.")).defaultValue(Keybind.none())).action(() -> {
         this.active = !this.active;
      }).build());
      this.snappingRange = this.sgEditor.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("snapping-range")).description("Snapping range in editor.")).defaultValue(6)).build());
      this.RENDERER = new HudRenderer();
      this.elements = new ArrayList();
      this.reset = () -> {
         this.align();
         this.elements.forEach((element) -> {
            element.active = element.defaultActive;
            element.settings.forEach((group) -> {
               group.forEach(Setting::reset);
            });
         });
      };
      this.topLeft = new HudElementLayer(this.RENDERER, this.elements, AlignmentX.Left, AlignmentY.Top, 2, 2);
      this.topLeft.add(new LogoHud(this));
      this.topLeft.add(new LogoHudtwo(this));
      this.topLeft.add(new WatermarkHud(this));
      this.topLeft.add(new FpsHud(this));
      this.topLeft.add(new PingHud(this));
      this.topLeft.add(new TpsHud(this));
      this.topLeft.add(new SpeedHud(this));
      this.topLeft.add(new BiomeHud(this));
      this.topLeft.add(new TimeHud(this));
      this.topLeft.add(new ServerHud(this));
      this.topLeft.add(new DurabilityHud(this));
      this.topLeft.add(new BreakingBlockHud(this));
      this.topLeft.add(new LookingAtHud(this));
      this.topLeft.add(new ModuleInfoHud(this));
      this.topLeft.add(new TextRadarHud(this));
      this.topCenter = new HudElementLayer(this.RENDERER, this.elements, AlignmentX.Center, AlignmentY.Top, 0, 2);
      this.topCenter.add(new InventoryViewerHud(this));
      this.topCenter.add(new WelcomeHud(this));
      this.topCenter.add(new LagNotifierHud(this));
      this.topRight = new HudElementLayer(this.RENDERER, this.elements, AlignmentX.Right, AlignmentY.Top, 2, 2);
      this.topRight.add(new ActiveModulesHud(this));
      this.bottomLeft = new HudElementLayer(this.RENDERER, this.elements, AlignmentX.Left, AlignmentY.Bottom, 2, 2);
      this.bottomLeft.add(new PlayerModelHud(this));
      this.bottomCenter = new HudElementLayer(this.RENDERER, this.elements, AlignmentX.Center, AlignmentY.Bottom, 48, 64);
      this.bottomCenter.add(new ArmorHud(this));
      this.bottomCenter.add(new ArmorHudTwo(this));
      this.bottomCenter.add(new CompassHud(this));
      this.bottomCenter.add(new ContainerViewerHud(this));
      this.bottomCenter.add(new TotemHud(this));
      this.bottomCenter.add(new CrystalHud(this));
      this.bottomCenter.add(new EXPHud(this));
      this.bottomCenter.add(new TNTHud(this));
      this.bottomCenter.add(new WEBHud(this));
      this.bottomCenter.add(new FierHud(this));
      this.bottomCenter.add(new LeverHud(this));
      this.bottomCenter.add(new obsidianHud(this));
      this.bottomRight = new HudElementLayer(this.RENDERER, this.elements, AlignmentX.Right, AlignmentY.Bottom, 2, 2);
      this.bottomRight.add(new PositionHud(this));
      this.bottomRight.add(new RotationHud(this));
      this.bottomRight.add(new PotionTimersHud(this));
      this.bottomRight.add(new HoleHud(this));
      this.bottomRight.add(new CombatHud(this));
      this.align();
   }

   public static HUD get() {
      return (HUD)Systems.get(HUD.class);
   }

   private void align() {
      this.RENDERER.begin((Double)this.scale.get(), 0.0D, true);
      this.topLeft.align();
      this.topCenter.align();
      this.topRight.align();
      this.bottomLeft.align();
      this.bottomCenter.align();
      this.bottomRight.align();
      this.RENDERER.end();
   }

   @EventHandler
   public void onRender(Render2DEvent event) {
      if (isEditorScreen()) {
         this.render(event.tickDelta, (hudElement) -> {
            return true;
         });
      } else if (this.active && !MeteorClient.mc.field_1690.field_1842 && !MeteorClient.mc.field_1690.field_1866) {
         this.render(event.tickDelta, (hudElement) -> {
            return hudElement.active;
         });
      }

   }

   public void render(float delta, Predicate<HudElement> shouldRender) {
      this.RENDERER.begin((Double)this.scale.get(), (double)delta, false);
      Iterator var3 = this.elements.iterator();

      while(var3.hasNext()) {
         HudElement element = (HudElement)var3.next();
         if (shouldRender.test(element)) {
            element.update(this.RENDERER);
            element.render(this.RENDERER);
         }
      }

      this.RENDERER.end();
   }

   public static boolean isEditorScreen() {
      return MeteorClient.mc.field_1755 instanceof HudEditorScreen || MeteorClient.mc.field_1755 instanceof HudElementScreen;
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10556("active", this.active);
      tag.method_10566("settings", this.settings.toTag());
      tag.method_10566("elements", NbtUtils.listToTag(this.elements));
      return tag;
   }

   public HUD fromTag(class_2487 tag) {
      this.settings.reset();
      if (tag.method_10545("active")) {
         this.active = tag.method_10577("active");
      }

      if (tag.method_10545("settings")) {
         this.settings.fromTag(tag.method_10562("settings"));
      }

      if (tag.method_10545("elements")) {
         class_2499 elementsTag = tag.method_10554("elements", 10);
         Iterator var3 = elementsTag.iterator();

         while(true) {
            while(var3.hasNext()) {
               class_2520 t = (class_2520)var3.next();
               class_2487 elementTag = (class_2487)t;
               Iterator var6 = this.elements.iterator();

               while(var6.hasNext()) {
                  HudElement element = (HudElement)var6.next();
                  if (element.name.equals(elementTag.method_10558("name"))) {
                     element.fromTag(elementTag);
                     break;
                  }
               }
            }

            return (HUD)super.fromTag(tag);
         }
      } else {
         return (HUD)super.fromTag(tag);
      }
   }
}
