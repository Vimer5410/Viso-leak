package meteordevelopment.meteorclient.systems.hud;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.systems.hud.modules.HudElement;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.AlignmentX;
import meteordevelopment.meteorclient.utils.render.AlignmentY;

public class HudElementLayer {
   private final HudRenderer renderer;
   private final List<HudElement> allElements;
   private final List<HudElement> elements;
   private final AlignmentX xAlign;
   private final AlignmentY yAlign;
   private final int xOffset;
   private final int yOffset;

   public HudElementLayer(HudRenderer renderer, List<HudElement> allElements, AlignmentX xAlign, AlignmentY yAlign, int xOffset, int yOffset) {
      this.renderer = renderer;
      this.allElements = allElements;
      this.elements = new ArrayList();
      this.xAlign = xAlign;
      this.yAlign = yAlign;
      this.xOffset = xOffset;
      this.yOffset = yOffset;
   }

   public void add(HudElement element) {
      this.allElements.add(element);
      this.elements.add(element);
      element.settings.registerColorSettings((Module)null);
   }

   public void align() {
      double x = (double)(this.xOffset * (this.xAlign == AlignmentX.Right ? -1 : 1));
      double y = (double)(this.yOffset * (this.yAlign == AlignmentY.Bottom ? -1 : 1));
      Iterator var5 = this.elements.iterator();

      while(var5.hasNext()) {
         HudElement element = (HudElement)var5.next();
         element.update(this.renderer);
         element.box.x = this.xAlign;
         element.box.y = this.yAlign;
         element.box.xOffset = (double)((int)Math.round(x));
         element.box.yOffset = (double)((int)Math.round(y));
         if (this.yAlign == AlignmentY.Bottom) {
            y -= element.box.height;
         } else {
            y += element.box.height;
         }
      }

   }
}
