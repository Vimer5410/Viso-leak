package meteordevelopment.meteorclient.systems.hud;

import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import meteordevelopment.meteorclient.utils.render.AlignmentX;
import meteordevelopment.meteorclient.utils.render.AlignmentY;
import net.minecraft.class_2487;
import net.minecraft.class_2514;

public class BoundingBox implements ISerializable<BoundingBox> {
   public AlignmentX x;
   public AlignmentY y;
   public double xOffset;
   public double yOffset;
   public double width;
   public double height;

   public BoundingBox() {
      this.x = AlignmentX.Left;
      this.y = AlignmentY.Top;
   }

   public double alignX(double width) {
      double var10000;
      switch(this.x) {
      case Left:
         var10000 = 0.0D;
         break;
      case Center:
         var10000 = this.width / 2.0D - width / 2.0D;
         break;
      case Right:
         var10000 = this.width - width;
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   public void addPos(double deltaX, double deltaY) {
      this.xOffset += deltaX;
      this.yOffset += deltaY;
      double xPos = this.getX();
      double yPos = this.getY();
      double c;
      double cLeft;
      switch(this.x) {
      case Left:
         c = (double)Utils.getWindowWidth() / 3.0D;
         if (xPos >= c - this.width / 2.0D) {
            this.x = AlignmentX.Center;
            this.xOffset = -c / 2.0D + xPos - c + this.width / 2.0D;
         }
         break;
      case Center:
         c = (double)Utils.getWindowWidth() / 3.0D;
         cLeft = (double)Utils.getWindowWidth() / 3.0D * 2.0D;
         if (xPos > cLeft - this.width / 2.0D) {
            this.x = AlignmentX.Right;
            this.xOffset = -(c - this.width) + (c - ((double)Utils.getWindowWidth() - xPos));
         } else if (xPos < c - this.width / 2.0D) {
            this.x = AlignmentX.Left;
            this.xOffset = xPos;
         }
         break;
      case Right:
         c = (double)Utils.getWindowWidth() / 3.0D;
         cLeft = (double)Utils.getWindowWidth() / 3.0D * 2.0D;
         if (xPos <= cLeft - this.width / 2.0D) {
            this.x = AlignmentX.Center;
            this.xOffset = -c / 2.0D + xPos - c + this.width / 2.0D;
         }
      }

      if (this.x == AlignmentX.Left && this.xOffset < 0.0D) {
         this.xOffset = 0.0D;
      } else if (this.x == AlignmentX.Right && this.xOffset > 0.0D) {
         this.xOffset = 0.0D;
      }

      switch(this.y) {
      case Top:
         c = (double)Utils.getWindowHeight() / 3.0D;
         if (yPos >= c - this.height / 2.0D) {
            this.y = AlignmentY.Center;
            this.yOffset = -c / 2.0D + yPos - c + this.height / 2.0D;
         }
         break;
      case Center:
         c = (double)Utils.getWindowHeight() / 3.0D;
         cLeft = (double)Utils.getWindowHeight() / 3.0D * 2.0D;
         if (yPos > cLeft - this.height / 2.0D) {
            this.y = AlignmentY.Bottom;
            this.yOffset = -(c - this.height) + (c - ((double)Utils.getWindowHeight() - yPos));
         } else if (yPos < c - this.height / 2.0D) {
            this.y = AlignmentY.Top;
            this.yOffset = yPos;
         }
         break;
      case Bottom:
         c = (double)Utils.getWindowHeight() / 3.0D;
         cLeft = (double)Utils.getWindowHeight() / 3.0D * 2.0D;
         if (yPos <= cLeft - this.height / 2.0D) {
            this.y = AlignmentY.Center;
            this.yOffset = -c / 2.0D + yPos - c + this.height / 2.0D;
         }
      }

      if (this.y == AlignmentY.Top && this.yOffset < 0.0D) {
         this.yOffset = 0.0D;
      } else if (this.y == AlignmentY.Bottom && this.yOffset > 0.0D) {
         this.yOffset = 0.0D;
      }

   }

   public void setSize(double width, double height) {
      this.width = width;
      this.height = height;
   }

   public double getX() {
      double var10000;
      switch(this.x) {
      case Left:
         var10000 = this.xOffset;
         break;
      case Center:
         var10000 = (double)Utils.getWindowWidth() / 2.0D - this.width / 2.0D + this.xOffset;
         break;
      case Right:
         var10000 = (double)Utils.getWindowWidth() - this.width + this.xOffset;
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   public void setX(int x) {
      this.addPos((double)x - this.getX(), 0.0D);
   }

   public double getY() {
      double var10000;
      switch(this.y) {
      case Top:
         var10000 = this.yOffset;
         break;
      case Center:
         var10000 = (double)Utils.getWindowHeight() / 2.0D - this.height / 2.0D + this.yOffset;
         break;
      case Bottom:
         var10000 = (double)Utils.getWindowHeight() - this.height + this.yOffset;
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   public void setY(int y) {
      this.addPos(0.0D, (double)y - this.getY());
   }

   public boolean isOver(double x, double y) {
      double sx = this.getX();
      double sy = this.getY();
      return x >= sx && x <= sx + this.width && y >= sy && y <= sy + this.height;
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10582("x", this.x.name());
      tag.method_10582("y", this.y.name());
      tag.method_10549("xOffset", this.xOffset);
      tag.method_10549("yOffset", this.yOffset);
      return tag;
   }

   public BoundingBox fromTag(class_2487 tag) {
      this.x = AlignmentX.valueOf(tag.method_10558("x"));
      this.y = AlignmentY.valueOf(tag.method_10558("y"));
      this.xOffset = ((class_2514)tag.method_10580("xOffset")).method_10697();
      this.yOffset = ((class_2514)tag.method_10580("yOffset")).method_10697();
      return this;
   }
}
