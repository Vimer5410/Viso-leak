package meteordevelopment.meteorclient.systems.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.systems.commands.commands.BaritoneCommand;
import meteordevelopment.meteorclient.systems.commands.commands.BindsCommand;
import meteordevelopment.meteorclient.systems.commands.commands.CommandsCommand;
import meteordevelopment.meteorclient.systems.commands.commands.DamageCommand;
import meteordevelopment.meteorclient.systems.commands.commands.DismountCommand;
import meteordevelopment.meteorclient.systems.commands.commands.DropCommand;
import meteordevelopment.meteorclient.systems.commands.commands.EnchantCommand;
import meteordevelopment.meteorclient.systems.commands.commands.FOVCommand;
import meteordevelopment.meteorclient.systems.commands.commands.FakePlayerCommand;
import meteordevelopment.meteorclient.systems.commands.commands.FriendsCommand;
import meteordevelopment.meteorclient.systems.commands.commands.GamemodeCommand;
import meteordevelopment.meteorclient.systems.commands.commands.GiveCommand;
import meteordevelopment.meteorclient.systems.commands.commands.HClipCommand;
import meteordevelopment.meteorclient.systems.commands.commands.InventoryCommand;
import meteordevelopment.meteorclient.systems.commands.commands.LocateCommand;
import meteordevelopment.meteorclient.systems.commands.commands.ModulesCommand;
import meteordevelopment.meteorclient.systems.commands.commands.NameHistoryCommand;
import meteordevelopment.meteorclient.systems.commands.commands.NbtCommand;
import meteordevelopment.meteorclient.systems.commands.commands.NotebotCommand;
import meteordevelopment.meteorclient.systems.commands.commands.PeekCommand;
import meteordevelopment.meteorclient.systems.commands.commands.ProfilesCommand;
import meteordevelopment.meteorclient.systems.commands.commands.ReloadCommand;
import meteordevelopment.meteorclient.systems.commands.commands.ResetCommand;
import meteordevelopment.meteorclient.systems.commands.commands.RotationCommand;
import meteordevelopment.meteorclient.systems.commands.commands.SaveMapCommand;
import meteordevelopment.meteorclient.systems.commands.commands.SayCommand;
import meteordevelopment.meteorclient.systems.commands.commands.ServerCommand;
import meteordevelopment.meteorclient.systems.commands.commands.SettingCommand;
import meteordevelopment.meteorclient.systems.commands.commands.SpectateCommand;
import meteordevelopment.meteorclient.systems.commands.commands.SwarmCommand;
import meteordevelopment.meteorclient.systems.commands.commands.ToggleCommand;
import meteordevelopment.meteorclient.systems.commands.commands.VClipCommand;
import meteordevelopment.meteorclient.systems.commands.commands.WaypointCommand;
import net.minecraft.class_2172;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_637;

public class Commands extends System<Commands> {
   private final CommandDispatcher<class_2172> DISPATCHER = new CommandDispatcher();
   private final class_2172 COMMAND_SOURCE;
   private final List<Command> commands;
   private final Map<Class<? extends Command>, Command> commandInstances;

   public Commands() {
      super((String)null);
      this.COMMAND_SOURCE = new Commands.ChatCommandSource(MeteorClient.mc);
      this.commands = new ArrayList();
      this.commandInstances = new HashMap();
   }

   public static Commands get() {
      return (Commands)Systems.get(Commands.class);
   }

   public void init() {
      this.add(new BaritoneCommand());
      this.add(new VClipCommand());
      this.add(new HClipCommand());
      this.add(new DismountCommand());
      this.add(new DamageCommand());
      this.add(new DropCommand());
      this.add(new EnchantCommand());
      this.add(new FakePlayerCommand());
      this.add(new FriendsCommand());
      this.add(new CommandsCommand());
      this.add(new InventoryCommand());
      this.add(new LocateCommand());
      this.add(new NbtCommand());
      this.add(new NotebotCommand());
      this.add(new PeekCommand());
      this.add(new ProfilesCommand());
      this.add(new ReloadCommand());
      this.add(new ResetCommand());
      this.add(new SayCommand());
      this.add(new ServerCommand());
      this.add(new SwarmCommand());
      this.add(new ToggleCommand());
      this.add(new SettingCommand());
      this.add(new SpectateCommand());
      this.add(new GamemodeCommand());
      this.add(new SaveMapCommand());
      this.add(new ModulesCommand());
      this.add(new BindsCommand());
      this.add(new GiveCommand());
      this.add(new NameHistoryCommand());
      this.add(new BindCommand());
      this.add(new FOVCommand());
      this.add(new RotationCommand());
      this.add(new WaypointCommand());
      this.commands.sort(Comparator.comparing(Command::getName));
   }

   public void dispatch(String message) throws CommandSyntaxException {
      this.dispatch(message, new Commands.ChatCommandSource(MeteorClient.mc));
   }

   public void dispatch(String message, class_2172 source) throws CommandSyntaxException {
      ParseResults<class_2172> results = this.DISPATCHER.parse(message, source);
      this.DISPATCHER.execute(results);
   }

   public CommandDispatcher<class_2172> getDispatcher() {
      return this.DISPATCHER;
   }

   public class_2172 getCommandSource() {
      return this.COMMAND_SOURCE;
   }

   public void add(Command command) {
      this.commands.removeIf((command1) -> {
         return command1.getName().equals(command.getName());
      });
      this.commandInstances.values().removeIf((command1) -> {
         return command1.getName().equals(command.getName());
      });
      command.registerTo(this.DISPATCHER);
      this.commands.add(command);
      this.commandInstances.put(command.getClass(), command);
   }

   public int getCount() {
      return this.commands.size();
   }

   public List<Command> getAll() {
      return this.commands;
   }

   public <T extends Command> T get(Class<T> klass) {
      return (Command)this.commandInstances.get(klass);
   }

   private static final class ChatCommandSource extends class_637 {
      public ChatCommandSource(class_310 client) {
         super((class_634)null, client);
      }
   }
}
