package meteordevelopment.meteorclient.systems.commands.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.systems.profiles.Profile;
import meteordevelopment.meteorclient.systems.profiles.Profiles;
import net.minecraft.class_2172;
import net.minecraft.class_2585;

public class ProfileArgumentType implements ArgumentType<String> {
   private static final DynamicCommandExceptionType NO_SUCH_PROFILE = new DynamicCommandExceptionType((name) -> {
      return new class_2585("Profile with name " + name + " doesn't exist.");
   });

   public static ProfileArgumentType profile() {
      return new ProfileArgumentType();
   }

   public static Profile getProfile(CommandContext<?> context, String name) {
      return Profiles.get().get((String)context.getArgument(name, String.class));
   }

   public String parse(StringReader reader) throws CommandSyntaxException {
      String argument = reader.getRemaining();
      reader.setCursor(reader.getTotalLength());
      if (Profiles.get().get(argument) == null) {
         throw NO_SUCH_PROFILE.create(argument);
      } else {
         return argument;
      }
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
      return class_2172.method_9265(this.getExamples(), builder);
   }

   public Collection<String> getExamples() {
      List<String> names = new ArrayList();
      Iterator var2 = Profiles.get().iterator();

      while(var2.hasNext()) {
         Profile profile = (Profile)var2.next();
         names.add(profile.name);
      }

      return names;
   }
}
