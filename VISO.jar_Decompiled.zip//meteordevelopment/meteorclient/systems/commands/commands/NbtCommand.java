package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.commands.arguments.CompoundNbtTagArgumentType;
import meteordevelopment.meteorclient.systems.config.Config;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2172;
import net.minecraft.class_2203;
import net.minecraft.class_2487;
import net.minecraft.class_2554;
import net.minecraft.class_2558;
import net.minecraft.class_2568;
import net.minecraft.class_2585;
import net.minecraft.class_2873;
import net.minecraft.class_2203.class_2209;
import net.minecraft.class_2558.class_2559;
import net.minecraft.class_2568.class_5247;

public class NbtCommand extends Command {
   public NbtCommand() {
      super("nbt", "Modifies NBT data for an item, example: .nbt add {display:{Name:'{\"text\":\"$cRed Name\"}'}}");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("add").then(argument("nbt_data", CompoundNbtTagArgumentType.nbtTag()).executes((s) -> {
         class_1799 stack = mc.field_1724.method_31548().method_7391();
         if (this.validBasic(stack)) {
            class_2487 tag = CompoundNbtTagArgumentType.getTag(s, "nbt_data");
            class_2487 source = stack.method_7948();
            if (tag != null) {
               source.method_10543(tag);
               this.setStack(stack);
            } else {
               this.error("Some of the NBT data could not be found, try using: " + (String)Config.get().prefix.get() + "nbt set {nbt}", new Object[0]);
            }
         }

         return 1;
      })));
      builder.then(literal("set").then(argument("nbt_data", CompoundNbtTagArgumentType.nbtTag()).executes((s) -> {
         class_1799 stack = mc.field_1724.method_31548().method_7391();
         if (this.validBasic(stack)) {
            class_2487 tag = (class_2487)s.getArgument("nbt_data", class_2487.class);
            stack.method_7980(tag);
            this.setStack(stack);
         }

         return 1;
      })));
      builder.then(literal("remove").then(argument("nbt_path", class_2203.method_9360()).executes((s) -> {
         class_1799 stack = mc.field_1724.method_31548().method_7391();
         if (this.validBasic(stack)) {
            class_2209 path = (class_2209)s.getArgument("nbt_path", class_2209.class);
            path.method_9372(stack.method_7969());
         }

         return 1;
      })));
      builder.then(literal("get").executes((s) -> {
         class_1799 stack = mc.field_1724.method_31548().method_7391();
         if (stack == null) {
            this.error("You must hold an item in your main hand.", new Object[0]);
         } else {
            class_2487 tag = stack.method_7969();
            String nbt = tag == null ? "{}" : tag.method_10714();
            class_2554 copyButton = new class_2585("NBT");
            copyButton.method_10862(copyButton.method_10866().method_27706(class_124.field_1073).method_10958(new class_2558(class_2559.field_11750, this.toString(new String[]{"copy"}))).method_10949(new class_2568(class_5247.field_24342, new class_2585("Copy the NBT data to your clipboard."))));
            class_2554 text = new class_2585("");
            text.method_10852(copyButton);
            text.method_10852(new class_2585(": " + nbt));
            this.info(text);
         }

         return 1;
      }));
      builder.then(literal("copy").executes((s) -> {
         class_1799 stack = mc.field_1724.method_31548().method_7391();
         if (stack == null) {
            this.error("You must hold an item in your main hand.", new Object[0]);
         } else {
            class_2487 tag = stack.method_7948();
            mc.field_1774.method_1455(tag.toString());
            class_2554 nbt = new class_2585("NBT");
            nbt.method_10862(nbt.method_10866().method_27706(class_124.field_1073).method_10949(new class_2568(class_5247.field_24342, new class_2585(tag.toString()))));
            class_2554 text = new class_2585("");
            text.method_10852(nbt);
            text.method_10852(new class_2585(" data copied!"));
            this.info(text);
         }

         return 1;
      }));
      builder.then(literal("count").then(argument("count", IntegerArgumentType.integer(-127, 127)).executes((context) -> {
         class_1799 stack = mc.field_1724.method_31548().method_7391();
         if (this.validBasic(stack)) {
            int count = IntegerArgumentType.getInteger(context, "count");
            stack.method_7939(count);
            this.setStack(stack);
            this.info("Set mainhand stack count to %s.", new Object[]{count});
         }

         return 1;
      })));
   }

   private void setStack(class_1799 stack) {
      mc.field_1724.field_3944.method_2883(new class_2873(36 + mc.field_1724.method_31548().field_7545, stack));
   }

   private boolean validBasic(class_1799 stack) {
      if (!mc.field_1724.method_31549().field_7477) {
         this.error("Creative mode only.", new Object[0]);
         return false;
      } else if (stack == null) {
         this.error("You must hold an item in your main hand.", new Object[0]);
         return false;
      } else {
         return true;
      }
   }
}
