package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2554;
import net.minecraft.class_2568;
import net.minecraft.class_2585;
import net.minecraft.class_2568.class_5247;

public class ModulesCommand extends Command {
   public ModulesCommand() {
      super("modules", "Displays a list of all modules.", "features");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes((context) -> {
         ChatUtils.info("--- Modules ((highlight)%d(default)) ---", Modules.get().getCount());
         Modules.loopCategories().forEach((category) -> {
            class_2554 categoryMessage = new class_2585("");
            Modules.get().getGroup(category).forEach((module) -> {
               categoryMessage.method_10852(this.getModuleText(module));
            });
            ChatUtils.sendMsg(category.name, categoryMessage);
         });
         return 1;
      });
   }

   private class_2554 getModuleText(Module module) {
      class_2554 tooltip = new class_2585("");
      tooltip.method_10852((new class_2585(module.title)).method_27695(new class_124[]{class_124.field_1078, class_124.field_1067})).method_27693("\n");
      tooltip.method_10852((new class_2585(module.name)).method_27692(class_124.field_1080)).method_27693("\n\n");
      tooltip.method_10852((new class_2585(module.description)).method_27692(class_124.field_1068));
      class_2554 finalModule = new class_2585(module.title);
      if (module != Modules.get().getList().get(Modules.get().getList().size() - 1)) {
         finalModule.method_10852((new class_2585(", ")).method_27692(class_124.field_1080));
      }

      finalModule.method_10862(finalModule.method_10866().method_10949(new class_2568(class_5247.field_24342, tooltip)));
      return finalModule;
   }
}
