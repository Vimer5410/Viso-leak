package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import javax.imageio.ImageIO;
import meteordevelopment.meteorclient.mixin.MapRendererAccessor;
import meteordevelopment.meteorclient.systems.commands.Command;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1806;
import net.minecraft.class_2172;
import net.minecraft.class_22;
import net.minecraft.class_2585;
import net.minecraft.class_330;
import net.minecraft.class_330.class_331;
import org.lwjgl.BufferUtils;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

public class SaveMapCommand extends Command {
   private static final SimpleCommandExceptionType MAP_NOT_FOUND = new SimpleCommandExceptionType(new class_2585("You must be holding a filled map."));
   private static final SimpleCommandExceptionType OOPS = new SimpleCommandExceptionType(new class_2585("Something went wrong."));
   private final PointerBuffer filters = BufferUtils.createPointerBuffer(1);

   public SaveMapCommand() {
      super("save-map", "Saves a map to an image.", "sm");
      ByteBuffer pngFilter = MemoryUtil.memASCII("*.png");
      this.filters.put(pngFilter);
      this.filters.rewind();
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      ((LiteralArgumentBuilder)builder.executes((context) -> {
         class_22 state = this.getMapState();
         if (state == null) {
            throw MAP_NOT_FOUND.create();
         } else {
            class_1799 map = this.getMap();
            String path = this.getPath();
            if (path == null) {
               throw OOPS.create();
            } else {
               this.saveMap(map, state, path, 128);
               return 1;
            }
         }
      })).then(argument("scale", IntegerArgumentType.integer()).executes((context) -> {
         int scale = IntegerArgumentType.getInteger(context, "scale");
         class_22 state = this.getMapState();
         if (state == null) {
            throw MAP_NOT_FOUND.create();
         } else {
            class_1799 map = this.getMap();
            String path = this.getPath();
            if (path == null) {
               throw OOPS.create();
            } else {
               this.saveMap(map, state, path, scale);
               return 1;
            }
         }
      }));
   }

   private void saveMap(class_1799 map, class_22 state, String path, int scale) {
      class_330 mapRenderer = mc.field_1773.method_3194();
      class_331 texture = ((MapRendererAccessor)mapRenderer).invokeGetMapTexture(class_1806.method_8003(map), state);
      int[] data = texture.field_2048.method_4525().method_4322();
      BufferedImage image = new BufferedImage(128, 128, 2);
      image.setRGB(0, 0, image.getWidth(), image.getHeight(), data, 0, 128);
      BufferedImage scaledImage = new BufferedImage(scale, scale, 2);
      if (scale != 128) {
         Graphics2D g = scaledImage.createGraphics();
         g.setComposite(AlphaComposite.Src);
         g.drawImage(image, 0, 0, scale, scale, (ImageObserver)null);
         g.dispose();
      }

      try {
         ImageIO.write(scale == 128 ? image : scaledImage, "png", new File(path));
      } catch (IOException var11) {
         var11.printStackTrace();
      }

   }

   private class_22 getMapState() {
      class_1799 map = this.getMap();
      if (map == null) {
         return null;
      } else {
         class_22 state = class_1806.method_7997(class_1806.method_8003(map), mc.field_1687);
         return state == null ? null : state;
      }
   }

   private String getPath() {
      String path = TinyFileDialogs.tinyfd_saveFileDialog("Save image", (CharSequence)null, this.filters, (CharSequence)null);
      if (path == null) {
         return null;
      } else {
         if (!path.endsWith(".png")) {
            path = path + ".png";
         }

         return path;
      }
   }

   private class_1799 getMap() {
      class_1799 itemStack = mc.field_1724.method_6047();
      if (itemStack.method_7909() == class_1802.field_8204) {
         return itemStack;
      } else {
         itemStack = mc.field_1724.method_6079();
         return itemStack.method_7909() == class_1802.field_8204 ? itemStack : null;
      }
   }
}
