package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.gui.GuiThemes;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.commands.arguments.ModuleArgumentType;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_2172;

public class ResetCommand extends Command {
   public ResetCommand() {
      super("reset", "Resets specified settings.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      ((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)builder.then(((LiteralArgumentBuilder)literal("settings").then(argument("module", ModuleArgumentType.module()).executes((context) -> {
         Module module = (Module)context.getArgument("module", Module.class);
         module.settings.forEach((group) -> {
            group.forEach(Setting::reset);
         });
         module.info("Reset all settings.");
         return 1;
      }))).then(literal("all").executes((context) -> {
         Modules.get().getAll().forEach((module) -> {
            module.settings.forEach((group) -> {
               group.forEach(Setting::reset);
            });
         });
         ChatUtils.info("Modules", "Reset all module settings");
         return 1;
      })))).then(literal("gui").executes((context) -> {
         GuiThemes.get().clearWindowConfigs();
         ChatUtils.info("Reset GUI positioning.");
         return 1;
      }))).then(((LiteralArgumentBuilder)literal("bind").then(argument("module", ModuleArgumentType.module()).executes((context) -> {
         Module module = (Module)context.getArgument("module", Module.class);
         module.keybind.set(true, -1);
         module.info("Reset bind.");
         return 1;
      }))).then(literal("all").executes((context) -> {
         Modules.get().getAll().forEach((module) -> {
            module.keybind.set(true, -1);
         });
         ChatUtils.info("Modules", "Reset all binds.");
         return 1;
      })))).then(literal("hud").executes((context) -> {
         ((HUD)Systems.get(HUD.class)).reset.run();
         ChatUtils.info("HUD", "Reset all elements.");
         return 1;
      }));
   }
}
