package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.systems.commands.Command;
import net.minecraft.class_1297;
import net.minecraft.class_2172;
import net.minecraft.class_243;
import net.minecraft.class_746;

public class HClipCommand extends Command {
   public HClipCommand() {
      super("hclip", "Lets you clip through blocks horizontally.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("blocks", DoubleArgumentType.doubleArg()).executes((context) -> {
         class_746 player = mc.field_1724;

         assert player != null;

         double blocks = (Double)context.getArgument("blocks", Double.class);
         class_243 forward = class_243.method_1030(0.0F, player.method_36454()).method_1029();
         if (player.method_5765()) {
            class_1297 vehicle = player.method_5854();
            vehicle.method_5814(vehicle.method_23317() + forward.field_1352 * blocks, vehicle.method_23318(), vehicle.method_23321() + forward.field_1350 * blocks);
         }

         player.method_5814(player.method_23317() + forward.field_1352 * blocks, player.method_23318(), player.method_23321() + forward.field_1350 * blocks);
         return 1;
      }));
   }
}
