package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import meteordevelopment.meteorclient.systems.commands.Command;
import net.minecraft.class_2172;
import net.minecraft.class_3532;

public class RotationCommand extends Command {
   public RotationCommand() {
      super("rotation", "Modifies your rotation.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      ((LiteralArgumentBuilder)builder.then(literal("set").then(((RequiredArgumentBuilder)argument("pitch", FloatArgumentType.floatArg(-90.0F, 90.0F)).executes((context) -> {
         mc.field_1724.method_36457((Float)context.getArgument("pitch", Float.class));
         return 1;
      })).then(argument("yaw", FloatArgumentType.floatArg(-180.0F, 180.0F)).executes((context) -> {
         mc.field_1724.method_36457((Float)context.getArgument("pitch", Float.class));
         mc.field_1724.method_36456((Float)context.getArgument("yaw", Float.class));
         return 1;
      }))))).then(literal("add").then(((RequiredArgumentBuilder)argument("pitch", FloatArgumentType.floatArg(-90.0F, 90.0F)).executes((context) -> {
         float pitch = mc.field_1724.method_36455() + (Float)context.getArgument("pitch", Float.class);
         mc.field_1724.method_36457(pitch >= 0.0F ? Math.min(pitch, 90.0F) : Math.max(pitch, -90.0F));
         return 1;
      })).then(argument("yaw", FloatArgumentType.floatArg(-180.0F, 180.0F)).executes((context) -> {
         float pitch = mc.field_1724.method_36455() + (Float)context.getArgument("pitch", Float.class);
         mc.field_1724.method_36457(pitch >= 0.0F ? Math.min(pitch, 90.0F) : Math.max(pitch, -90.0F));
         float yaw = mc.field_1724.method_36454() + (Float)context.getArgument("yaw", Float.class);
         mc.field_1724.method_36456(class_3532.method_15393(yaw));
         return 1;
      }))));
   }
}
