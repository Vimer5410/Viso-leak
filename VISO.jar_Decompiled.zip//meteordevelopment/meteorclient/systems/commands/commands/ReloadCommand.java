package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.utils.network.Capes;
import net.minecraft.class_2172;

public class ReloadCommand extends Command {
   public ReloadCommand() {
      super("reload", "Reloads the config, modules, friends, macros, accounts and capes.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes((context) -> {
         Systems.load();
         Capes.init();
         return 1;
      });
   }
}
