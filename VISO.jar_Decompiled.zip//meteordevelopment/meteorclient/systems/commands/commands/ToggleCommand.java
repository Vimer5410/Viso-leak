package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.util.ArrayList;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.commands.arguments.ModuleArgumentType;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_2172;

public class ToggleCommand extends Command {
   public ToggleCommand() {
      super("toggle", "Toggles a module.", "t");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      ((LiteralArgumentBuilder)builder.then(((LiteralArgumentBuilder)literal("all").then(literal("on").executes((context) -> {
         (new ArrayList(Modules.get().getAll())).forEach((module) -> {
            if (!module.isActive()) {
               module.toggle();
            }

         });
         return 1;
      }))).then(literal("off").executes((context) -> {
         (new ArrayList(Modules.get().getActive())).forEach(Module::toggle);
         return 1;
      })))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)argument("module", ModuleArgumentType.module()).executes((context) -> {
         Module m = ModuleArgumentType.getModule(context, "module");
         m.toggle();
         return 1;
      })).then(literal("on").executes((context) -> {
         Module m = ModuleArgumentType.getModule(context, "module");
         if (!m.isActive()) {
            m.toggle();
         }

         return 1;
      }))).then(literal("off").executes((context) -> {
         Module m = ModuleArgumentType.getModule(context, "module");
         if (m.isActive()) {
            m.toggle();
         }

         return 1;
      })));
   }
}
