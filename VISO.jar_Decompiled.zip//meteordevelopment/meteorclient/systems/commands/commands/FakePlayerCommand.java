package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.player.FakePlayer;
import meteordevelopment.meteorclient.utils.entity.fakeplayer.FakePlayerManager;
import net.minecraft.class_2172;

public class FakePlayerCommand extends Command {
   public FakePlayerCommand() {
      super("fake-player", "Manages fake players that you can use for testing.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(((LiteralArgumentBuilder)literal("spawn").executes((context) -> {
         if (this.active()) {
            FakePlayerManager.add("Meteor on Crack", 36.0F, true);
         }

         return 1;
      })).then(((RequiredArgumentBuilder)argument("name", StringArgumentType.word()).executes((context) -> {
         if (this.active()) {
            FakePlayerManager.add(StringArgumentType.getString(context, "name"), 36.0F, true);
         }

         return 1;
      })).then(((RequiredArgumentBuilder)argument("health", FloatArgumentType.floatArg(0.0F)).executes((context) -> {
         if (this.active()) {
            FakePlayerManager.add(StringArgumentType.getString(context, "name"), FloatArgumentType.getFloat(context, "health"), true);
         }

         return 1;
      })).then(argument("copy-inv", BoolArgumentType.bool()).executes((context) -> {
         if (this.active()) {
            FakePlayerManager.add(StringArgumentType.getString(context, "name"), FloatArgumentType.getFloat(context, "health"), BoolArgumentType.getBool(context, "copy-inv"));
         }

         return 1;
      })))));
      builder.then(literal("clear").executes((context) -> {
         if (this.active()) {
            FakePlayerManager.clear();
         }

         return 1;
      }));
   }

   private boolean active() {
      if (!Modules.get().isActive(FakePlayer.class)) {
         this.error("The FakePlayer module must be enabled.", new Object[0]);
         return false;
      } else {
         return true;
      }
   }
}
