package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.Iterator;
import java.util.function.Function;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.utils.Utils;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2172;
import net.minecraft.class_2194;
import net.minecraft.class_2378;
import net.minecraft.class_2585;
import net.minecraft.class_437;
import net.minecraft.class_490;

public class EnchantCommand extends Command {
   private static final SimpleCommandExceptionType NOT_IN_CREATIVE = new SimpleCommandExceptionType(new class_2585("You must be in creative mode to use this."));
   private static final SimpleCommandExceptionType NOT_HOLDING_ITEM = new SimpleCommandExceptionType(new class_2585("You need to hold some item to enchant."));

   public EnchantCommand() {
      super("enchant", "Enchants the item in your hand. REQUIRES Creative mode.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("one").then(((RequiredArgumentBuilder)argument("enchantment", class_2194.method_9336()).then(literal("level").then(argument("level", IntegerArgumentType.integer()).executes((context) -> {
         this.one(context, (enchantment) -> {
            return (Integer)context.getArgument("level", Integer.class);
         });
         return 1;
      })))).then(literal("max").executes((context) -> {
         this.one(context, class_1887::method_8183);
         return 1;
      }))));
      builder.then(((LiteralArgumentBuilder)literal("all_possible").then(literal("level").then(argument("level", IntegerArgumentType.integer()).executes((context) -> {
         this.all(true, (enchantment) -> {
            return (Integer)context.getArgument("level", Integer.class);
         });
         return 1;
      })))).then(literal("max").executes((context) -> {
         this.all(true, class_1887::method_8183);
         return 1;
      })));
      builder.then(((LiteralArgumentBuilder)literal("all").then(literal("level").then(argument("level", IntegerArgumentType.integer()).executes((context) -> {
         this.all(false, (enchantment) -> {
            return (Integer)context.getArgument("level", Integer.class);
         });
         return 1;
      })))).then(literal("max").executes((context) -> {
         this.all(false, class_1887::method_8183);
         return 1;
      })));
      builder.then(literal("clear").executes((context) -> {
         class_1799 itemStack = this.tryGetItemStack();
         Utils.clearEnchantments(itemStack);
         this.syncItem();
         return 1;
      }));
      builder.then(literal("remove").then(argument("enchantment", class_2194.method_9336()).executes((context) -> {
         class_1799 itemStack = this.tryGetItemStack();
         Utils.removeEnchantment(itemStack, (class_1887)context.getArgument("enchantment", class_1887.class));
         this.syncItem();
         return 1;
      })));
   }

   private void one(CommandContext<class_2172> context, Function<class_1887, Integer> level) throws CommandSyntaxException {
      class_1799 itemStack = this.tryGetItemStack();
      class_1887 enchantment = (class_1887)context.getArgument("enchantment", class_1887.class);
      Utils.addEnchantment(itemStack, enchantment, (Integer)level.apply(enchantment));
      this.syncItem();
   }

   private void all(boolean onlyPossible, Function<class_1887, Integer> level) throws CommandSyntaxException {
      class_1799 itemStack = this.tryGetItemStack();
      Iterator var4 = class_2378.field_11160.iterator();

      while(true) {
         class_1887 enchantment;
         do {
            if (!var4.hasNext()) {
               this.syncItem();
               return;
            }

            enchantment = (class_1887)var4.next();
         } while(onlyPossible && !enchantment.method_8192(itemStack));

         Utils.addEnchantment(itemStack, enchantment, (Integer)level.apply(enchantment));
      }
   }

   private void syncItem() {
      mc.method_1507(new class_490(mc.field_1724));
      mc.method_1507((class_437)null);
   }

   private class_1799 tryGetItemStack() throws CommandSyntaxException {
      if (!mc.field_1724.method_7337()) {
         throw NOT_IN_CREATIVE.create();
      } else {
         class_1799 itemStack = this.getItemStack();
         if (itemStack == null) {
            throw NOT_HOLDING_ITEM.create();
         } else {
            return itemStack;
         }
      }
   }

   private class_1799 getItemStack() {
      class_1799 itemStack = mc.field_1724.method_6047();
      if (itemStack == null) {
         itemStack = mc.field_1724.method_6079();
      }

      return itemStack.method_7960() ? null : itemStack;
   }
}
