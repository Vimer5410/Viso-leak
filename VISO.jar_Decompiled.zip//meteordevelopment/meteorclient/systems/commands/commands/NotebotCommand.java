package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.Notebot;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_156;
import net.minecraft.class_2172;
import net.minecraft.class_2585;
import net.minecraft.class_2596;
import net.minecraft.class_2767;
import net.minecraft.class_3417;

public class NotebotCommand extends Command {
   private static final SimpleCommandExceptionType INVALID_NAME = new SimpleCommandExceptionType(new class_2585("Invalid name."));
   int ticks = -1;
   List<List<Integer>> song = new ArrayList();

   public NotebotCommand() {
      super("notebot", "Allows you load notebot files");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("help").executes((ctx) -> {
         class_156.method_668().method_670("https://github.com/MeteorDevelopment/meteor-client/wiki/Notebot-Guide");
         return 1;
      }));
      builder.then(literal("status").executes((ctx) -> {
         Notebot notebot = (Notebot)Modules.get().get(Notebot.class);
         notebot.printStatus();
         return 1;
      }));
      builder.then(literal("pause").executes((ctx) -> {
         Notebot notebot = (Notebot)Modules.get().get(Notebot.class);
         notebot.pause();
         return 1;
      }));
      builder.then(literal("resume").executes((ctx) -> {
         Notebot notebot = (Notebot)Modules.get().get(Notebot.class);
         notebot.pause();
         return 1;
      }));
      builder.then(literal("stop").executes((ctx) -> {
         Notebot notebot = (Notebot)Modules.get().get(Notebot.class);
         notebot.stop();
         return 1;
      }));
      builder.then(literal("play").then(argument("name", StringArgumentType.greedyString()).executes((ctx) -> {
         Notebot notebot = (Notebot)Modules.get().get(Notebot.class);
         String name = (String)ctx.getArgument("name", String.class);
         if (name != null && !name.equals("")) {
            Path path = MeteorClient.FOLDER.toPath().resolve(String.format("notebot/%s.txt", name));
            if (!path.toFile().exists()) {
               path = MeteorClient.FOLDER.toPath().resolve(String.format("notebot/%s.nbs", name));
            }

            notebot.loadSong(path.toFile());
            return 1;
         } else {
            throw INVALID_NAME.create();
         }
      })));
      builder.then(literal("preview").then(argument("name", StringArgumentType.greedyString()).executes((ctx) -> {
         Notebot notebot = (Notebot)Modules.get().get(Notebot.class);
         String name = (String)ctx.getArgument("name", String.class);
         if (name != null && !name.equals("")) {
            Path path = MeteorClient.FOLDER.toPath().resolve(String.format("notebot/%s.txt", name));
            if (!path.toFile().exists()) {
               path = MeteorClient.FOLDER.toPath().resolve(String.format("notebot/%s.nbs", name));
            }

            notebot.previewSong(path.toFile());
            return 1;
         } else {
            throw INVALID_NAME.create();
         }
      })));
      builder.then(literal("record").then(literal("start").executes((ctx) -> {
         this.ticks = -1;
         this.song.clear();
         MeteorClient.EVENT_BUS.subscribe((Object)this);
         this.info("Recording started", new Object[0]);
         return 1;
      })));
      builder.then(literal("record").then(literal("cancel").executes((ctx) -> {
         MeteorClient.EVENT_BUS.unsubscribe((Object)this);
         this.info("Recording cancelled", new Object[0]);
         return 1;
      })));
      builder.then(literal("record").then(literal("save").then(argument("name", StringArgumentType.greedyString()).executes((ctx) -> {
         String name = (String)ctx.getArgument("name", String.class);
         if (name != null && !name.equals("")) {
            Path path = MeteorClient.FOLDER.toPath().resolve(String.format("notebot/%s.txt", name));
            this.saveRecording(path);
            return 1;
         } else {
            throw INVALID_NAME.create();
         }
      }))));
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (this.ticks != -1) {
         ++this.ticks;
      }
   }

   @EventHandler
   private void onReadPacket(PacketEvent.Receive event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof class_2767) {
         class_2767 sound = (class_2767)var3;
         if (sound.method_11894() == class_3417.field_15114) {
            if (this.ticks == -1) {
               this.ticks = 0;
            }

            this.song.add(Arrays.asList(this.ticks, this.getNote(sound.method_11892())));
         }
      }

   }

   private void saveRecording(Path path) {
      if (this.song.size() < 1) {
         MeteorClient.EVENT_BUS.unsubscribe((Object)this);
      } else {
         try {
            FileWriter file = new FileWriter(path.toFile());

            for(int i = 0; i < this.song.size() - 1; ++i) {
               List<Integer> note = (List)this.song.get(i);
               file.write(String.format("%d:%d\n", note.get(0), note.get(1)));
            }

            List<Integer> note = (List)this.song.get(this.song.size() - 1);
            file.write(String.format("%d:%d", note.get(0), note.get(1)));
            file.close();
            this.info(String.format("Song saved. Length: (highlight)%d(default).", note.get(0)), new Object[0]);
            MeteorClient.EVENT_BUS.unsubscribe((Object)this);
         } catch (IOException var5) {
            this.info("Couldn't create the file.", new Object[0]);
            MeteorClient.EVENT_BUS.unsubscribe((Object)this);
         }

      }
   }

   private int getNote(float pitch) {
      for(int n = 0; n < 25; ++n) {
         if ((double)((float)Math.pow(2.0D, (double)(n - 12) / 12.0D)) - 0.01D < (double)pitch && (double)((float)Math.pow(2.0D, (double)(n - 12) / 12.0D)) + 0.01D > (double)pitch) {
            return n;
         }
      }

      return 0;
   }
}
