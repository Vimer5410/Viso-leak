package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.utils.Utils;
import net.minecraft.class_1799;
import net.minecraft.class_2172;
import net.minecraft.class_2585;

public class PeekCommand extends Command {
   private static final class_1799[] ITEMS = new class_1799[27];
   private static final SimpleCommandExceptionType NOT_HOLDING_SHULKER_BOX = new SimpleCommandExceptionType(new class_2585("You must be holding a storage block with items in it."));

   public PeekCommand() {
      super("peek", "Lets you see what's inside storage block items.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes((context) -> {
         if (Utils.openContainer(mc.field_1724.method_6047(), ITEMS, true)) {
            return 1;
         } else if (Utils.openContainer(mc.field_1724.method_6079(), ITEMS, true)) {
            return 1;
         } else {
            throw NOT_HOLDING_SHULKER_BOX.create();
         }
      });
   }
}
