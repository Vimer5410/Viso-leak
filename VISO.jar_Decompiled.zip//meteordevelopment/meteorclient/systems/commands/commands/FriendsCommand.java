package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.friends.Friend;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_2172;

public class FriendsCommand extends Command {
   public FriendsCommand() {
      super("friends", "Manages friends.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("add").then(argument("friend", FriendsCommand.FriendArgumentType.friend()).executes((context) -> {
         Friend friend = FriendsCommand.FriendArgumentType.getFriend(context, "friend");
         if (Friends.get().add(friend)) {
            this.info("Added (highlight)%s (default)to friends.", new Object[]{friend.name});
         } else {
            this.error("That person is already your friend.", new Object[0]);
         }

         return 1;
      })));
      builder.then(literal("remove").then(argument("friend", FriendsCommand.FriendArgumentType.friend()).executes((context) -> {
         Friend friend = FriendsCommand.FriendArgumentType.getFriend(context, "friend");
         if (Friends.get().remove(friend)) {
            this.info("Removed (highlight)%s (default)from friends.", new Object[]{friend.name});
         } else {
            this.error("That person is not your friend.", new Object[0]);
         }

         return 1;
      })));
      builder.then(literal("list").executes((context) -> {
         this.info("--- Friends ((highlight)%s(default)) ---", new Object[]{Friends.get().count()});
         Friends.get().forEach((friend) -> {
            ChatUtils.info("(highlight)" + friend.name);
         });
         return 1;
      }));
   }

   private static class FriendArgumentType implements ArgumentType<Friend> {
      public static FriendsCommand.FriendArgumentType friend() {
         return new FriendsCommand.FriendArgumentType();
      }

      public Friend parse(StringReader reader) throws CommandSyntaxException {
         return new Friend(reader.readString());
      }

      public static Friend getFriend(CommandContext<?> context, String name) {
         return (Friend)context.getArgument(name, Friend.class);
      }

      public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
         return class_2172.method_9265((Iterable)FriendsCommand.mc.method_1562().method_2880().stream().map((entry) -> {
            return entry.method_2966().getName();
         }).collect(Collectors.toList()), builder);
      }

      public Collection<String> getExamples() {
         return Arrays.asList("seasnail8169", "MineGame159");
      }
   }
}
