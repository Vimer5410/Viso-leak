package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.commands.arguments.ModuleArgumentType;
import meteordevelopment.meteorclient.systems.commands.arguments.SettingArgumentType;
import meteordevelopment.meteorclient.systems.commands.arguments.SettingValueArgumentType;
import net.minecraft.class_2172;

public class SettingCommand extends Command {
   public SettingCommand() {
      super("settings", "Allows you to view and change module settings.", "s");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("module", ModuleArgumentType.module()).then(((RequiredArgumentBuilder)argument("setting", SettingArgumentType.setting()).executes((context) -> {
         Setting<?> setting = SettingArgumentType.getSetting(context);
         ModuleArgumentType.getModule(context, "module").info("Setting (highlight)%s(default) is (highlight)%s(default).", setting.title, setting.get());
         return 1;
      })).then(argument("value", SettingValueArgumentType.value()).executes((context) -> {
         Setting<?> setting = SettingArgumentType.getSetting(context);
         String value = (String)context.getArgument("value", String.class);
         if (setting.parse(value)) {
            ModuleArgumentType.getModule(context, "module").info("Setting (highlight)%s(default) changed to (highlight)%s(default).", setting.title, value);
         }

         return 1;
      }))));
   }
}
