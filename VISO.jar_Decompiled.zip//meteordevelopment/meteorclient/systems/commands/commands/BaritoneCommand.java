package meteordevelopment.meteorclient.systems.commands.commands;

import baritone.api.BaritoneAPI;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.systems.commands.Command;
import net.minecraft.class_2172;

public class BaritoneCommand extends Command {
   public BaritoneCommand() {
      super("baritone", "Executes baritone commands.", "b");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("command", StringArgumentType.greedyString()).executes((context) -> {
         String command = (String)context.getArgument("command", String.class);
         BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute(command);
         return 1;
      }));
   }
}
