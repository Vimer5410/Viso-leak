package meteordevelopment.meteorclient.systems.commands.commands;

import baritone.api.BaritoneAPI;
import baritone.api.pathing.goals.GoalXZ;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.List;
import java.util.Random;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.commands.arguments.ModuleArgumentType;
import meteordevelopment.meteorclient.systems.commands.arguments.PlayerArgumentType;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.swarm.Swarm;
import meteordevelopment.meteorclient.systems.modules.misc.swarm.SwarmConnection;
import meteordevelopment.meteorclient.systems.modules.misc.swarm.SwarmHost;
import meteordevelopment.meteorclient.systems.modules.misc.swarm.SwarmWorker;
import meteordevelopment.meteorclient.systems.modules.world.InfinityMiner;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_1657;
import net.minecraft.class_2172;
import net.minecraft.class_2247;
import net.minecraft.class_2257;
import net.minecraft.class_2585;

public class SwarmCommand extends Command {
   private static final SimpleCommandExceptionType SWARM_NOT_ACTIVE = new SimpleCommandExceptionType(new class_2585("The swarm module must be active to use this command."));

   public SwarmCommand() {
      super("swarm", "Sends commands to connected swarm workers.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("disconnect").executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            swarm.close();
            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      }));
      builder.then(literal("join").then(argument("ip", StringArgumentType.string()).then(argument("port", IntegerArgumentType.integer(0, 65535)).executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (!swarm.isActive()) {
            swarm.toggle();
         }

         swarm.close();
         swarm.mode.set(Swarm.Mode.Worker);
         swarm.worker = new SwarmWorker(StringArgumentType.getString(context, "ip"), IntegerArgumentType.getInteger(context, "port"));
         return 1;
      }))));
      builder.then(literal("connections").executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (!swarm.isActive()) {
            throw SWARM_NOT_ACTIVE.create();
         } else {
            if (swarm.isHost()) {
               if (swarm.host.getConnectionCount() > 0) {
                  ChatUtils.info("--- Swarm Connections (highlight)(%s/%s)(default) ---", swarm.host.getConnectionCount(), swarm.host.getConnections().length);

                  for(int i = 0; i < swarm.host.getConnections().length; ++i) {
                     SwarmConnection connection = swarm.host.getConnections()[i];
                     if (connection != null) {
                        ChatUtils.info("(highlight)Worker %s(default): %s.", i, connection.getConnection());
                     }
                  }
               } else {
                  this.warning("No active connections", new Object[0]);
               }
            } else if (swarm.isWorker()) {
               this.info("Connected to (highlight)%s", new Object[]{swarm.worker.getConnection()});
            }

            return 1;
         }
      }));
      builder.then(((LiteralArgumentBuilder)literal("follow").executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               SwarmHost var10000 = swarm.host;
               String var10001 = context.getInput();
               var10000.sendMessage(var10001 + " " + mc.field_1724.method_5820());
            } else if (swarm.isWorker()) {
               this.error("The follow host command must be used by the host.", new Object[0]);
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })).then(argument("player", PlayerArgumentType.player()).executes((context) -> {
         class_1657 playerEntity = PlayerArgumentType.getPlayer(context);
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker() && playerEntity != null) {
               BaritoneAPI.getProvider().getPrimaryBaritone().getFollowProcess().follow((entity) -> {
                  return entity.method_5820().equalsIgnoreCase(playerEntity.method_5820());
               });
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })));
      builder.then(literal("goto").then(argument("x", IntegerArgumentType.integer()).then(argument("z", IntegerArgumentType.integer()).executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               int x = IntegerArgumentType.getInteger(context, "x");
               int z = IntegerArgumentType.getInteger(context, "z");
               BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoalAndPath(new GoalXZ(x, z));
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      }))));
      builder.then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)literal("infinity-miner").executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               this.runInfinityMiner();
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })).then(((RequiredArgumentBuilder)argument("target", class_2257.method_9653()).executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               ((InfinityMiner)Modules.get().get(InfinityMiner.class)).targetBlocks.set(List.of(((class_2247)context.getArgument("target", class_2247.class)).method_9494().method_26204()));
               this.runInfinityMiner();
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })).then(argument("repair", class_2257.method_9653()).executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               ((InfinityMiner)Modules.get().get(InfinityMiner.class)).targetBlocks.set(List.of(((class_2247)context.getArgument("target", class_2247.class)).method_9494().method_26204()));
               ((InfinityMiner)Modules.get().get(InfinityMiner.class)).repairBlocks.set(List.of(((class_2247)context.getArgument("repair", class_2247.class)).method_9494().method_26204()));
               this.runInfinityMiner();
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })))).then(literal("logout").then(argument("logout", BoolArgumentType.bool()).executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               ((InfinityMiner)Modules.get().get(InfinityMiner.class)).autoLogOut.set(BoolArgumentType.getBool(context, "logout"));
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })))).then(literal("walkhome").then(argument("walkhome", BoolArgumentType.bool()).executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               ((InfinityMiner)Modules.get().get(InfinityMiner.class)).autoWalkHome.set(BoolArgumentType.getBool(context, "walkhome"));
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      }))));
      builder.then(literal("mine").then(argument("block", class_2257.method_9653()).executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               swarm.worker.target = ((class_2247)context.getArgument("block", class_2247.class)).method_9494().method_26204();
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })));
      builder.then(literal("toggle").then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)argument("module", ModuleArgumentType.module()).executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               Module module = ModuleArgumentType.getModule(context, "module");
               module.toggle();
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })).then(literal("on").executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               Module m = ModuleArgumentType.getModule(context, "module");
               if (!m.isActive()) {
                  m.toggle();
               }
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      }))).then(literal("off").executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               Module m = ModuleArgumentType.getModule(context, "module");
               if (m.isActive()) {
                  m.toggle();
               }
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      }))));
      builder.then(((LiteralArgumentBuilder)literal("scatter").executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               this.scatter(100);
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })).then(argument("radius", IntegerArgumentType.integer()).executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               this.scatter(IntegerArgumentType.getInteger(context, "radius"));
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })));
      builder.then(literal("stop").executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().cancelEverything();
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      }));
      builder.then(literal("exec").then(argument("command", StringArgumentType.greedyString()).executes((context) -> {
         Swarm swarm = (Swarm)Modules.get().get(Swarm.class);
         if (swarm.isActive()) {
            if (swarm.isHost()) {
               swarm.host.sendMessage(context.getInput());
            } else if (swarm.isWorker()) {
               mc.field_1724.method_3142(StringArgumentType.getString(context, "command"));
            }

            return 1;
         } else {
            throw SWARM_NOT_ACTIVE.create();
         }
      })));
   }

   private void runInfinityMiner() {
      InfinityMiner infinityMiner = (InfinityMiner)Modules.get().get(InfinityMiner.class);
      if (infinityMiner.isActive()) {
         infinityMiner.toggle();
      }

      if (!infinityMiner.isActive()) {
         infinityMiner.toggle();
      }

   }

   private void scatter(int radius) {
      Random random = new Random();
      double a = random.nextDouble() * 2.0D * 3.141592653589793D;
      double r = (double)radius * Math.sqrt(random.nextDouble());
      double x = mc.field_1724.method_23317() + r * Math.cos(a);
      double z = mc.field_1724.method_23321() + r * Math.sin(a);
      BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().cancelEverything();
      BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoalAndPath(new GoalXZ((int)x, (int)z));
   }
}
