package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Iterator;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.utils.misc.MeteorStarscript;
import meteordevelopment.starscript.Script;
import meteordevelopment.starscript.compiler.Compiler;
import meteordevelopment.starscript.compiler.Parser;
import meteordevelopment.starscript.utils.Error;
import meteordevelopment.starscript.utils.StarscriptError;
import net.minecraft.class_2172;
import net.minecraft.class_2797;

public class SayCommand extends Command {
   public SayCommand() {
      super("say", "Sends messages in chat.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("message", StringArgumentType.greedyString()).executes((context) -> {
         String msg = (String)context.getArgument("message", String.class);
         Parser.Result result = Parser.parse(msg);
         if (result.hasErrors()) {
            Iterator var3 = result.errors.iterator();

            while(var3.hasNext()) {
               Error error = (Error)var3.next();
               MeteorStarscript.printChatError(error);
            }
         } else {
            Script script = Compiler.compile(result);

            try {
               String message = MeteorStarscript.ss.run(script);
               mc.method_1562().method_2883(new class_2797(message));
            } catch (StarscriptError var5) {
               MeteorStarscript.printChatError(var5);
            }
         }

         return 1;
      }));
   }
}
