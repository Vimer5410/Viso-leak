package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Iterator;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.commands.arguments.WaypointArgumentType;
import meteordevelopment.meteorclient.systems.waypoints.Waypoint;
import meteordevelopment.meteorclient.systems.waypoints.Waypoints;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import net.minecraft.class_124;
import net.minecraft.class_2172;

public class WaypointCommand extends Command {
   public WaypointCommand() {
      super("waypoint", "Manages waypoints.", "wp");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("list").executes((context) -> {
         if (Waypoints.get().waypoints.isEmpty()) {
            this.error("No created waypoints.", new Object[0]);
         } else {
            this.info(class_124.field_1068 + "Created Waypoints:", new Object[0]);
            Iterator var2 = Waypoints.get().iterator();

            while(var2.hasNext()) {
               Waypoint waypoint = (Waypoint)var2.next();
               this.info("Name: (highlight)'%s'(default), Dimension: (highlight)%s(default), Pos: (highlight)%s(default)", new Object[]{waypoint.name, waypoint.actualDimension, this.waypointPos(waypoint)});
            }
         }

         return 1;
      }));
      builder.then(literal("get").then(argument("waypoint", WaypointArgumentType.waypoint()).executes((context) -> {
         Waypoint waypoint = WaypointArgumentType.getWaypoint(context, "waypoint");
         this.info("Name: " + class_124.field_1068 + waypoint.name, new Object[0]);
         this.info("Actual Dimension: " + class_124.field_1068 + waypoint.actualDimension, new Object[0]);
         class_124 var10001 = class_124.field_1068;
         this.info("Position: " + var10001 + this.waypointFullPos(waypoint), new Object[0]);
         this.info("Visible: " + (waypoint.visible ? class_124.field_1060 + "True" : class_124.field_1061 + "False"), new Object[0]);
         return 1;
      })));
      builder.then(literal("add").then(argument("waypoint", StringArgumentType.greedyString()).executes((context) -> {
         if (mc.field_1724 == null) {
            return -1;
         } else {
            Waypoint waypoint = new Waypoint() {
               {
                  this.name = StringArgumentType.getString(context, "waypoint");
                  this.actualDimension = PlayerUtils.getDimension();
                  this.x = (int)WaypointCommand.mc.field_1724.method_23317();
                  this.y = (int)WaypointCommand.mc.field_1724.method_23318() + 1;
                  this.z = (int)WaypointCommand.mc.field_1724.method_23321();
                  switch(this.actualDimension) {
                  case Overworld:
                     this.overworld = true;
                     break;
                  case Nether:
                     this.nether = true;
                     break;
                  case End:
                     this.end = true;
                  }

               }
            };
            Waypoints.get().add(waypoint);
            Waypoints.get().save();
            this.info("Created waypoint with name: (highlight)%s(default)", new Object[]{waypoint.name});
            return 1;
         }
      })));
      builder.then(literal("delete").then(argument("waypoint", WaypointArgumentType.waypoint()).executes((context) -> {
         Waypoint waypoint = WaypointArgumentType.getWaypoint(context, "waypoint");
         this.info("The waypoint (highlight)'%s'(default) has been deleted.", new Object[]{waypoint.name});
         Waypoints.get().remove(waypoint);
         Waypoints.get().save();
         return 1;
      })));
      builder.then(literal("toggle").then(argument("waypoint", WaypointArgumentType.waypoint()).executes((context) -> {
         Waypoint waypoint = WaypointArgumentType.getWaypoint(context, "waypoint");
         waypoint.visible = !waypoint.visible;
         Waypoints.get().save();
         return 1;
      })));
   }

   private String waypointPos(Waypoint waypoint) {
      return "X: " + waypoint.x + " Z: " + waypoint.z;
   }

   private String waypointFullPos(Waypoint waypoint) {
      return "X: " + waypoint.x + ", Y: " + waypoint.y + ", Z: " + waypoint.z;
   }
}
