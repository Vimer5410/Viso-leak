package meteordevelopment.meteorclient.systems.commands.commands;

import com.google.common.reflect.TypeToken;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.commands.arguments.PlayerListEntryArgumentType;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.network.Http;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2554;
import net.minecraft.class_2558;
import net.minecraft.class_2568;
import net.minecraft.class_2585;
import net.minecraft.class_5251;
import net.minecraft.class_640;
import net.minecraft.class_2558.class_2559;
import net.minecraft.class_2568.class_5247;

public class NameHistoryCommand extends Command {
   private static final Type RESPONSE_TYPE = (new TypeToken<List<NameHistoryCommand.NameHistoryObject>>() {
   }).getType();

   public NameHistoryCommand() {
      super("name-history", "Provides a list of a players previous names from the Mojang api.", "history", "names");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("player", PlayerListEntryArgumentType.playerListEntry()).executes((context) -> {
         MeteorExecutor.execute(() -> {
            class_640 lookUpTarget = PlayerListEntryArgumentType.getPlayerListEntry(context);
            UUID uuid = lookUpTarget.method_2966().getId();
            String var10000 = this.formatUUID(uuid);
            List<NameHistoryCommand.NameHistoryObject> nameHistoryObjects = (List)Http.get("https://api.mojang.com/user/profiles/" + var10000 + "/names").sendJson(RESPONSE_TYPE);
            if (nameHistoryObjects != null && !nameHistoryObjects.isEmpty()) {
               String name = lookUpTarget.method_2966().getName();
               class_2554 initial = new class_2585(name);
               initial.method_10852(new class_2585(name.endsWith("s") ? "'" : "'s"));
               Color nameColor = PlayerUtils.getPlayerColor(mc.field_1687.method_18470(uuid), Utils.WHITE);
               initial.method_10862(initial.method_10866().method_27703(new class_5251(nameColor.getPacked())).method_10958(new class_2558(class_2559.field_11749, "https://namemc.com/search?q=" + name)).method_10949(new class_2568(class_5247.field_24342, (new class_2585("View on NameMC")).method_27692(class_124.field_1054).method_27692(class_124.field_1056))));
               this.info(initial.method_10852((new class_2585(" Username History:")).method_27692(class_124.field_1080)));

               class_2585 nameText;
               for(Iterator var8 = nameHistoryObjects.iterator(); var8.hasNext(); ChatUtils.sendMsg(nameText)) {
                  NameHistoryCommand.NameHistoryObject nameHistoryObject = (NameHistoryCommand.NameHistoryObject)var8.next();
                  nameText = new class_2585(nameHistoryObject.name);
                  nameText.method_27692(class_124.field_1075);
                  if (nameHistoryObject.changedToAt != 0L) {
                     class_2554 changed = new class_2585("Changed at: ");
                     changed.method_27692(class_124.field_1080);
                     Date date = new Date(nameHistoryObject.changedToAt);
                     DateFormat formatter = new SimpleDateFormat("hh:mm:ss, dd/MM/yyyy");
                     changed.method_10852((new class_2585(formatter.format(date))).method_27692(class_124.field_1068));
                     nameText.method_10862(nameText.method_10866().method_10949(new class_2568(class_5247.field_24342, changed)));
                  }
               }

            } else {
               this.error("There was an error fetching that users name history.", new Object[0]);
            }
         });
         return 1;
      }));
   }

   private String formatUUID(UUID uuid) {
      return uuid.toString().replace("-", "");
   }

   private static class NameHistoryObject {
      String name;
      long changedToAt;
   }
}
