package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.suggestion.Suggestions;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import joptsimple.internal.Strings;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.utils.world.TickRate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1132;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2554;
import net.minecraft.class_2558;
import net.minecraft.class_2568;
import net.minecraft.class_2585;
import net.minecraft.class_2639;
import net.minecraft.class_2805;
import net.minecraft.class_637;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_2558.class_2559;
import net.minecraft.class_2568.class_5247;

public class ServerCommand extends Command {
   private static final List<String> ANTICHEAT_LIST = Arrays.asList("nocheatplus", "negativity", "warden", "horizon", "illegalstack", "coreprotect", "exploitsx");
   private Integer ticks = 0;

   public ServerCommand() {
      super("server", "Prints server information");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes((context) -> {
         this.basicInfo();
         return 1;
      });
      builder.then(literal("info").executes((ctx) -> {
         this.basicInfo();
         return 1;
      }));
      builder.then(literal("plugins").executes((ctx) -> {
         this.ticks = 0;
         MeteorClient.EVENT_BUS.subscribe((Object)this);
         mc.field_1724.field_3944.method_2883(new class_2805(0, "/"));
         return 1;
      }));
      builder.then(literal("tps").executes((ctx) -> {
         float tps = TickRate.INSTANCE.getTickRate();
         class_124 color;
         if (tps > 17.0F) {
            color = class_124.field_1060;
         } else if (tps > 12.0F) {
            color = class_124.field_1054;
         } else {
            color = class_124.field_1061;
         }

         this.info("Current TPS: %s%.2f(default).", new Object[]{color, tps});
         return 1;
      }));
   }

   private void basicInfo() {
      if (mc.method_1496()) {
         class_1132 server = mc.method_1576();
         this.info("Singleplayer", new Object[0]);
         if (server != null) {
            this.info("Version: %s", new Object[]{server.method_3827()});
         }

      } else {
         class_642 server = mc.method_1558();
         if (server == null) {
            this.info("Couldn't obtain any server information.", new Object[0]);
         } else {
            String ipv4 = "";

            try {
               ipv4 = InetAddress.getByName(server.field_3761).getHostAddress();
            } catch (UnknownHostException var6) {
            }

            class_2585 ipText;
            if (ipv4.isEmpty()) {
               ipText = new class_2585(class_124.field_1080 + server.field_3761);
               ipText.method_10862(ipText.method_10866().method_10958(new class_2558(class_2559.field_21462, server.field_3761)).method_10949(new class_2568(class_5247.field_24342, new class_2585("Copy to clipboard"))));
            } else {
               ipText = new class_2585(class_124.field_1080 + server.field_3761);
               ipText.method_10862(ipText.method_10866().method_10958(new class_2558(class_2559.field_21462, server.field_3761)).method_10949(new class_2568(class_5247.field_24342, new class_2585("Copy to clipboard"))));
               class_2554 ipv4Text = new class_2585(String.format("%s (%s)", class_124.field_1080, ipv4));
               ipv4Text.method_10862(ipText.method_10866().method_10958(new class_2558(class_2559.field_21462, ipv4)).method_10949(new class_2568(class_5247.field_24342, new class_2585("Copy to clipboard"))));
               ipText.method_10852(ipv4Text);
            }

            this.info((new class_2585(String.format("%sIP: ", class_124.field_1080))).method_10852(ipText));
            this.info("Port: %d", new Object[]{class_639.method_2950(server.field_3761).method_2954()});
            this.info("Type: %s", new Object[]{mc.field_1724.method_3135() != null ? mc.field_1724.method_3135() : "unknown"});
            this.info("Motd: %s", new Object[]{server.field_3757 != null ? server.field_3757.getString() : "unknown"});
            this.info("Version: %s", new Object[]{server.field_3760.getString()});
            this.info("Protocol version: %d", new Object[]{server.field_3756});
            this.info("Difficulty: %s", new Object[]{mc.field_1687.method_8407().method_5463().getString()});
            class_637 cmdSource = mc.method_1562().method_2875();

            int permission_level;
            for(permission_level = 5; permission_level > 0 && !cmdSource.method_9259(permission_level); --permission_level) {
            }

            this.info("Permission level: %d", new Object[]{permission_level});
         }
      }
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      Integer var2 = this.ticks;
      this.ticks = this.ticks + 1;
      if (this.ticks >= 5000) {
         this.error("Plugins check timed out", new Object[0]);
         MeteorClient.EVENT_BUS.unsubscribe((Object)this);
         this.ticks = 0;
      }

   }

   @EventHandler
   private void onReadPacket(PacketEvent.Receive event) {
      try {
         if (event.packet instanceof class_2639) {
            class_2639 packet = (class_2639)event.packet;
            List<String> plugins = new ArrayList();
            Suggestions matches = packet.method_11397();
            if (matches == null) {
               this.error("Invalid Packet.", new Object[0]);
               return;
            }

            Iterator var5 = matches.getList().iterator();

            while(var5.hasNext()) {
               Suggestion yes = (Suggestion)var5.next();
               String[] command = yes.getText().split(":");
               if (command.length > 1) {
                  String pluginName = command[0].replace("/", "");
                  if (!plugins.contains(pluginName)) {
                     plugins.add(pluginName);
                  }
               }
            }

            Collections.sort(plugins);

            for(int i = 0; i < plugins.size(); ++i) {
               plugins.set(i, this.formatName((String)plugins.get(i)));
            }

            if (!plugins.isEmpty()) {
               this.info("Plugins (%d): %s ", new Object[]{plugins.size(), Strings.join((String[])plugins.toArray(new String[0]), ", ")});
            } else {
               this.error("No plugins found.", new Object[0]);
            }

            this.ticks = 0;
            MeteorClient.EVENT_BUS.unsubscribe((Object)this);
         }
      } catch (Exception var9) {
         this.error("An error occurred while trying to find plugins", new Object[0]);
         this.ticks = 0;
         MeteorClient.EVENT_BUS.unsubscribe((Object)this);
      }

   }

   private String formatName(String name) {
      if (ANTICHEAT_LIST.contains(name)) {
         return String.format("%s%s(default)", class_124.field_1061, name);
      } else {
         return !name.contains("exploit") && !name.contains("cheat") && !name.contains("illegal") ? String.format("(highlight)%s(default)", name) : String.format("%s%s(default)", class_124.field_1061, name);
      }
   }
}
