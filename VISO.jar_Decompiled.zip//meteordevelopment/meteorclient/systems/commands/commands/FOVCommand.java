package meteordevelopment.meteorclient.systems.commands.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.systems.commands.Command;
import net.minecraft.class_2172;

public class FOVCommand extends Command {
   public FOVCommand() {
      super("fov", "Changes your FOV.");
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("fov", IntegerArgumentType.integer(0, 180)).executes((context) -> {
         mc.field_1690.field_1826 = (double)(Integer)context.getArgument("fov", Integer.class);
         return 1;
      }));
   }
}
