package meteordevelopment.meteorclient.gui.screens;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WidgetScreen;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.modules.HudElement;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_2487;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public class HudEditorScreen extends WidgetScreen {
   private final Color HOVER_BG_COLOR = new Color(200, 200, 200, 50);
   private final Color HOVER_OL_COLOR = new Color(200, 200, 200, 200);
   private final Color INACTIVE_BG_COLOR = new Color(200, 25, 25, 50);
   private final Color INACTIVE_OL_COLOR = new Color(200, 25, 25, 200);
   private final HUD hud = (HUD)Systems.get(HUD.class);
   private boolean selecting;
   private double mouseStartX;
   private double mouseStartY;
   private boolean dragging;
   private boolean dragged;
   private double lastMouseX;
   private double lastMouseY;
   private HudElement hoveredModule;
   private final List<HudElement> selectedElements = new ArrayList();

   public HudEditorScreen(GuiTheme theme, class_437 parent) {
      super(theme, "Hud Editor");
   }

   public void initWidgets() {
   }

   public boolean toClipboard() {
      return NbtUtils.toClipboard(this.hud.getName(), this.hud.toTag());
   }

   public boolean fromClipboard() {
      class_2487 clipboard = NbtUtils.fromClipboard(this.hud.toTag());
      if (clipboard != null) {
         this.hud.fromTag(clipboard);
         return true;
      } else {
         return false;
      }
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      if (this.hoveredModule != null) {
         if (button == 1) {
            if (!this.selectedElements.isEmpty()) {
               this.selectedElements.clear();
            }

            MeteorClient.mc.method_1507(new HudElementScreen(this.theme, this.hoveredModule));
         } else {
            this.dragging = true;
            this.dragged = false;
            if (!this.selectedElements.contains(this.hoveredModule)) {
               this.selectedElements.clear();
               this.selectedElements.add(this.hoveredModule);
            }
         }

         return true;
      } else {
         double s = MeteorClient.mc.method_22683().method_4495();
         this.selecting = true;
         this.mouseStartX = mouseX * s;
         this.mouseStartY = mouseY * s;
         if (!this.selectedElements.isEmpty()) {
            this.selectedElements.clear();
            return true;
         } else {
            return false;
         }
      }
   }

   private boolean isInSelection(double mouseX, double mouseY, double x, double y) {
      double sx;
      double sw;
      if (mouseX >= this.mouseStartX) {
         sx = this.mouseStartX;
         sw = mouseX - this.mouseStartX;
      } else {
         sx = mouseX;
         sw = this.mouseStartX - mouseX;
      }

      double sy;
      double sh;
      if (mouseY >= this.mouseStartY) {
         sy = this.mouseStartY;
         sh = mouseY - this.mouseStartY;
      } else {
         sy = mouseY;
         sh = this.mouseStartY - mouseY;
      }

      return x >= sx && x <= sx + sw && y >= sy && y <= sy + sh;
   }

   public void method_16014(double mouseX, double mouseY) {
      double s = MeteorClient.mc.method_22683().method_4495();
      mouseX *= s;
      mouseY *= s;
      Iterator var7;
      HudElement module;
      double x;
      double y;
      double w;
      double h;
      if (this.selecting) {
         this.selectedElements.clear();
         var7 = this.hud.elements.iterator();

         label165:
         while(true) {
            do {
               if (!var7.hasNext()) {
                  break label165;
               }

               module = (HudElement)var7.next();
               x = module.box.getX();
               y = module.box.getY();
               w = module.box.width;
               h = module.box.height;
            } while(!this.isInSelection(mouseX, mouseY, x, y) && !this.isInSelection(mouseX, mouseY, x + w, y) && !this.isInSelection(mouseX, mouseY, x, y + h) && !this.isInSelection(mouseX, mouseY, x + w, y + h));

            this.selectedElements.add(module);
         }
      } else if (this.dragging) {
         var7 = this.selectedElements.iterator();

         while(var7.hasNext()) {
            module = (HudElement)var7.next();
            module.box.addPos(mouseX - this.lastMouseX, mouseY - this.lastMouseY);
         }

         double r = (double)(Integer)this.hud.snappingRange.get();
         if (r > 0.0D) {
            x = Double.MAX_VALUE;
            y = Double.MAX_VALUE;
            w = 0.0D;
            h = 0.0D;

            Iterator var17;
            HudElement element;
            for(var17 = this.selectedElements.iterator(); var17.hasNext(); y = Math.min(y, element.box.getY())) {
               element = (HudElement)var17.next();
               x = Math.min(x, element.box.getX());
            }

            for(var17 = this.selectedElements.iterator(); var17.hasNext(); h = Math.max(h, element.box.getY() - y + element.box.height)) {
               element = (HudElement)var17.next();
               w = Math.max(w, element.box.getX() - x + element.box.width);
            }

            boolean movedX = false;
            boolean movedY = false;
            Iterator var19 = this.hud.elements.iterator();

            label129:
            do {
               HudElement element;
               do {
                  if (!var19.hasNext()) {
                     break label129;
                  }

                  element = (HudElement)var19.next();
               } while(this.selectedElements.contains(element));

               double eX = element.box.getX();
               double eY = element.box.getY();
               double eW = element.box.width;
               double eH = element.box.height;
               boolean isHorizontallyIn = this.isPointBetween(x, w, eX) || this.isPointBetween(x, w, eX + eW) || this.isPointBetween(eX, eW, x) || this.isPointBetween(eX, eW, x + w);
               boolean isVerticallyIn = this.isPointBetween(y, h, eY) || this.isPointBetween(y, h, eY + eH) || this.isPointBetween(eY, eH, y) || this.isPointBetween(eY, eH, y + h);
               double moveX = 0.0D;
               double moveY = 0.0D;
               double y2;
               double eY2;
               if (!movedX && isVerticallyIn) {
                  y2 = x + w;
                  eY2 = eX + eW;
                  if (Math.abs(eX - x) < r) {
                     moveX = eX - x;
                  } else if (Math.abs(eY2 - y2) <= r) {
                     moveX = eY2 - y2;
                  } else if (Math.abs(eY2 - x) <= r) {
                     moveX = eY2 - x;
                  } else if (Math.abs(eX - y2) <= r) {
                     moveX = eX - y2;
                  }
               }

               if (!movedY && isHorizontallyIn) {
                  y2 = y + h;
                  eY2 = eY + eH;
                  if (Math.abs(eY - y) <= r) {
                     moveY = eY - y;
                  } else if (Math.abs(eY2 - y2) <= r) {
                     moveY = eY2 - y2;
                  } else if (Math.abs(eY2 - y) <= r) {
                     moveY = eY2 - y;
                  } else if (Math.abs(eY - y2) <= r) {
                     moveY = eY - y2;
                  }
               }

               if (moveX != 0.0D || moveY != 0.0D) {
                  Iterator var42 = this.selectedElements.iterator();

                  while(var42.hasNext()) {
                     HudElement e = (HudElement)var42.next();
                     e.box.addPos(moveX, moveY);
                  }

                  if (moveX != 0.0D) {
                     movedX = true;
                  }

                  if (moveY != 0.0D) {
                     movedY = true;
                  }
               }
            } while(!movedX || !movedY);

            this.dragged = true;
         }
      }

      this.lastMouseX = mouseX;
      this.lastMouseY = mouseY;
   }

   private boolean isPointBetween(double start, double size, double point) {
      return point >= start && point <= start + size;
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      if (this.dragging) {
         this.dragging = false;
         if (!this.dragged && !this.selectedElements.isEmpty()) {
            this.selectedElements.forEach(HudElement::toggle);
            this.selectedElements.clear();
         }

         if (this.selectedElements.size() <= 1) {
            this.selectedElements.clear();
         }

         return true;
      } else if (this.selecting) {
         this.selecting = false;
         return true;
      } else {
         return false;
      }
   }

   public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
      if (!Utils.canUpdate()) {
         this.method_25420(matrices);
      }

      double s = MeteorClient.mc.method_22683().method_4495();
      mouseX = (int)((double)mouseX * s);
      mouseY = (int)((double)mouseY * s);
      Utils.unscaledProjection();
      if (!Utils.canUpdate()) {
         this.hud.render(delta, (hudElement) -> {
            return true;
         });
      }

      Renderer2D.COLOR.begin();
      Iterator var7 = this.hud.elements.iterator();

      HudElement module;
      while(var7.hasNext()) {
         module = (HudElement)var7.next();
         if (!module.active) {
            this.renderElement(module, this.INACTIVE_BG_COLOR, this.INACTIVE_OL_COLOR);
         }
      }

      var7 = this.selectedElements.iterator();

      while(var7.hasNext()) {
         module = (HudElement)var7.next();
         this.renderElement(module, this.HOVER_BG_COLOR, this.HOVER_OL_COLOR);
      }

      if (!this.dragging) {
         this.hoveredModule = null;
         var7 = this.hud.elements.iterator();

         while(var7.hasNext()) {
            module = (HudElement)var7.next();
            if (module.box.isOver((double)mouseX, (double)mouseY)) {
               if (!this.selectedElements.contains(module)) {
                  this.renderElement(module, this.HOVER_BG_COLOR, this.HOVER_OL_COLOR);
               }

               this.hoveredModule = module;
               break;
            }
         }

         if (this.selecting) {
            this.renderQuad(this.mouseStartX, this.mouseStartY, (double)mouseX - this.mouseStartX, (double)mouseY - this.mouseStartY, this.HOVER_BG_COLOR, this.HOVER_OL_COLOR);
         }
      }

      Renderer2D.COLOR.render(new class_4587());
      Utils.scaledProjection();
      this.runAfterRenderTasks();
   }

   private void renderElement(HudElement module, Color bgColor, Color olColor) {
      this.renderQuad(module.box.getX(), module.box.getY(), module.box.width, module.box.height, bgColor, olColor);
   }

   private void renderQuad(double x, double y, double w, double h, Color bgColor, Color olColor) {
      Renderer2D.COLOR.quad(x, y, w, h, bgColor);
      Renderer2D.COLOR.quad(x - 1.0D, y - 1.0D, w + 2.0D, 1.0D, olColor);
      Renderer2D.COLOR.quad(x - 1.0D, y + h - 1.0D, w + 2.0D, 1.0D, olColor);
      Renderer2D.COLOR.quad(x - 1.0D, y, 1.0D, h, olColor);
      Renderer2D.COLOR.quad(x + w, y, 1.0D, h, olColor);
   }
}
