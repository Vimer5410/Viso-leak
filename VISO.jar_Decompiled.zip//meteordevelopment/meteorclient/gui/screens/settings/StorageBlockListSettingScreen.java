package meteordevelopment.meteorclient.gui.screens.settings;

import java.util.Collection;
import java.util.List;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.StorageBlockListSetting;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2591;

public class StorageBlockListSettingScreen extends LeftRightListSettingScreen<class_2591<?>> {
   public StorageBlockListSettingScreen(GuiTheme theme, Setting<List<class_2591<?>>> setting) {
      super(theme, "Select Storage Blocks", setting, (Collection)setting.get(), StorageBlockListSetting.REGISTRY);
   }

   protected WWidget getValueWidget(class_2591<?> value) {
      class_1792 item = class_1802.field_8077;
      if (value == class_2591.field_11903) {
         item = class_1802.field_8732;
      } else if (value == class_2591.field_11914) {
         item = class_1802.field_8106;
      } else if (value == class_2591.field_11891) {
         item = class_1802.field_8247;
      } else if (value == class_2591.field_11901) {
         item = class_1802.field_8466;
      } else if (value == class_2591.field_11887) {
         item = class_1802.field_8357;
      } else if (value == class_2591.field_11899) {
         item = class_1802.field_8878;
      } else if (value == class_2591.field_11888) {
         item = class_1802.field_8239;
      } else if (value == class_2591.field_11896) {
         item = class_1802.field_8545;
      } else if (value == class_2591.field_16411) {
         item = class_1802.field_16307;
      } else if (value == class_2591.field_16414) {
         item = class_1802.field_16309;
      } else if (value == class_2591.field_16415) {
         item = class_1802.field_16306;
      }

      return this.theme.itemWithLabel(item.method_7854(), this.getValueName(value));
   }

   protected String getValueName(class_2591<?> value) {
      String name = "Unknown";
      if (value == class_2591.field_11903) {
         name = "Furnace";
      } else if (value == class_2591.field_11914) {
         name = "Chest";
      } else if (value == class_2591.field_11891) {
         name = "Trapped Chest";
      } else if (value == class_2591.field_11901) {
         name = "Ender Chest";
      } else if (value == class_2591.field_11887) {
         name = "Dispenser";
      } else if (value == class_2591.field_11899) {
         name = "Dropper";
      } else if (value == class_2591.field_11888) {
         name = "Hopper";
      } else if (value == class_2591.field_11896) {
         name = "Shulker Box";
      } else if (value == class_2591.field_16411) {
         name = "Barrel";
      } else if (value == class_2591.field_16414) {
         name = "Smoker";
      } else if (value == class_2591.field_16415) {
         name = "Blast Furnace";
      }

      return name;
   }
}
