package meteordevelopment.meteorclient.gui.screens.settings;

import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.PotionSetting;
import meteordevelopment.meteorclient.utils.misc.MyPotion;

public class PotionSettingScreen extends WindowScreen {
   private final PotionSetting setting;

   public PotionSettingScreen(GuiTheme theme, PotionSetting setting) {
      super(theme, "Select Potion");
      this.setting = setting;
   }

   public void initWidgets() {
      WTable table = (WTable)this.add(this.theme.table()).expandX().widget();
      MyPotion[] var2 = MyPotion.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         MyPotion potion = var2[var4];
         table.add(this.theme.itemWithLabel(potion.potion, potion.potion.method_7964().getString()));
         WButton select = (WButton)table.add(this.theme.button("Select")).widget();
         select.action = () -> {
            this.setting.set(potion);
            this.method_25419();
         };
         table.row();
      }

   }
}
