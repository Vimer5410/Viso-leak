package meteordevelopment.meteorclient.gui.screens.settings;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WIntEdit;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.utils.misc.Names;
import net.minecraft.class_1291;
import org.apache.commons.lang3.StringUtils;

public class StatusEffectAmplifierMapSettingScreen extends WindowScreen {
   private final Setting<Object2IntMap<class_1291>> setting;
   private WTable table;
   private WTextBox filter;
   private String filterText = "";

   public StatusEffectAmplifierMapSettingScreen(GuiTheme theme, Setting<Object2IntMap<class_1291>> setting) {
      super(theme, "Modify Amplifiers");
      this.setting = setting;
      this.initWidgets();
   }

   public void initWidgets() {
      this.filter = (WTextBox)this.add(this.theme.textBox("")).minWidth(400.0D).expandX().widget();
      this.filter.setFocused(true);
      this.filter.action = () -> {
         this.filterText = this.filter.get().trim();
         this.table.clear();
         this.initTable();
      };
      this.table = (WTable)this.add(this.theme.table()).expandX().widget();
      this.initTable();
   }

   private void initTable() {
      List<class_1291> statusEffects = new ArrayList(((Object2IntMap)this.setting.get()).keySet());
      statusEffects.sort(Comparator.comparing(Names::get));
      Iterator var2 = statusEffects.iterator();

      while(var2.hasNext()) {
         class_1291 statusEffect = (class_1291)var2.next();
         String name = Names.get(statusEffect);
         if (StringUtils.containsIgnoreCase(name, this.filterText)) {
            this.table.add(this.theme.label(name)).expandCellX();
            WIntEdit level = this.theme.intEdit(((Object2IntMap)this.setting.get()).getInt(statusEffect), 0, Integer.MAX_VALUE, true);
            level.action = () -> {
               ((Object2IntMap)this.setting.get()).put(statusEffect, level.get());
               this.setting.onChanged();
            };
            this.table.add(level).minWidth(50.0D);
            this.table.row();
         }
      }

   }
}
