package meteordevelopment.meteorclient.gui.screens;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.widgets.WLabel;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WDropdown;
import meteordevelopment.meteorclient.gui.widgets.input.WIntEdit;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WMinus;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.proxies.Proxies;
import meteordevelopment.meteorclient.systems.proxies.Proxy;
import meteordevelopment.meteorclient.systems.proxies.ProxyType;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;

public class ProxiesScreen extends WindowScreen {
   private final List<WCheckbox> checkboxes = new ArrayList();
   private boolean dirty;

   public ProxiesScreen(GuiTheme theme) {
      super(theme, "Proxies");
   }

   protected void openEditProxyScreen(Proxy proxy) {
      MeteorClient.mc.method_1507(new ProxiesScreen.EditProxyScreen(this.theme, proxy));
   }

   protected void method_25426() {
      super.method_25426();
      if (this.dirty) {
         this.reload();
         this.dirty = false;
      }

   }

   public void initWidgets() {
      WTable table = (WTable)this.add(this.theme.table()).expandX().widget();
      int i = 0;

      for(Iterator var3 = Proxies.get().iterator(); var3.hasNext(); ++i) {
         Proxy proxy = (Proxy)var3.next();
         WCheckbox enabled = (WCheckbox)table.add(this.theme.checkbox(proxy.enabled)).widget();
         this.checkboxes.add(enabled);
         enabled.action = () -> {
            boolean checked = enabled.checked;
            Proxies.get().setEnabled(proxy, checked);

            WCheckbox checkbox;
            for(Iterator var5 = this.checkboxes.iterator(); var5.hasNext(); checkbox.checked = false) {
               checkbox = (WCheckbox)var5.next();
            }

            ((WCheckbox)this.checkboxes.get(i)).checked = checked;
         };
         WLabel name = (WLabel)table.add(this.theme.label(proxy.name)).widget();
         name.color = this.theme.textColor();
         WLabel type = (WLabel)table.add(this.theme.label("(" + proxy.type + ")")).widget();
         type.color = this.theme.textSecondaryColor();
         WHorizontalList ipList = (WHorizontalList)table.add(this.theme.horizontalList()).expandCellX().widget();
         ipList.spacing = 0.0D;
         ipList.add(this.theme.label(proxy.address));
         ((WLabel)ipList.add(this.theme.label(":")).widget()).color = this.theme.textSecondaryColor();
         ipList.add(this.theme.label(Integer.toString(proxy.port)));
         WButton edit = (WButton)table.add(this.theme.button(GuiRenderer.EDIT)).widget();
         edit.action = () -> {
            this.openEditProxyScreen(proxy);
         };
         WMinus remove = (WMinus)table.add(this.theme.minus()).widget();
         remove.action = () -> {
            Proxies.get().remove(proxy);
            this.reload();
         };
         table.row();
      }

      WButton newBtn = (WButton)this.add(this.theme.button("New")).expandX().widget();
      newBtn.action = () -> {
         this.openEditProxyScreen((Proxy)null);
      };
   }

   public boolean toClipboard() {
      return NbtUtils.toClipboard(Proxies.get());
   }

   public boolean fromClipboard() {
      return NbtUtils.fromClipboard((System)Proxies.get());
   }

   protected class EditProxyScreen extends WindowScreen {
      private final boolean isNew;
      private final Proxy proxy;

      public EditProxyScreen(GuiTheme theme, Proxy p) {
         super(theme, p == null ? "New Proxy" : "Edit Proxy");
         this.isNew = p == null;
         this.proxy = this.isNew ? new Proxy() : p;
      }

      public void initWidgets() {
         WTable general = (WTable)this.add(this.theme.table()).expandX().widget();
         general.add(this.theme.label("Proxy Name:"));
         WTextBox name = (WTextBox)general.add(this.theme.textBox(this.proxy.name)).expandX().widget();
         name.action = () -> {
            this.proxy.name = name.get();
         };
         general.row();
         general.add(this.theme.label("Type:"));
         WDropdown<ProxyType> type = (WDropdown)general.add(this.theme.dropdown(this.proxy.type)).widget();
         type.action = () -> {
            this.proxy.type = (ProxyType)type.get();
         };
         general.row();
         general.add(this.theme.label("IP:"));
         WTextBox ip = (WTextBox)general.add(this.theme.textBox(this.proxy.address)).minWidth(400.0D).expandX().widget();
         ip.action = () -> {
            this.proxy.address = ip.get();
         };
         general.row();
         general.add(this.theme.label("Port:"));
         WIntEdit port = (WIntEdit)general.add(this.theme.intEdit(this.proxy.port, 0, 65535, true)).expandX().widget();
         port.action = () -> {
            this.proxy.port = port.get();
         };
         this.add(this.theme.horizontalSeparator("Optional")).expandX().widget();
         WTable optional = (WTable)this.add(this.theme.table()).expandX().widget();
         optional.add(this.theme.label("Username:"));
         WTextBox username = (WTextBox)optional.add(this.theme.textBox(this.proxy.username)).expandX().widget();
         username.action = () -> {
            this.proxy.username = username.get();
         };
         optional.row();
         optional.add(this.theme.label("Password:"));
         WTextBox password = (WTextBox)optional.add(this.theme.textBox(this.proxy.password)).expandX().widget();
         password.action = () -> {
            this.proxy.password = password.get();
         };
         this.add(this.theme.horizontalSeparator()).expandX();
         WButton addSave = (WButton)this.add(this.theme.button(this.isNew ? "Add" : "Save")).expandX().widget();
         addSave.action = () -> {
            if (this.proxy.resolveAddress() && (!this.isNew || Proxies.get().add(this.proxy))) {
               ProxiesScreen.this.dirty = true;
               this.method_25419();
            }

         };
         this.enterAction = addSave.action;
      }
   }
}
