package meteordevelopment.meteorclient.gui.screens;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.tabs.Tab;
import meteordevelopment.meteorclient.gui.tabs.TabScreen;
import meteordevelopment.meteorclient.gui.tabs.Tabs;
import meteordevelopment.meteorclient.gui.utils.Cell;
import meteordevelopment.meteorclient.gui.widgets.containers.WContainer;
import meteordevelopment.meteorclient.gui.widgets.containers.WSection;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.containers.WView;
import meteordevelopment.meteorclient.gui.widgets.containers.WWindow;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import net.minecraft.class_1802;

public class ModulesScreen extends TabScreen {
   public ModulesScreen(GuiTheme theme) {
      super(theme, (Tab)Tabs.get().get(0));
   }

   public void initWidgets() {
      this.add(new ModulesScreen.WCategoryController());
      WVerticalList help = (WVerticalList)this.add(this.theme.verticalList()).pad(4.0D).bottom().widget();
      help.add(this.theme.label("Left click - Toggle module"));
      help.add(this.theme.label("Right click - Open module settings"));
   }

   protected WWindow createCategory(WContainer c, Category category) {
      WWindow w = this.theme.window(category.name);
      w.id = category.name;
      w.padding = 0.0D;
      w.spacing = 0.0D;
      if (this.theme.categoryIcons()) {
         w.beforeHeaderInit = (wContainer) -> {
            wContainer.add(this.theme.item(category.icon)).pad(2.0D);
         };
      }

      c.add(w);
      w.view.scrollOnlyWhenMouseOver = true;
      w.view.hasScrollBar = false;
      w.view.spacing = 0.0D;

      Module module;
      for(Iterator var4 = Modules.get().getGroup(category).iterator(); var4.hasNext(); w.add(this.theme.module(module)).expandX().widget().tooltip = module.description) {
         module = (Module)var4.next();
      }

      return w;
   }

   protected void createSearchW(WContainer w, String text) {
      if (!text.isEmpty()) {
         Set<Module> modules = Modules.get().searchTitles(text);
         WSection section;
         Iterator var5;
         Module module;
         if (modules.size() > 0) {
            section = (WSection)w.add(this.theme.section("Modules")).expandX().widget();
            section.spacing = 0.0D;
            var5 = modules.iterator();

            while(var5.hasNext()) {
               module = (Module)var5.next();
               section.add(this.theme.module(module)).expandX();
            }
         }

         modules = Modules.get().searchSettingTitles(text);
         if (modules.size() > 0) {
            section = (WSection)w.add(this.theme.section("Settings")).expandX().widget();
            section.spacing = 0.0D;
            var5 = modules.iterator();

            while(var5.hasNext()) {
               module = (Module)var5.next();
               section.add(this.theme.module(module)).expandX();
            }
         }
      }

   }

   protected WWindow createSearch(WContainer c) {
      WWindow w = this.theme.window("Search");
      w.id = "search";
      if (this.theme.categoryIcons()) {
         w.beforeHeaderInit = (wContainer) -> {
            wContainer.add(this.theme.item(class_1802.field_8251.method_7854())).pad(2.0D);
         };
      }

      c.add(w);
      w.view.scrollOnlyWhenMouseOver = true;
      w.view.hasScrollBar = false;
      WView var10000 = w.view;
      var10000.maxHeight -= 20.0D;
      WVerticalList l = this.theme.verticalList();
      WTextBox text = (WTextBox)w.add(this.theme.textBox("")).minWidth(140.0D).expandX().widget();
      text.setFocused(true);
      text.action = () -> {
         l.clear();
         this.createSearchW(l, text.get());
      };
      w.add(l).expandX();
      this.createSearchW(l, text.get());
      return w;
   }

   public boolean toClipboard() {
      return NbtUtils.toClipboard(Modules.get());
   }

   public boolean fromClipboard() {
      return NbtUtils.fromClipboard((System)Modules.get());
   }

   public void reload() {
   }

   protected class WCategoryController extends WContainer {
      public final List<WWindow> windows = new ArrayList();

      public void init() {
         Iterator var1 = Modules.loopCategories().iterator();

         while(var1.hasNext()) {
            Category category = (Category)var1.next();
            this.windows.add(ModulesScreen.this.createCategory(this, category));
         }

         this.windows.add(ModulesScreen.this.createSearch(this));
      }

      protected void onCalculateWidgetPositions() {
         double pad = this.theme.scale(4.0D);
         double h = this.theme.scale(40.0D);
         double x = this.x + pad;
         double y = this.y;

         Cell cell;
         for(Iterator var9 = this.cells.iterator(); var9.hasNext(); x += cell.width + pad) {
            cell = (Cell)var9.next();
            double windowWidth = (double)Utils.getWindowWidth();
            double windowHeight = (double)Utils.getWindowHeight();
            if (x + cell.width > windowWidth) {
               x += pad;
               y += h;
            }

            if (x > windowWidth) {
               x = windowWidth / 2.0D - cell.width / 2.0D;
               if (x < 0.0D) {
                  x = 0.0D;
               }
            }

            if (y > windowHeight) {
               y = windowHeight / 2.0D - cell.height / 2.0D;
               if (y < 0.0D) {
                  y = 0.0D;
               }
            }

            cell.x = x;
            cell.y = y;
            cell.width = cell.widget().width;
            cell.height = cell.widget().height;
            cell.alignWidget();
         }

      }
   }
}
