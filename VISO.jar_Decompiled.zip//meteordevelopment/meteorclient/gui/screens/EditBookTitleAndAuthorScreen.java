package meteordevelopment.meteorclient.gui.screens;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2820;
import net.minecraft.class_3872.class_3931;
import net.minecraft.class_3872.class_3933;

public class EditBookTitleAndAuthorScreen extends WindowScreen {
   private final class_1799 itemStack;
   private final class_1268 hand;

   public EditBookTitleAndAuthorScreen(GuiTheme theme, class_1799 itemStack, class_1268 hand) {
      super(theme, "Edit title & author");
      this.itemStack = itemStack;
      this.hand = hand;
   }

   public void initWidgets() {
      WTable t = (WTable)this.add(this.theme.table()).expandX().widget();
      t.add(this.theme.label("Title"));
      WTextBox title = (WTextBox)t.add(this.theme.textBox(this.itemStack.method_7948().method_10558("title"))).minWidth(220.0D).expandX().widget();
      t.row();
      t.add(this.theme.label("Author"));
      WTextBox author = (WTextBox)t.add(this.theme.textBox(this.itemStack.method_7969().method_10558("author"))).minWidth(220.0D).expandX().widget();
      t.row();
      ((WButton)t.add(this.theme.button("Done")).expandX().widget()).action = () -> {
         this.itemStack.method_7969().method_10582("author", author.get());
         this.itemStack.method_7969().method_10582("title", title.get());
         class_3931 contents = new class_3933(this.itemStack);
         List<String> pages = new ArrayList(contents.method_17560());

         for(int i = 0; i < contents.method_17560(); ++i) {
            pages.add(contents.method_17563(i).getString());
         }

         MeteorClient.mc.method_1562().method_2883(new class_2820(this.hand == class_1268.field_5808 ? MeteorClient.mc.field_1724.method_31548().field_7545 : 40, pages, Optional.of(title.get())));
         this.method_25419();
      };
   }
}
