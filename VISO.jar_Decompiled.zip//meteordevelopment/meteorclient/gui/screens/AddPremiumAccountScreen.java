package meteordevelopment.meteorclient.gui.screens;

import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.systems.accounts.Accounts;
import meteordevelopment.meteorclient.systems.accounts.types.PremiumAccount;

public class AddPremiumAccountScreen extends AddAccountScreen {
   public AddPremiumAccountScreen(GuiTheme theme, AccountsScreen parent) {
      super(theme, "Add Premium Account", parent);
   }

   public void initWidgets() {
      WTable t = (WTable)this.add(this.theme.table()).widget();
      t.add(this.theme.label("Email: "));
      WTextBox email = (WTextBox)t.add(this.theme.textBox("")).minWidth(400.0D).expandX().widget();
      email.setFocused(true);
      t.row();
      t.add(this.theme.label("Password: "));
      WTextBox password = (WTextBox)t.add(this.theme.textBox("")).minWidth(400.0D).expandX().widget();
      t.row();
      this.add = (WButton)t.add(this.theme.button("Add")).expandX().widget();
      this.add.action = () -> {
         PremiumAccount account = new PremiumAccount(email.get(), password.get());
         if (!email.get().isEmpty() && !password.get().isEmpty() && email.get().contains("@") && !Accounts.get().exists(account)) {
            AccountsScreen.addAccount(this, this.parent, account);
         }

      };
      this.enterAction = this.add.action;
   }
}
