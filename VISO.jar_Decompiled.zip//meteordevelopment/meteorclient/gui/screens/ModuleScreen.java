package meteordevelopment.meteorclient.gui.screens;

import meteordevelopment.meteorclient.events.meteor.ModuleBindChangedEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.utils.Cell;
import meteordevelopment.meteorclient.gui.widgets.WKeybind;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WContainer;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.containers.WSection;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2487;

public class ModuleScreen extends WindowScreen {
   private final Module module;
   private WContainer settingsContainer;
   private WKeybind keybind;

   public ModuleScreen(GuiTheme theme, Module module) {
      super(theme, module.title);
      this.module = module;
   }

   public void initWidgets() {
      this.add(this.theme.label(this.module.description, (double)Utils.getWindowWidth() / 2.0D));
      if (this.module.settings.groups.size() > 0) {
         this.settingsContainer = (WContainer)this.add(this.theme.verticalList()).expandX().widget();
         this.settingsContainer.add(this.theme.settings(this.module.settings)).expandX();
      }

      WWidget widget = this.module.getWidget(this.theme);
      if (widget != null) {
         this.add(this.theme.horizontalSeparator()).expandX();
         Cell<WWidget> cell = this.add(widget);
         if (widget instanceof WContainer) {
            cell.expandX();
         }
      }

      WSection section = (WSection)this.add(this.theme.section("Bind", true)).expandX().widget();
      this.keybind = (WKeybind)section.add(this.theme.keybind(this.module.keybind)).expandX().widget();
      this.keybind.actionOnSet = () -> {
         Modules.get().setModuleToBind(this.module);
      };
      WHorizontalList tobr = (WHorizontalList)section.add(this.theme.horizontalList()).widget();
      tobr.add(this.theme.label("Toggle on bind release: "));
      WCheckbox tobrC = (WCheckbox)tobr.add(this.theme.checkbox(this.module.toggleOnBindRelease)).widget();
      tobrC.action = () -> {
         this.module.toggleOnBindRelease = tobrC.checked;
      };
      this.add(this.theme.horizontalSeparator()).expandX();
      WHorizontalList bottom = (WHorizontalList)this.add(this.theme.horizontalList()).expandX().widget();
      bottom.add(this.theme.label("Active: "));
      WCheckbox active = (WCheckbox)bottom.add(this.theme.checkbox(this.module.isActive())).expandCellX().widget();
      active.action = () -> {
         if (this.module.isActive() != active.checked) {
            this.module.toggle();
         }

      };
   }

   public void method_25393() {
      super.method_25393();
      this.module.settings.tick(this.settingsContainer, this.theme);
   }

   @EventHandler
   private void onModuleBindChanged(ModuleBindChangedEvent event) {
      this.keybind.reset();
   }

   public boolean toClipboard() {
      return NbtUtils.toClipboard(this.module.title, this.module.toTag());
   }

   public boolean fromClipboard() {
      class_2487 clipboard = NbtUtils.fromClipboard(this.module.toTag());
      if (clipboard != null) {
         this.module.fromTag(clipboard);
         return true;
      } else {
         return false;
      }
   }
}
