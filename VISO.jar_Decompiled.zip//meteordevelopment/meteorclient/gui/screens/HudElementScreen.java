package meteordevelopment.meteorclient.gui.screens;

import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.widgets.containers.WContainer;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.systems.hud.HUD;
import meteordevelopment.meteorclient.systems.hud.modules.HudElement;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import net.minecraft.class_2487;

public class HudElementScreen extends WindowScreen {
   public final HudElement element;
   private WContainer settings;

   public HudElementScreen(GuiTheme theme, HudElement element) {
      super(theme, element.title);
      this.element = element;
   }

   public void initWidgets() {
      this.add(this.theme.label(this.element.description, (double)Utils.getWindowWidth() / 2.0D));
      if (this.element.settings.sizeGroups() > 0) {
         this.settings = (WContainer)this.add(this.theme.verticalList()).expandX().widget();
         this.settings.add(this.theme.settings(this.element.settings)).expandX();
         this.add(this.theme.horizontalSeparator()).expandX();
      }

      WHorizontalList bottomList = (WHorizontalList)this.add(this.theme.horizontalList()).expandX().widget();
      bottomList.add(this.theme.label("Active:"));
      WCheckbox active = (WCheckbox)bottomList.add(this.theme.checkbox(this.element.active)).widget();
      active.action = () -> {
         if (this.element.active != active.checked) {
            this.element.toggle();
         }

      };
      WButton reset = (WButton)bottomList.add(this.theme.button(GuiRenderer.RESET)).expandCellX().right().widget();
      reset.action = () -> {
         if (this.element.active != this.element.defaultActive) {
            this.element.active = active.checked = this.element.defaultActive;
         }

      };
   }

   public void method_25393() {
      super.method_25393();
      if (this.settings != null) {
         this.element.settings.tick(this.settings, this.theme);
      }

   }

   protected void onRenderBefore(float delta) {
      if (!Utils.canUpdate()) {
         ((HUD)Systems.get(HUD.class)).render(delta, (hudElement) -> {
            return true;
         });
      }

   }

   public boolean toClipboard() {
      return NbtUtils.toClipboard(this.element.title, this.element.toTag());
   }

   public boolean fromClipboard() {
      class_2487 clipboard = NbtUtils.fromClipboard(this.element.toTag());
      if (clipboard != null) {
         this.element.fromTag(clipboard);
         return true;
      } else {
         return false;
      }
   }
}
