package meteordevelopment.meteorclient.gui;

public class GuiKeyEvents {
   public static boolean canUseKeys = true;
}
