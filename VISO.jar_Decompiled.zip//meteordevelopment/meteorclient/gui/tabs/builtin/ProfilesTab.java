package meteordevelopment.meteorclient.gui.tabs.builtin;

import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.tabs.Tab;
import meteordevelopment.meteorclient.gui.tabs.TabScreen;
import meteordevelopment.meteorclient.gui.tabs.WindowTabScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WMinus;
import meteordevelopment.meteorclient.gui.widgets.pressable.WPlus;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.profiles.Profile;
import meteordevelopment.meteorclient.systems.profiles.Profiles;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import net.minecraft.class_437;
import org.apache.commons.lang3.StringUtils;

public class ProfilesTab extends Tab {
   public ProfilesTab() {
      super("Profiles");
   }

   public TabScreen createScreen(GuiTheme theme) {
      return new ProfilesTab.ProfilesScreen(theme, this);
   }

   public boolean isScreen(class_437 screen) {
      return screen instanceof ProfilesTab.ProfilesScreen;
   }

   private static class ProfilesScreen extends WindowTabScreen {
      public ProfilesScreen(GuiTheme theme, Tab tab) {
         super(theme, tab);
      }

      public void initWidgets() {
         WTable table = (WTable)this.add(this.theme.table()).expandX().minWidth(300.0D).widget();
         Iterator var2 = Profiles.get().iterator();

         while(var2.hasNext()) {
            Profile profile = (Profile)var2.next();
            table.add(this.theme.label(profile.name)).expandCellX();
            WButton save = (WButton)table.add(this.theme.button("Save")).widget();
            Objects.requireNonNull(profile);
            save.action = profile::save;
            WButton load = (WButton)table.add(this.theme.button("Load")).widget();
            Objects.requireNonNull(profile);
            load.action = profile::load;
            WButton edit = (WButton)table.add(this.theme.button(GuiRenderer.EDIT)).widget();
            edit.action = () -> {
               MeteorClient.mc.method_1507(new ProfilesTab.EditProfileScreen(this.theme, profile, this::reload));
            };
            WMinus remove = (WMinus)table.add(this.theme.minus()).widget();
            remove.action = () -> {
               Profiles.get().remove(profile);
               this.reload();
            };
            table.row();
         }

         table.add(this.theme.horizontalSeparator()).expandX();
         table.row();
         WButton create = (WButton)table.add(this.theme.button("Create")).expandX().widget();
         create.action = () -> {
            MeteorClient.mc.method_1507(new ProfilesTab.EditProfileScreen(this.theme, (Profile)null, this::reload));
         };
      }

      public boolean toClipboard() {
         return NbtUtils.toClipboard(Profiles.get());
      }

      public boolean fromClipboard() {
         return NbtUtils.fromClipboard((System)Profiles.get());
      }
   }

   private static class EditProfileScreen extends WindowScreen {
      private final Profile newProfile;
      private final Profile oldProfile;
      private final boolean isNew;
      private final Runnable action;

      public EditProfileScreen(GuiTheme theme, Profile profile, Runnable action) {
         super(theme, profile == null ? "New Profile" : "Edit Profile");
         this.isNew = profile == null;
         this.newProfile = new Profile();
         this.oldProfile = this.isNew ? new Profile() : profile;
         this.action = action;
         this.newProfile.set(this.oldProfile);
      }

      public void initWidgets() {
         this.initWidgets(this.oldProfile, this.newProfile.loadOnJoinIps);
      }

      public void initWidgets(Profile ogProfile, List<String> list) {
         WTable table = (WTable)this.add(this.theme.table()).expandX().widget();
         table.add(this.theme.label("Name:"));
         WTextBox nameInput = (WTextBox)table.add(this.theme.textBox(ogProfile.name, this::nameFilter)).minWidth(400.0D).expandX().widget();
         nameInput.action = () -> {
            this.newProfile.name = nameInput.get();
         };
         table.row();
         table.add(this.theme.horizontalSeparator()).expandX();
         table.row();
         table.add(this.theme.label("Load on Launch:"));
         WCheckbox onLaunchCheckbox = (WCheckbox)table.add(this.theme.checkbox(ogProfile.onLaunch)).widget();
         onLaunchCheckbox.action = () -> {
            this.newProfile.onLaunch = onLaunchCheckbox.checked;
         };
         table.row();
         table.add(this.theme.label("Load when Joining:"));
         WTable ips = (WTable)table.add(this.theme.table()).widget();
         this.initTable(ips, list);
         table.row();
         table.add(this.theme.horizontalSeparator()).expandX();
         table.row();
         table.add(this.theme.label("Accounts:"));
         WCheckbox accountsBool = (WCheckbox)table.add(this.theme.checkbox(ogProfile.accounts)).widget();
         accountsBool.action = () -> {
            this.newProfile.accounts = accountsBool.checked;
         };
         table.row();
         table.add(this.theme.label("Config:"));
         WCheckbox configBool = (WCheckbox)table.add(this.theme.checkbox(ogProfile.config)).widget();
         configBool.action = () -> {
            this.newProfile.config = configBool.checked;
         };
         table.row();
         table.add(this.theme.label("Friends:"));
         WCheckbox friendsBool = (WCheckbox)table.add(this.theme.checkbox(ogProfile.friends)).widget();
         friendsBool.action = () -> {
            this.newProfile.friends = friendsBool.checked;
         };
         table.row();
         table.add(this.theme.label("Macros:"));
         WCheckbox macrosBool = (WCheckbox)table.add(this.theme.checkbox(ogProfile.macros)).widget();
         macrosBool.action = () -> {
            this.newProfile.macros = macrosBool.checked;
         };
         table.row();
         table.add(this.theme.label("Modules:"));
         WCheckbox modulesBool = (WCheckbox)table.add(this.theme.checkbox(ogProfile.modules)).widget();
         modulesBool.action = () -> {
            this.newProfile.modules = modulesBool.checked;
         };
         table.row();
         table.add(this.theme.label("Waypoints:"));
         WCheckbox waypointsBool = (WCheckbox)table.add(this.theme.checkbox(ogProfile.waypoints)).widget();
         waypointsBool.action = () -> {
            this.newProfile.waypoints = waypointsBool.checked;
         };
         table.row();
         table.add(this.theme.label("HUD:"));
         WCheckbox hudBool = (WCheckbox)table.add(this.theme.checkbox(ogProfile.hud)).widget();
         hudBool.action = () -> {
            this.newProfile.hud = hudBool.checked;
         };
         table.row();
         table.add(this.theme.horizontalSeparator()).expandX();
         table.row();
         WButton save = (WButton)table.add(this.theme.button("Save")).expandX().widget();
         save.action = () -> {
            if (!this.newProfile.name.isEmpty()) {
               Iterator var1 = Profiles.get().iterator();

               Profile p;
               do {
                  if (!var1.hasNext()) {
                     this.oldProfile.set(this.newProfile);
                     if (this.isNew) {
                        Profiles.get().add(this.oldProfile);
                     } else {
                        Profiles.get().save();
                     }

                     this.method_25419();
                     return;
                  }

                  p = (Profile)var1.next();
               } while(!this.newProfile.equals(p) || this.oldProfile.equals(p));

            }
         };
         this.enterAction = save.action;
      }

      private void initTable(WTable table, List<String> ipList) {
         if (ipList.isEmpty()) {
            ipList.add("");
         }

         for(int i = 0; i < ipList.size(); ++i) {
            WTextBox line = (WTextBox)table.add(this.theme.textBox((String)ipList.get(i), this::ipFilter)).minWidth(400.0D).expandX().widget();
            line.action = () -> {
               String ip = line.get().trim();
               if (ip.contains(".") && !StringUtils.containsWhitespace(ip)) {
                  ipList.set(i, ip);
               }
            };
            if (i != ipList.size() - 1) {
               WMinus remove = (WMinus)table.add(this.theme.minus()).widget();
               remove.action = () -> {
                  ipList.remove(i);
                  this.clear();
                  this.initWidgets(this.newProfile, ipList);
               };
            } else {
               WPlus add = (WPlus)table.add(this.theme.plus()).widget();
               add.action = () -> {
                  ipList.add("");
                  this.clear();
                  this.initWidgets(this.newProfile, ipList);
               };
            }

            table.row();
         }

      }

      private boolean nameFilter(String text, char character) {
         return character >= 'a' && character <= 'z' || character >= 'A' && character <= 'Z' || character >= '0' && character <= '9' || character == '_' || character == '-' || character == '.' || character == ' ';
      }

      private boolean ipFilter(String text, char character) {
         if (text.contains(":") && character == ':') {
            return false;
         } else {
            return character >= 'a' && character <= 'z' || character >= 'A' && character <= 'Z' || character >= '0' && character <= '9' || character == '.';
         }
      }

      protected void onClosed() {
         if (this.action != null) {
            this.action.run();
         }

      }
   }
}
