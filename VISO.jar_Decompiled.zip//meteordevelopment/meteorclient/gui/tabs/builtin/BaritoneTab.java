package meteordevelopment.meteorclient.gui.tabs.builtin;

import baritone.api.BaritoneAPI;
import baritone.api.Settings.Setting;
import baritone.api.utils.SettingsUtil;
import java.awt.Color;
import java.lang.reflect.Field;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.tabs.Tab;
import meteordevelopment.meteorclient.gui.tabs.TabScreen;
import meteordevelopment.meteorclient.gui.tabs.WindowTabScreen;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.Settings;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_437;

public class BaritoneTab extends Tab {
   private static Settings settings;

   public BaritoneTab() {
      super("Baritone");
   }

   private static Settings getSettings() {
      if (settings != null) {
         return settings;
      } else {
         settings = new Settings();
         SettingGroup sgBool = settings.createGroup("Checkboxes");
         SettingGroup sgDouble = settings.createGroup("Numbers");
         SettingGroup sgInt = settings.createGroup("Whole Numbers");
         SettingGroup sgColor = settings.createGroup("Colors");

         try {
            Class<? extends baritone.api.Settings> klass = BaritoneAPI.getSettings().getClass();
            Field[] var5 = klass.getDeclaredFields();
            int var6 = var5.length;

            for(int var7 = 0; var7 < var6; ++var7) {
               Field field = var5[var7];
               Object obj = field.get(BaritoneAPI.getSettings());
               if (obj instanceof Setting) {
                  Setting setting = (Setting)obj;
                  Object value = setting.value;
                  if (value instanceof Boolean) {
                     sgBool.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name(setting.getName())).description(setting.getName())).defaultValue((Boolean)setting.defaultValue)).onChanged((aBoolean) -> {
                        setting.value = aBoolean;
                     })).onModuleActivated((booleanSetting) -> {
                        booleanSetting.set((Boolean)setting.value);
                     })).build());
                  } else if (value instanceof Double) {
                     sgDouble.add(((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name(setting.getName())).description(setting.getName())).defaultValue((Double)setting.defaultValue).onChanged((aDouble) -> {
                        setting.value = aDouble;
                     })).onModuleActivated((doubleSetting) -> {
                        doubleSetting.set((Double)setting.value);
                     })).build());
                  } else if (value instanceof Float) {
                     sgDouble.add(((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name(setting.getName())).description(setting.getName())).defaultValue(((Float)setting.defaultValue).doubleValue()).onChanged((aDouble) -> {
                        setting.value = aDouble.floatValue();
                     })).onModuleActivated((doubleSetting) -> {
                        doubleSetting.set(((Float)setting.value).doubleValue());
                     })).build());
                  } else if (value instanceof Integer) {
                     sgInt.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name(setting.getName())).description(setting.getName())).defaultValue((Integer)setting.defaultValue)).onChanged((integer) -> {
                        setting.value = integer;
                     })).onModuleActivated((integerSetting) -> {
                        integerSetting.set((Integer)setting.value);
                     })).build());
                  } else if (value instanceof Long) {
                     sgInt.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name(setting.getName())).description(setting.getName())).defaultValue(((Long)setting.defaultValue).intValue())).onChanged((integer) -> {
                        setting.value = integer.longValue();
                     })).onModuleActivated((integerSetting) -> {
                        integerSetting.set(((Long)setting.value).intValue());
                     })).build());
                  } else if (value instanceof Color) {
                     Color c = (Color)setting.value;
                     sgColor.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name(setting.getName())).description(setting.getName())).defaultValue(new SettingColor(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()))).onChanged((color) -> {
                        setting.value = new Color(color.r, color.g, color.b, color.a);
                     })).onModuleActivated((colorSetting) -> {
                        colorSetting.set(new SettingColor(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()));
                     })).build());
                  }
               }
            }
         } catch (IllegalAccessException var13) {
            var13.printStackTrace();
         }

         return settings;
      }
   }

   public TabScreen createScreen(GuiTheme theme) {
      return new BaritoneTab.BaritoneScreen(theme, this);
   }

   public boolean isScreen(class_437 screen) {
      return screen instanceof BaritoneTab.BaritoneScreen;
   }

   private static class BaritoneScreen extends WindowTabScreen {
      public BaritoneScreen(GuiTheme theme, Tab tab) {
         super(theme, tab);
         BaritoneTab.getSettings().onActivated();
      }

      public void initWidgets() {
         WTextBox filter = (WTextBox)this.add(this.theme.textBox("")).minWidth(400.0D).expandX().widget();
         filter.setFocused(true);
         filter.action = () -> {
            this.clear();
            this.add(filter);
            this.add(this.theme.settings(BaritoneTab.getSettings(), filter.get().trim())).expandX();
         };
         this.add(this.theme.settings(BaritoneTab.getSettings(), filter.get().trim())).expandX();
      }

      protected void onClosed() {
         SettingsUtil.save(BaritoneAPI.getSettings());
      }
   }
}
