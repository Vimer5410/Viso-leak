package meteordevelopment.meteorclient.gui.tabs.builtin;

import java.util.Iterator;
import java.util.Objects;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.tabs.Tab;
import meteordevelopment.meteorclient.gui.tabs.TabScreen;
import meteordevelopment.meteorclient.gui.tabs.WindowTabScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.containers.WSection;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WMinus;
import meteordevelopment.meteorclient.gui.widgets.pressable.WPlus;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.Settings;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.friends.Friend;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_437;

public class FriendsTab extends Tab {
   public FriendsTab() {
      super("Friends");
   }

   public TabScreen createScreen(GuiTheme theme) {
      return new FriendsTab.FriendsScreen(theme, this);
   }

   public boolean isScreen(class_437 screen) {
      return screen instanceof FriendsTab.FriendsScreen;
   }

   private static class FriendsScreen extends WindowTabScreen {
      private final Settings settings = new Settings();

      public FriendsScreen(GuiTheme theme, Tab tab) {
         super(theme, tab);
         SettingGroup sgGeneral = this.settings.getDefaultGroup();
         ColorSetting.Builder var10001 = (ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("color")).description("The color used to show friends.")).defaultValue(new SettingColor(0, 255, 180));
         SettingColor var10002 = Friends.get().color;
         Objects.requireNonNull(var10002);
         sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)var10001.onChanged(var10002::set)).onModuleActivated((colorSetting) -> {
            colorSetting.set(Friends.get().color);
         })).build());
         sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("attack")).description("Whether to attack friends.")).defaultValue(false)).onChanged((aBoolean) -> {
            Friends.get().attack = aBoolean;
         })).onModuleActivated((booleanSetting) -> {
            booleanSetting.set(Friends.get().attack);
         })).build());
         this.settings.onActivated();
      }

      public void initWidgets() {
         this.add(this.theme.settings(this.settings)).expandX();
         WSection friends = (WSection)this.add(this.theme.section("Friends")).expandX().widget();
         WTable table = (WTable)friends.add(this.theme.table()).expandX().widget();
         this.initTable(table);
         WHorizontalList list = (WHorizontalList)friends.add(this.theme.horizontalList()).expandX().widget();
         WTextBox nameW = (WTextBox)list.add(this.theme.textBox("")).minWidth(400.0D).expandX().widget();
         nameW.setFocused(true);
         WPlus add = (WPlus)list.add(this.theme.plus()).widget();
         add.action = () -> {
            String name = nameW.get().trim();
            if (Friends.get().add(new Friend(name))) {
               nameW.set("");
               table.clear();
               this.initTable(table);
            }

         };
         this.enterAction = add.action;
      }

      private void initTable(WTable table) {
         Iterator var2 = Friends.get().iterator();

         while(var2.hasNext()) {
            Friend friend = (Friend)var2.next();
            table.add(this.theme.label(friend.name));
            WMinus remove = (WMinus)table.add(this.theme.minus()).expandCellX().right().widget();
            remove.action = () -> {
               Friends.get().remove(friend);
               table.clear();
               this.initTable(table);
            };
            table.row();
         }

      }

      public boolean toClipboard() {
         return NbtUtils.toClipboard(Friends.get());
      }

      public boolean fromClipboard() {
         return NbtUtils.fromClipboard((System)Friends.get());
      }
   }
}
