package meteordevelopment.meteorclient.gui.tabs.builtin;

import java.util.Iterator;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.meteor.MouseButtonEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.tabs.Tab;
import meteordevelopment.meteorclient.gui.tabs.TabScreen;
import meteordevelopment.meteorclient.gui.tabs.WindowTabScreen;
import meteordevelopment.meteorclient.gui.widgets.WKeybind;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WMinus;
import meteordevelopment.meteorclient.gui.widgets.pressable.WPlus;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.macros.Macro;
import meteordevelopment.meteorclient.systems.macros.Macros;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_437;

public class MacrosTab extends Tab {
   public MacrosTab() {
      super("Macros");
   }

   public TabScreen createScreen(GuiTheme theme) {
      return new MacrosTab.MacrosScreen(theme, this);
   }

   public boolean isScreen(class_437 screen) {
      return screen instanceof MacrosTab.MacrosScreen;
   }

   private static class MacrosScreen extends WindowTabScreen {
      public MacrosScreen(GuiTheme theme, Tab tab) {
         super(theme, tab);
      }

      public void initWidgets() {
         if (Macros.get().getAll().size() > 0) {
            WTable table = (WTable)this.add(this.theme.table()).expandX().widget();
            Iterator var2 = Macros.get().iterator();

            while(var2.hasNext()) {
               Macro macro = (Macro)var2.next();
               table.add(this.theme.label(macro.name + " (" + macro.keybind + ")"));
               WButton edit = (WButton)table.add(this.theme.button(GuiRenderer.EDIT)).expandCellX().right().widget();
               edit.action = () -> {
                  MeteorClient.mc.method_1507(new MacrosTab.MacroEditorScreen(this.theme, macro));
               };
               WMinus remove = (WMinus)table.add(this.theme.minus()).widget();
               remove.action = () -> {
                  Macros.get().remove(macro);
                  this.clear();
                  this.initWidgets();
               };
               table.row();
            }
         }

         WButton create = (WButton)this.add(this.theme.button("Create")).expandX().widget();
         create.action = () -> {
            MeteorClient.mc.method_1507(new MacrosTab.MacroEditorScreen(this.theme, (Macro)null));
         };
      }

      public boolean toClipboard() {
         return NbtUtils.toClipboard(Macros.get());
      }

      public boolean fromClipboard() {
         return NbtUtils.fromClipboard((System)Macros.get());
      }
   }

   private static class MacroEditorScreen extends WindowScreen {
      private final boolean isNew;
      private final Macro macro;
      private WKeybind keybind;
      private boolean binding;

      public MacroEditorScreen(GuiTheme theme, Macro m) {
         super(theme, m == null ? "Create Macro" : "Edit Macro");
         this.isNew = m == null;
         this.macro = this.isNew ? new Macro() : m;
      }

      public void initWidgets() {
         this.initWidgets(this.macro);
      }

      private void initWidgets(Macro m) {
         WTable t = (WTable)this.add(this.theme.table()).widget();
         t.add(this.theme.label("Name:"));
         WTextBox name = (WTextBox)t.add(this.theme.textBox(m == null ? "" : this.macro.name)).minWidth(400.0D).expandX().widget();
         name.setFocused(true);
         name.action = () -> {
            this.macro.name = name.get().trim();
         };
         t.row();
         t.add(this.theme.label("Messages:")).padTop(4.0D).top();
         WTable lines = (WTable)t.add(this.theme.table()).widget();
         this.initTable(lines);
         this.keybind = (WKeybind)this.add(this.theme.keybind(this.macro.keybind)).expandX().widget();
         this.keybind.actionOnSet = () -> {
            this.binding = true;
         };
         WButton apply = (WButton)this.add(this.theme.button(this.isNew ? "Add" : "Apply")).expandX().widget();
         apply.action = () -> {
            if (this.isNew) {
               if (this.macro.name != null && !this.macro.name.isEmpty() && this.macro.messages.size() > 0 && this.macro.keybind.isSet()) {
                  Macros.get().add(this.macro);
                  this.method_25419();
               }
            } else {
               Macros.get().save();
               this.method_25419();
            }

         };
         this.enterAction = apply.action;
      }

      private void initTable(WTable lines) {
         if (this.macro.messages.isEmpty()) {
            this.macro.addMessage("");
         }

         for(int i = 0; i < this.macro.messages.size(); ++i) {
            WTextBox line = (WTextBox)lines.add(this.theme.textBox((String)this.macro.messages.get(i))).minWidth(400.0D).expandX().widget();
            line.action = () -> {
               this.macro.messages.set(i, line.get().trim());
            };
            if (i != this.macro.messages.size() - 1) {
               WMinus remove = (WMinus)lines.add(this.theme.minus()).widget();
               remove.action = () -> {
                  this.macro.removeMessage(i);
                  this.clear();
                  this.initWidgets(this.macro);
               };
            } else {
               WPlus add = (WPlus)lines.add(this.theme.plus()).widget();
               add.action = () -> {
                  this.macro.addMessage("");
                  this.clear();
                  this.initWidgets(this.macro);
               };
            }

            lines.row();
         }

      }

      @EventHandler(
         priority = 200
      )
      private void onKey(KeyEvent event) {
         if (this.onAction(true, event.key)) {
            event.cancel();
         }

      }

      @EventHandler(
         priority = 200
      )
      private void onButton(MouseButtonEvent event) {
         if (this.onAction(false, event.button)) {
            event.cancel();
         }

      }

      private boolean onAction(boolean isKey, int value) {
         if (this.binding) {
            this.keybind.onAction(isKey, value);
            this.binding = false;
            return true;
         } else {
            return false;
         }
      }
   }
}
