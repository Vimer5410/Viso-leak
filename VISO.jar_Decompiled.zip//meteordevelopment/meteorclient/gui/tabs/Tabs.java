package meteordevelopment.meteorclient.gui.tabs;

import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.gui.tabs.builtin.BaritoneTab;
import meteordevelopment.meteorclient.gui.tabs.builtin.ConfigTab;
import meteordevelopment.meteorclient.gui.tabs.builtin.FriendsTab;
import meteordevelopment.meteorclient.gui.tabs.builtin.GuiTab;
import meteordevelopment.meteorclient.gui.tabs.builtin.HudTab;
import meteordevelopment.meteorclient.gui.tabs.builtin.MacrosTab;
import meteordevelopment.meteorclient.gui.tabs.builtin.ModulesTab;
import meteordevelopment.meteorclient.gui.tabs.builtin.ProfilesTab;
import meteordevelopment.meteorclient.utils.Init;
import meteordevelopment.meteorclient.utils.InitStage;

public class Tabs {
   private static final List<Tab> tabs = new ArrayList();

   @Init(
      stage = InitStage.Pre
   )
   public static void init() {
      add(new ModulesTab());
      add(new ConfigTab());
      add(new GuiTab());
      add(new HudTab());
      add(new FriendsTab());
      add(new MacrosTab());
      add(new ProfilesTab());
      add(new BaritoneTab());
   }

   public static void add(Tab tab) {
      tabs.add(tab);
   }

   public static List<Tab> get() {
      return tabs;
   }
}
