package meteordevelopment.meteorclient.gui.utils;

public interface CharFilter {
   boolean filter(String var1, char var2);
}
