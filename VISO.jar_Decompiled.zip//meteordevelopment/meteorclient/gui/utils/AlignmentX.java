package meteordevelopment.meteorclient.gui.utils;

public enum AlignmentX {
   Left,
   Center,
   Right;

   // $FF: synthetic method
   private static AlignmentX[] $values() {
      return new AlignmentX[]{Left, Center, Right};
   }
}
