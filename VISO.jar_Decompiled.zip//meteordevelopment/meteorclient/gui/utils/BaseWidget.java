package meteordevelopment.meteorclient.gui.utils;

import meteordevelopment.meteorclient.gui.GuiTheme;

public interface BaseWidget {
   GuiTheme getTheme();
}
