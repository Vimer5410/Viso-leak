package meteordevelopment.meteorclient.gui.utils;

public enum AlignmentY {
   Top,
   Center,
   Bottom;

   // $FF: synthetic method
   private static AlignmentY[] $values() {
      return new AlignmentY[]{Top, Center, Bottom};
   }
}
