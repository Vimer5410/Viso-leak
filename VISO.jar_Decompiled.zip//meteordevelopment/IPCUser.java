package meteordevelopment;

public class IPCUser {
   public String id;
   public String username;
   public String discriminator;
   public String avatar;
   public boolean bot;
   public String flags;
   public int premium_type;
}
